var psCurrentRedundPolicyState; //Previous power Supply Redundancy Policy State
var psCapability; //Capability value received from GUI backend 
var psCurrentPolicyIdxSelected;// Index of selected policy option from drop down window after page on-load and refresh. 	   

/**
 * Submit a request for data to the server and call
 * refreshThresholdDataCallback when the response arrives.
 */
function refreshThresholdData(data) 
{
    document.chainedCallback = refreshThresholdDataCallback;
    //loadXMLDocument('data?get=' + data, waitWithCallback);
    loadXMLDocument(data, waitWithCallback);
}
        
/**
 * Submit a request for data to the server and call
 * refreshDiscreteDataCallback when the response arrives.
 */
function refreshDiscreteData(data) 
{
    document.chainedCallback = refreshDiscreteDataCallback;
    loadXMLDocument(data, waitWithCallback);
}

function refreshPSData(data) 
{
    document.chainedCallback = refreshPSDataCallback;
    //loadXMLDocument('data?get=' + data, waitWithCallback);
    loadXMLDocument(data, waitWithCallback);
}

function insertStatusIcon(row, cell, status)
{
	var x = document.getElementById(row);
	if (null == x)
		return;
	x = x.insertCell(cell);
	x.innerHTML = "<align='center' valign='middle'> <img src=" + status + " align='absmiddle' border='0'>";
}

/*******************************************************************************
 *	This Function is for mcCave Platform. 
 *  Fix the problem that multiple Status Icons/Markers'are inserted during the 
 *  page refreshing trigered by configurating Redundancy Policy.
 *  Input: cellId, cell,status  
 *	Output: NONE
 *  Fanlu Kong: Intial draft,Jan 2009.
 *******************************************************************************/

function psInsertStatusIcon(cellId, cell, status) 
{
	var x = document.getElementById(cellId);
	if (null == x)
		return;
	x.innerHTML = "<align='center' valign='middle'> <img src=" + status + " align='absmiddle' border='0'>";
}

var Status = {OK : 0, ALERT : 1, FAILED : 2};

statusImg = new Array();
/*statusImg[Status.ALERT]		= "images/non-critical.gif";
statusImg[Status.FAILED]	= "images/critical.gif";
statusImg[Status.OK]		= "images/ok.gif";*/

statusImg[Status.ALERT]		= "noncritical";
statusImg[Status.FAILED]	= "critical";
statusImg[Status.OK]		= "ok";
    
function stringToIcon(str) {
	switch (str) {
	case 'Normal':
		return "images/ok.gif";
	case 'Warning':
		return "images/non-critical.gif";
	case 'Critical':
		return "images/critical.gif";
	case 'Unknown':
		return "images/sevUnknown.gif";
	default:
		return "images/sevUnknown.gif";
	}
}

//OBJ_STATUS_UNKNOWN - 1 , OBJ_STATUS_OK -2 , OBJ_STATUS_NON_CRITICAL -3 ,OBJ_STATUS_CRITICAL - 4
function valueToIcon(str) {
	switch (str) {
	case '1':
		return "images/sevUnknown.gif";
	case '2':
		return "images/ok.gif";
	case '3':
		return "images/non-critical.gif";
	case '4':
		return "images/critical.gif";
	default:
		return "images/sevUnknown.gif";

	}
}

function convert(str)
{
	switch (str) {
	case 'normal':
		return "ok";
	case 'warning':
		return "noncritical";
	case 'critical':
		return "critical";
	default:
		return 'unknown';
	}
	
	return str;
}


var PS_STATE_ABSENT          			= "0";//      0x00    // default settings

var PS_STATE_PRESENCE_DETECTED      	= "1";//BIT(0)  // Presence detected

var PS_STATE_PS_FAILURE_DETECTED    	= "2";//BIT(1)  // PS failure detected

var PS_STATE_PREDICTIVE_FAILURE     	= "3";//BIT(2)  // Predictive failure

var PS_STATE_PS_AC_LOST             		= "4";//BIT(3)  // PS AC lost

var PS_STATE_AC_LOST_OR_OUTOFRANGE  ="5";//BIT(4)  // AC lost or out-of-range

var PS_STATE_AC_PRESENT_OUTOFRANGE  ="6";//BIT(5)  // AC present but out-of-range

var PS_STATE_CONFIG_ERROR           		="7";//BIT(6)  // Configuration error
var PS_STATE_ABSENT_SYS_OFF			="8";
var PS_STATE_PRESENT_SYS_OFF			="9";


function convertPSStatus(status)
{
   var returnStrStatus = "";	

    switch (status)
   {
	case PS_STATE_ABSENT:
		returnStrStatus = psStateAbsent;
		break;
	case PS_STATE_PRESENCE_DETECTED:
		returnStrStatus = psStatePresence;
		break;
	case PS_STATE_PS_FAILURE_DETECTED:
		returnStrStatus =psStateFailure;
		break;
	case PS_STATE_PREDICTIVE_FAILURE:
		returnStrStatus = psStatePredictive;
		break;
	case PS_STATE_PS_AC_LOST:
		returnStrStatus = psStateACLost;
		break;
	case PS_STATE_AC_LOST_OR_OUTOFRANGE:
		returnStrStatus = psStateLostOutofrange;
		break;
	case PS_STATE_AC_PRESENT_OUTOFRANGE:
		returnStrStatus = psStatePresentOutofrange;
		break;
	case PS_STATE_CONFIG_ERROR:
		returnStrStatus =psStateConfigError;
		break;
	case PS_STATE_ABSENT_SYS_OFF:
		returnStrStatus =psStateAbsentSysOff;
		break;
	case PS_STATE_PRESENT_SYS_OFF:
		returnStrStatus =psStatePresentSysOff;
		break;

   }	

	return returnStrStatus;
}



var DATA_OBJ_REDUNDANCY_OTHER       	= "0" // Do not show redundancy box.

var DATA_OBJ_REDUNDANCY_UNKNOWN      = "1" // Power redundancy is Unknown. Configuration options are available through Power Configuration.

var DATA_OBJ_REDUNDANCY_NA            	= "2" // Do not show redundancy box.

var DATA_OBJ_REDUNDANCY_OFFLINE       	= "3" // Do not show redundancy box.

var DATA_OBJ_REDUNDANCY_FULL          	= "4" // Power redundancy is Full. Configuration options are available through Power Configuration.

var DATA_OBJ_REDUNDANCY_DEGRADED     = "5" // Power redundancy is Degraded. Configuration options are available through Power Configuration.

var DATA_OBJ_REDUNDANCY_LOST          	 = "6" // Power redundancy is Lost. Configuration options are available through Power Configuration.


////////////////////////////START of redirection to power configuration //////////////
function redirection_PowerConfig()
{
  var PowerTree = top.treelist.tbl_Powerthermal;
  PowerTree = PowerTree.substring(4);
  top.parent.snb.f_getHTML(PowerTree,top.treelist.snbindex_pwrConfig,top.treelist.lsnbindex_pwrConfig);	
}
////////////////////////////////END/////////////////////////////

function isProductLicensed()
{
  if(top.savedProdDesc.indexOf('Basic')!=-1 || top.savedProdDesc.indexOf('Express')!=-1){
    return false;
  }
  return true;
}


function setPSRedundancyStatus(xmlDoc)
{

   var redundancyStatus = getXMLValue(xmlDoc, "psRedundancyStatus") ;
   var statusIconElem = document.getElementById("redundancyStatusIconDiv");	
   var elem 		  = document.getElementById("redundancyStatusCol");	

  var powerConfigLink = "<a href='javascript:redirection_PowerConfig();' title='Power Configuration'><span>&nbsp;"+ powerConfig +"</span></a> </span>";


  switch (redundancyStatus)
  {
	case DATA_OBJ_REDUNDANCY_OTHER :
	case DATA_OBJ_REDUNDANCY_NA :
	case DATA_OBJ_REDUNDANCY_OFFLINE :
	case DATA_OBJ_REDUNDANCY_UNKNOWN:
		{
			elem.innerHTML = "<span>"+  redundancyConfig + powerConfigLink;

			break;
		}
	case DATA_OBJ_REDUNDANCY_UNKNOWN:
		{
			statusIconElem.innerHTML = "<div class='status_unknown_32'></div>";
			elem.innerHTML = "<span>"+  redundancyUnknown + powerConfigLink;

			break;
		}

	case DATA_OBJ_REDUNDANCY_FULL :
		{
			statusIconElem.innerHTML = "<div class='alertTabTitleOkIcon_32'></div>";
			elem.innerHTML = "<span>"+ redundancyFull + "</span><span id='redundancyConfigMsg'> "+redundancyConfig + powerConfigLink +"</span>";	

			break;
		}
	case DATA_OBJ_REDUNDANCY_DEGRADED :
		{
			statusIconElem.innerHTML = "<div class='alertTabTitleNonCriticalIcon_32'></div>";
			elem.innerHTML = "<span>"+ redundancyDegraded + "   " + redundancyConfig + powerConfigLink;

			break;
		}
	case DATA_OBJ_REDUNDANCY_LOST :
		{
			statusIconElem.innerHTML = "<div class='alertTabTitleCriticalIcon_32'></div>";
			elem.innerHTML = "<span>"+ redundancyLost + "   " + redundancyConfig + powerConfigLink;

			break;
		}
	default:
		{
			elem.innerHTML = "<span>"+  redundancyConfig + powerConfigLink;

			break;
		}
  }	
  
    var power_config_present = ((top.isPlatformBlade == "false" && top.isPmbusPSUPresent == 0) ||(top.isPlatformBlade == "true" && top.iDracSys != top.IDRAC_SCALPEL_SYSTEM && top.isPowerBudgetLicensed !=0) ) ? false: true;

	if (power_config_present && top.isStompAquaSledPowerCfg != 1 && isProductLicensed())
	{	
		showBlockElement('redundancyStatusScreen');	
	} else if(redundancyStatus == DATA_OBJ_REDUNDANCY_FULL) {
        hideElement("redundancyConfigMsg");		
	   showBlockElement('redundancyStatusScreen');	
	} else {
        hideElement('redundancyStatusScreen');
	}
}


var	powerOn = 'powerOn';
var xmlItem = 'sensor';
//xmlRedundancy = 'discreteSensorList';
// 06/10/08 rbj: Added to resolve PR27820: Fan Redundancy is not displayed.
//               This function is only called by refreshThresholdDataCallback(xmlDoc) below,
//               which is only called by listfan.html onLoad & Refresh button.
//               The sensorStatus & name tags are available but not needed.
function refreshRedundancy(xmlDoc){
	var list = getXMLValue(xmlDoc, xmlDiscreteList) ;
	if( list != null  && typeof list == "object" ) {
       	var item = list.getElementsByTagName(xmlItem);
        var reading = "";
        if( item != null ) {
            for (var i = 0; i < item.length; i++) {
				var entry = item[i];
				//var reading = entry.getElementsByTagName("reading")[0].childNodes[0].nodeValue;
				if(entry.getElementsByTagName("reading")[0].childNodes[0] != null)
				   reading = entry.getElementsByTagName("reading")[0].childNodes[0].nodeValue;
			}
		}
	}
	var value;
        var displayValue = disabledStatusMsg;
	if ((reading == "full") || (reading == "Full"))
	{
		reading = "Full";
                displayValue = fullStatusMsg;
		value = 0;
	}
	else if ((reading == "lost") || (reading == "Lost"))
	{
		reading = "Lost";
                displayValue = lostStatusMsg;
		value = 2;
	}
	else if ((reading == "degraded") || (reading == "Degraded"))
	{
		reading = "Degraded";
		displayValue = degradedStatusMsg;
		value = 1;
	}
	else // reading == "Disabled"
	{
		// value = 3;
		value = 2;
    displayValue = disabledStatusMsg;     
		
		hideElement('RedundancyJumpBar');
		hideElement('RedundancyTableSection');
		hideElement('RedundancyTableBackBar');
	}
        setDiv("redundancyStatus", displayValue);
	//insertStatusIcon('redundancyInfo', 1, statusImg[value]);
	/*
	if (document.getElementById('redundancyInfo')!=null)
	{
			document.getElementById('redundancyInfo').className = 'status_' + (trim(statusImg[value])).toLowerCase();
      return value;  
  }
	*/

	if (document.getElementById('redundancyInfoIcon')!=null)
	{
	  if (value == 3)
	  {
	      //psInsertStatusIcon('redundancyInfoIcon', 1, statusImg[(value-2)]); // Set Icon of redundancy status to 'ALERT'
				document.getElementById('redundancyInfoIcon').className = 'status_' + (trim(statusImg[value-2])).toLowerCase();
	      return value;  
		}
	  else
	  {
	      //psInsertStatusIcon('redundancyInfoIcon', 1, statusImg[value]);
				document.getElementById('redundancyInfoIcon').className = 'status_' + (trim(statusImg[value])).toLowerCase();
	      return value;        
	  }
	}
}
xmlThresholdList = 'thresholdSensorList';
// 06/10/08 rbj: Edited to resolve PR27820: Fan Redundancy is not displayed.
//               Removed a bunch of commented out code (that dien't work) &
//               replaced with a call to refreshRedundancy(xmlDoc).
function refreshThresholdDataCallback(xmlDoc) 
{
	if( xmlDoc != null) 
	{
		var pwOn = getXMLValue(xmlDoc, powerOn);
		if (pwOn == "") {
			showPowerOffPanel();
		}
		else {
		var redundancyStatus = refreshRedundancy(xmlDoc);		// Go process the values for the Fan Redundancy table
	
	        var row  = new Array();
			var list = getXMLValue(xmlDoc, xmlThresholdList) ;
			globalStatus = "Normal";
			if( list != null  && typeof list == "object" )
			{
				var item = list.getElementsByTagName(xmlItem);
				// Process the XML Snippet row by row
				for (var i = 0; i < item.length; i++) {
					// Populate the cells
					entry = item[i];

					row[0] = new Cell(Cell.BLANK);

					var sensorStatus = entry.getElementsByTagName("sensorStatus")[0].childNodes[0].nodeValue;
					row[1] = new Cell(Cell.CONTENT, '<span class="status_' + convert((trim(sensorStatus)).toLowerCase()) + '">&nbsp;</span>', 'center');

					
					var name1 = entry.getElementsByTagName("name")[0].childNodes[0].nodeValue;
					row[2] = new Cell(Cell.CONTENT, name1, 'left');
					
					reading = entry.getElementsByTagName("reading")[0].childNodes[0].nodeValue;
					
					//Fix for DF495395: Gui can not retrieve any Information under Power->Temperature tab
					//units = " " + entry.getElementsByTagName("units")[0].childNodes[0].nodeValue;
					
					var nlUnitChildNodes=entry.getElementsByTagName("units")[0].childNodes;
					var units="";
					if(null != nlUnitChildNodes && nlUnitChildNodes.length >0)
						units=" " +nlUnitChildNodes[0].nodeValue;
					
					row[3] = new Cell(Cell.CONTENT, reading + units, 'left');
					//row[5] = new Cell(Cell.BLANK);
					minWarning = entry.getElementsByTagName("minWarning")[0].childNodes;
					if (minWarning.length == 0)
						minWarning = "[N/A]";
					else
						minWarning = minWarning[0].nodeValue;
					min_warning = isNaN(minWarning) ? minWarning : minWarning + units;
					row[4] = new Cell(Cell.CONTENT, min_warning, 'left');
					//row[7] = new Cell(Cell.BLANK);
					maxWarning = entry.getElementsByTagName("maxWarning")[0].childNodes;
					if (maxWarning.length == 0)
						maxWarning = "[N/A]";
					else
						maxWarning = maxWarning[0].nodeValue;
					max_warning = isNaN(maxWarning) ? maxWarning : maxWarning + units;
					row[5] = new Cell(Cell.CONTENT, max_warning, 'left');
					//row[9] = new Cell(Cell.BLANK);
					minFailure = entry.getElementsByTagName("minFailure")[0].childNodes;
					if (minFailure.length == 0)
						minFailure = "[N/A]";
					else
						minFailure = minFailure[0].nodeValue;
					min_failure = isNaN(minFailure) ? minFailure : minFailure + units;
					row[6] = new Cell(Cell.CONTENT, min_failure, 'left');
					//row[11] = new Cell(Cell.BLANK);
					maxFailure = entry.getElementsByTagName("maxFailure")[0].childNodes;
					if (maxFailure.length == 0)
						maxFailure = "[N/A]";
					else
						maxFailure = maxFailure[0].nodeValue;
					max_failure = isNaN(maxFailure) ? maxFailure : maxFailure + units;
					row[7] = new Cell(Cell.CONTENT, max_failure, 'left');

					row[8] = new Cell(Cell.BLANK);
				
					appendTableRow("probes_table", row);
					
					switch (globalStatus)
					{
						case "Normal":
							globalStatus = sensorStatus;                        		
							break;
						case "Warning":
							if ("Critical" == sensorStatus) {
								globalStatus = "Critical";
							}
							break;
						case "Critical":
							break;
					}
				}
			}
                        // DF263013 Overall fan status on GUI should only check the fan redundancy status
                        /*
                         * if (redundancy_status == FULL)
                              {
                                  Display Normal icon;
                              } 
                              else if (redundancy_status == LOST)
                              {
                                  Display Critical icon;
                              }
                              else
                              {
                                  // redundancy status is DISABLED
                                  if (any_fan_sensor == FAILED)
                                  {
                                     Display Critical icon;
                                  }
                                  else if (any_fan_sensor == WARNING)
                                  {
                                     Display Warning icon;
                                  }
                                  else
                                  {
                                     Display Normal icon;
                                  }
                              }
                         */
                        
                        if (redundancyStatus == Status.FAILED)//LOST
                              globalStatus = "Critical";
                        else if (redundancyStatus == Status.OK)//FULL
                              globalStatus = "Normal";
                        
			//insertStatusIcon('probesInfo', 1, stringToIcon(globalStatus));
			//document.getElementById('probesInfo').className = 'status_' + (trim(globalStatus)).toLowerCase();
			showContentPanel();
		}
	}
	else {
		showContentPanel();
	}
}

xmlDiscreteList = 'discreteSensorList';

function refreshDiscreteDataCallback(xmlDoc) 
{
	if (xmlDoc!=null) {
	//	showErrorMessage("refreshDiscreteDataCallback - No XML document.");
	//	return;
	//} 
	//else 
	//{
		//Extract data from the returned XML...
		var pwOn = getXMLValue(xmlDoc, powerOn);
		if (pwOn == "") {
			showPowerOffPanel();
		}
		else {
	        var globalStatus = "Normal";
			var list = getXMLValue(xmlDoc, xmlDiscreteList) ;
	
			if( list != null && typeof list == "object" ) {
	        	var item = list.getElementsByTagName(xmlItem);
	            if( item != null) {
	            	//Process the XML Snippet row by row
	                for (var i = 0; i < item.length; i++) {
						// Populate the cells
						var entry = item[i];
						var row = new Array();

						row[0] = new Cell(Cell.BLANK);

						var sensorStatus = entry.getElementsByTagName("sensorStatus")[0].childNodes[0].nodeValue;
						row[1] = new Cell(Cell.CONTENT, '<span class="status_' + convert((trim(sensorStatus)).toLowerCase()) + '">&nbsp;</span>', 'center');

						var name = entry.getElementsByTagName("name")[0].childNodes[0].nodeValue;
						row[2] = new Cell(Cell.CONTENT, name, 'left');

						var reading = entry.getElementsByTagName("reading")[0].childNodes[0].nodeValue;
						row[3] = new Cell(Cell.CONTENT, reading, 'left');

						row[4] = new Cell(Cell.BLANK);

						appendTableRow("probes_table", row);
						switch (globalStatus) {
						case "Normal":
							globalStatus = sensorStatus;                        		
							break;
						case "Warning":
							if ("Critical" == sensorStatus) {
								globalStatus = "Critical";
							
							}
							break;
						case "Critical":
							break;
						}
					}
				}
			}
                        
			//insertStatusIcon('probesInfo', 1, stringToIcon(globalStatus));
			//document.getElementById('probesInfo').className = 'status_' + (trim(globalStatus)).toLowerCase();
			showContentPanel();
		}
	}
	else {
		showContentPanel();
	}
}

xmlPSList = 'psSensorList';
/*******************************************************************************
 *  History: 
 *	Fanlu Kong: Add handling for mcCave Redundancy Policy drop dwon window, Jan 2009.
 *	Fanlu Kong: This fix is based on Dell CR281791 [ttid: 1045,310939] - Mar 3, 2009
 *              More generally: when PS Redundancy sensor is enabled, the overall status 
 *              indicator (green/yellow/red) should track the PS Redundancy indicator.  
 *              When the PS Redundancy sensor is disable, the overall status indicator 
 *              should track the "worst" individual PS status sensor, as it does today.  
 *              This should support the desired behavior on McCave while not changing 
 *              the existing behavior on other platforms.	
 * *******************************************************************************/

function refreshPSDataCallback(xmlDoc) 
{

	//hideElement('RedundancyTableSection');
	if (xmlDoc!=null) 
	{
		var pwOn = getXMLValue(xmlDoc, powerOn);
		setPSRedundancyStatus(xmlDoc);

	    
			var list = getXMLValue(xmlDoc, xmlPSList);
			if (list != null  && typeof list == "object")
			{
				clearTableRows('probes_table',2);

				var item = list.getElementsByTagName(xmlItem);
				//Process the XML Snippet row by row
			if (item.length ==0)
			{
				//insert blank row
				var row = new Array();
				row[0] = new Cell(Cell.BLANK);
				row[1] = new Cell(Cell.BLANK);
				row[2] = new Cell(Cell.BLANK);
				row[3] = new Cell(Cell.BLANK);
				row[4] = new Cell(Cell.BLANK);
				row[5] = new Cell(Cell.BLANK);
				row[6] = new Cell(Cell.BLANK);
				row[7] = new Cell(Cell.BLANK);
				row[8] = new Cell(Cell.BLANK);
				row[9] = new Cell(Cell.BLANK);
				appendTableRow("probes_table", row);

			}
			  else
			  {
				for (var i = 0; i < item.length; i++)
				{
					// Populate the cells
					var entry = item[i];
					var row = new Array();
					row[0] = new Cell(Cell.BLANK);

					var sensorHealth = entry.getElementsByTagName("sensorHealth")[0].childNodes[0].nodeValue;
					row[1] = new Cell(Cell.ICON, valueToIcon(sensorHealth), 'center');

					loc = entry.getElementsByTagName("name");
					if (loc.length > 0 && loc[0].childNodes.length > 0) {
					loc = loc[0].childNodes[0].nodeValue;
						row[2] = new Cell(Cell.CONTENT, loc, 'left');

					}
					else
					{
						row[2] = new Cell(Cell.BLANK);

					}

					var sensorStatus = entry.getElementsByTagName("sensorStatus");
					if (sensorStatus.length > 0 && sensorStatus[0].childNodes.length > 0) 
					{
						sensorStatus = sensorStatus[0].childNodes[0].nodeValue;
						var temp = sensorStatus.split("|");
						var sensorStatusVals = "";
						for(var j=0;j<temp.length;j++)
						{
							var status = convertPSStatus(temp[j]);
							if (sensorStatusVals == "")
								sensorStatusVals = status;
							else
								sensorStatusVals +=" | "+ status;
							
						}	 

						row[3] = new Cell(Cell.CONTENT, sensorStatusVals, 'left');
					}
					else
					{
						row[3] = new Cell(Cell.BLANK);

					}


					inputWattage = entry.getElementsByTagName("inputWattage");
					if (inputWattage.length > 0 && inputWattage[0].childNodes.length > 0) {
						inputWattage = inputWattage[0].childNodes[0].nodeValue;
						row[4] = new Cell(Cell.CONTENT, inputWattage, 'left');

					}
					else {
						row[4] = new Cell(Cell.BLANK);

					}
					maxWattage = entry.getElementsByTagName("maxWattage");
					if (maxWattage.length > 0 && maxWattage[0].childNodes.length > 0) {
						maxWattage = maxWattage[0].childNodes[0].nodeValue;
						row[5] = new Cell(Cell.CONTENT, maxWattage, 'left');

					}
					else {
						row[5] = new Cell(Cell.BLANK);

					}

					fwVersion = entry.getElementsByTagName("fwVersion");
					if (fwVersion.length > 0 && fwVersion[0].childNodes.length > 0) {
						fwVersion = fwVersion[0].childNodes[0].nodeValue;
						row[6] = new Cell(Cell.CONTENT, fwVersion, 'left');
					}
					else {
						row[6] = new Cell(Cell.BLANK);
					}

					present = entry.getElementsByTagName("partno");
					if (present.length > 0 && present[0].childNodes.length > 0) {
						present = present[0].childNodes[0].nodeValue;
						row[7] = new Cell(Cell.CONTENT, present, 'left');

					}
					else {
						row[7] = new Cell(Cell.BLANK);

					}

					type = entry.getElementsByTagName("type");
					if (type.length > 0 && type[0].childNodes.length > 0) {
						type = type[0].childNodes[0].nodeValue;
						row[8] = new Cell(Cell.CONTENT, type, 'left');

					}
					else {
						row[8] = new Cell(Cell.BLANK);

					}				
			
					
					row[9] = new Cell(Cell.BLANK);					
					
					appendTableRow("probes_table", row);

				}
			    }	
			}

			showContentPanel();
		
	}
	else {
		showContentPanel();
	}
}

function refreshThreshold(data) 
{
	showProgressPanel();
	refreshThresholdData(data);
}

function refreshDiscrete(data) 
{
	showProgressPanel();
	refreshDiscreteData(data);
}

function refreshPS(data) 
{
	showProgressPanel();
	refreshPSData(data);
}

function showPowerOffPanel()
{
    hideElement( 'progressScreen' );
    showInlineElement( 'powerOffScreen' );
}

/*******************************************************************************
 *	This Function is for mcCave Platform. Do no display Power Supply Redundancy 
 *  if the retune value of 'redundancy' from XML is '0', 	which cover 2 cases: 
 *  it s not mcCave Platform or the number of power supply is not equal to 2.
 *  Input: XML Doc 
 *	Output: 1-Redundancy Police is set. 2-No Redundancy
 *  Fanlu Kong: Intial draft,Jan 2009.
 *******************************************************************************/
function psRedundancyPoliceDisplayCheck(xmlDoc)
{
	var psRedundancyPolicySetting = getXMLValue(xmlDoc, "redundancyPolicy");
	psRedundancyPolicySetting = psRedundancyPolicySetting & 0xF;
	
	psCapability = getXMLValue(xmlDoc, "redundancyCapability");
	psCapability = psCapability & 0xF;
	
	if (psCapability == 0 || psRedundancyPolicySetting == 0)
	{
		hideElement( 'redundancyPolicyScreen');
		hideElement( 'redundancyPolicyJumpBar');
	}
	else
	{
		showInlineElement( 'redundancyPolicyJumpBar' );
		showInlineElement( 'redundancyPolicyScreen' );
		psRedundandPolicyListUpdate(psCapability,psRedundancyPolicySetting);		 
	}
	
	//psRedundancyPolicySetting = trim(psRedundancyPolicySetting);
	
	
	return psRedundancyPolicySetting	
}
function psRedundandPolicyListUpdate(capability,redundPolicy)
{
	var redundantMsg					=EntityDecode(jsesp_redundantMsg);
	var noneRedundantMsg				=EntityDecode(jsesp_noneRedundantMsg);
	var applyBtnElement = document.getElementById("mainSubmit");
	var selectBox = document.dataarea.id_psRedundPolicyOpt;
	var listText;
//	var testValue_1;
//	var testValue_2;

//	testValue_1 = redundPolicy & 0x0F;
//	testValue_2 = redundPolicy & 0xFFF0;
	
	removeAllOptions(selectBox);
		
	if(capability == 1 || capability == 2 ||capability == 4 || capability == 8)
	{
		if (redundPolicy == 1){
			listText = noneRedundantMsg;
		}
//		else if ((testValue_1 == 0) && (testValue_2 !=0)){
//			listText =reservedMsg;
//		}
		else{
			listText = redundantMsg;
		}
		psRedundantPolicyDisplayHandler(selectBox, listText, redundPolicy, 1, applyBtnElement, 1);
	}
	else{
		
		if (redundPolicy == 1)
		{
			addOption(selectBox,redundPolicy, noneRedundantMsg,1);
			addOption(selectBox,redundPolicy, redundantMsg, 0);
		}
		else 
		{
			addOption(selectBox,redundPolicy, noneRedundantMsg,0);
			addOption(selectBox,redundPolicy, redundantMsg, 1);
		}
		
		psCurrentPolicyIdxSelected = document.getElementById('id_psRedundPolicyOpt').selectedIndex;
	}
}
	function psRedundantPolicyDisplayHandler(selectbox, text, value, flagSelected, btnElement, btnDisable)
	{
		addOption(selectbox, value, text, flagSelected);
		if (btnDisable == true)
		{
			btnElement.disabled=true;
			//btnElement.className = "data-area-button-disabled";
		}
	}



function removeAllOptions(selectbox)
	{
		var i;
		for(i=selectbox.options.length-1;i>=0;i--)
		{
			//selectbox.options.remove(i);
			selectbox.remove(i);
		}
	}
	
function addOption(selectbox, value, text, flagSelected )
	{
		var optn = document.createElement("OPTION");
		optn.text = text;
		optn.value = value;
		if(flagSelected == 1)
		{
			optn.setAttribute("selected","selected");
		}

		
		selectbox.options.add(optn);
	}

/*******************************************************************************
 *	This Function is for mcCave Platform. Refresh the individual PS, Redundancy  
 *  Status and Redundancy Policy value, which are read from backend. 
 *  Called psRedundancePolicySubmit() function in 'listpowersup.html'
 *  Input: None 
 *	Output: None
 *  Fanlu Kong: Intial draft,Jan 2009.
 *******************************************************************************/

function psPSDataLoad()
{
	var psloadPSDataRefresh = 'data?get=powerSupplies,psRedundancy,psRedundancyPolicy';
	refreshPS(psloadPSDataRefresh);
}

	
