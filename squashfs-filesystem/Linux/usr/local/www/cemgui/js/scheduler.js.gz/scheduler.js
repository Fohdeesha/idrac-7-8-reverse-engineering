var AutoUpdate = {
	clearSet:'',
    enableDisableChkBox: function(e){
        if (!($(e).checked)) {
            this.disableAllScheduler();
        }
        else {
            this.enableAllScheduler();
        }
		Scheduler.setEnableDisableSch($(e).checked);
    },
    disableAllScheduler: function(){
        $('scheduleUpdateRadio').disabled = "disabled";
        $('scheduleUpdateRebootRadio').disabled = "disabled";
        $('sNetworkRadio').disabled = "disabled";
        $('sFTPradio').disabled = "disabled";
		$('atftp_rd').disabled = "disabled";
		$('ahttp_rd').disabled = "disabled";
        var inputFields = $('sNetworkSettings').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
        inputFields.each(function(inputField){
            inputField.disabled = true;
        });
        
    },
    enableAllScheduler: function(){
        $('scheduleUpdateRadio').disabled = "";
        $('scheduleUpdateRebootRadio').disabled = "";
        $('sNetworkRadio').disabled = "";
        $('sFTPradio').disabled = "";
		$('atftp_rd').disabled = "";
		$('ahttp_rd').disabled = "";
        
        var inputFields = $('sNetworkSettings').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
        inputFields.each(function(inputField){
            inputField.disabled = false;
        });
    },
    selectedTab: function(e){
		
        if (e == "default") {
			$('alertContent').style.display = 'none';
            $('defaultTabDiv').style.display = "";
            $('schedulerDiv').style.display = "none";
            $('defaultTab_id').className = "tab_button_emphasized";
            $('schedulerTab_id').className = "tab_button";            
            $('btnUpload').style.display = "";
            $('updateDetailsTbl_id').style.display = '';
            $('clearSetBtn').style.display = "none";
            $('schApplyBtn').style.display = "none";
        }
        else {
            $('defaultTabDiv').style.display = "none";
            $('schedulerDiv').style.display = "";
            $('defaultTab_id').className = "tab_button";
            $('schedulerTab_id').className = "tab_button_emphasized";            
            $('btnUpload').style.display = "none";
            $('updateDetailsTbl_id').style.display = 'none'
            $('clearSetBtn').style.display = "";
            $('schApplyBtn').style.display = "";
            document.getElementById('scheduleUpdateRebootRadio').checked = true ;
			schedulerURI = schedulerBackupURI;
		AutoUpdate.getState();
	
        }
		
		//this.enableDisableChkBox('enableSchedulerChkBox');
    },
	repoSel:function(e){
		if(e=="ftp"){
		    $('sHttpTable').style.display = "none";
			$('sNtkShareTable').style.display="none";			
			$('sFtpTable').style.display="";
			$('sTftpTable').style.display = "none";
			this.proxySet();			
		}else if(e == "tftp") {
		    $('sHttpTable').style.display = "none";
			$('sNtkShareTable').style.display="none";
			$('sFtpTable').style.display="none";
            $('sTftpTable').style.display = "";			
		} else if(e == "http") {
			$('sNtkShareTable').style.display="none";
			$('sFtpTable').style.display="none";
            $('sTftpTable').style.display = "none";			
			$('sHttpTable').style.display = "";
			this.httpProxySet();
		} else {
		    $('sHttpTable').style.display = "none";
			$('sNtkShareTable').style.display="";
			$('sFtpTable').style.display="none";			
			$('sTftpTable').style.display = "none";
		}
	},
	httpProxySet:function(){
		var flag = $('ahttp_Proxy').checked;
		var inputFields = $('httpProxySetDiv').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
        inputFields.each(function(inputField){
            inputField.disabled = !flag;
        });
		$('ahttp_ProxyType').disabled = !flag;
	},	
	getState:function(){
		Scheduler.clearAllDay();
		progressBar.show(true);
		URL = autoUpdate;				
		_param = '';
        _methodType = 'get';
		loadRESTdata();		
	},
	changeStateChkBox:function(_state){		
		if (_state.toLowerCase() == "enabled") {
			$('enableSchedulerChkBox').checked = true;
			this.enableAllScheduler();
			this.getRecuJobSch();
		}
		else {
			$('enableSchedulerChkBox').checked = false;
			this.disableAllScheduler();
			Scheduler.getiDRACtime();
			progressBar.hide(); 
			this.privilegeCheck();
		}	
	},
	getRecuJobSch:function(){
		schedulerURI = schedulerURI+'?jobtype=autoupdate';	
		URL  = schedulerURI;			
		_param = '';
        _methodType = 'get';
		loadRESTdata();
	},
	applySchedule:function()
	{	
		var _bodyTxt='{'
		if($('sNetworkRadio').checked){
			_bodyTxt+= AutoUpdate.networkLocSet();
		} else if($('atftp_rd').checked) {
            _bodyTxt += AutoUpdate.tftpLocSet();
        } else if($('ahttp_rd').checked) {		 
		    _bodyTxt += AutoUpdate.httpLocSet();
		} else {
			_bodyTxt+= AutoUpdate.ftpLocSet();
		}		
		
		if($('scheduleUpdateRadio').checked)
			_bodyTxt+='"applyreboot":"0",'
		else
			_bodyTxt+='"applyreboot":"1",'
		_bodyTxt+='"time":"'+$('shour').value+':'+$('smin').value+'",'
		if(Scheduler.recurrencePattern=="daily" || Scheduler.recurrencePattern==""){			
			_bodyTxt+='"repeat":"'+$('dailyTI').value+'",'
			 _bodyTxt+='"dayofmonth":"*",'
        	_bodyTxt+='"weekofmonth":"*",'
        	_bodyTxt+='"dayofweek":"*",'
		}else if (Scheduler.recurrencePattern == "weekly") {				
				_bodyTxt+='"dayofmonth":"*",'
            	_bodyTxt+='"weekofmonth":"*",'
				_bodyTxt+='"repeat":"'+$('weEveryTI').value+'",'
				var dayTmp = '';
				if($('sun').checked==true)dayTmp += "sun,";
				if($('mon').checked==true)dayTmp += "mon,";
				if($('tue').checked==true)dayTmp += "tue,";
				if($('wed').checked==true)dayTmp += "wed,";
				if($('thu').checked==true)dayTmp += "thu,";
				if($('fri').checked==true)dayTmp += "fri,";
				if($('sat').checked==true)dayTmp += "sat,";	
				dayTmp= dayTmp.substring(0,dayTmp.length-1);
				_bodyTxt += '"dayofweek":"'+dayTmp+'",';												
		}else {				
				if ($('domRadio').checked) {
					_bodyTxt += '"dayofmonth":"' + $('dayOfMonthTI').value + '",';
					_bodyTxt += '"repeat":"' + $('repeatMonth1TI').value + '",';
					_bodyTxt += '"weekofmonth":"*",'
					_bodyTxt += '"dayofweek":"*",'					
				}
				else {					
					_bodyTxt += '"weekofmonth":"'+$('sMonth').options[$('sMonth').selectedIndex].value+'",'; 
					_bodyTxt += '"dayofweek":"'+$('sMonthWeek').options[$('sMonthWeek').selectedIndex].value+'",';					
					_bodyTxt += '"repeat":"' + $('repeatMonth2TI').value + '",';
					_bodyTxt+='"dayofmonth":"*",'
				}
					
				
		}
		
		
		_bodyTxt+='"jobtype":"autoupdate"'
		_bodyTxt+='}'
		URL  = schedulerURI;			
		_param = _bodyTxt;
        _methodType = 'post';
		progressBar.show(true);
		loadRESTdata();
	
	},
	setExistSch:function(e){
		Scheduler.getiDRACtime();
		if (e.sharetype != null && e.sharetype.toLowerCase() != "ftp" && e.sharetype.toLowerCase() != "tftp" && e.sharetype.toLowerCase() != "http") {
			$('sNetworkRadio').checked="checked";
			AutoUpdate.repoSel('ntkShare')
			$('scatalogName').value = (e.catalogname!=null&&e.catalogname.length!=0)?e.catalogname:'';
			$('sDomainName').value = (e.domain!=null&&e.domain.length!=0)?e.domain:'';
			$('sIpAddr').value =  (e.hostname!=null&&e.hostname.length!=0)?e.hostname:'';
			$('sShareName').value = (e.sharename!=null&&e.sharename.length!=0)?e.sharename:'';
			$('scatalogLocation').value = (e.sharepath!=null&&e.sharepath.length!=0)?e.sharepath:'';
			$('sUserName').value = (e.username!=null&&e.username.length!=0)?e.username:'';
					
			if (e.sharetype.toLowerCase() == "cifs") 
				$('sCIFSradio').checked = "checked";
			else {
				$('sNFSradio').checked = "checked";
				$('sDomainName').disabled="disabled";
				$('sUserName').disabled="disabled";
				$('sPassword').disabled="disabled";
			}
		}else if(e.sharetype.toLowerCase() == "ftp") {
			$('sFTPradio').checked="checked";
			$('sFAddress').value = (e.hostname!=null&&e.hostname.length!=0)?e.hostname:'';
			$('sFuserName').value = (e.username!=null&&e.username.length!=0)?e.username:'';
			$('sFpassword').value = (e.password!=null&&e.password.length!=0)?e.password:'';
			$('sFcatalogFile').value = (e.catalogname!=null&&e.catalogname.length!=0)?e.catalogname:'';	
			//use sharename field for catalog location for FTP,TFTP and HTTP
			$('sFcatalogLoc').value = (e.sharename!=null&&e.sharename.length!=0)?e.sharename:'';		
			if(e.proxyhostname!=null){
				$('sFPenableServerCK').checked = true;
				 this.proxySet()
				 $('sFPserver').value = (e.proxyhostname!=null&&e.proxyhostname.length!=0)?e.proxyhostname:'';
				 $('sFPport').value = (e.proxyport!=null&&e.proxyport.length!=0)?e.proxyport:'';
				 $('sFPuserName').value = (e.proxyusername!=null&&e.proxyusername.length!=0)?e.proxyusername:'';
				 $('sFPpassword').value = (e.proxypassword!=null&&e.proxypassword.length!=0)?e.proxypassword:'';				 
				 for(var i=0;i<$('sFPtype').options.length;i++){
					if($('sFPtype').options[i].value==e.proxytype){
						$('sFPtype').selectedIndex=i;
						break;
					}
				}
			}
			AutoUpdate.repoSel('ftp');			
		}
		else if(e.sharetype.toLowerCase() == "tftp"){
			$('atftp_rd').checked="checked";
			AutoUpdate.repoSel('tftp');
			$('atftp_Addr').value = (e.hostname!=null&&e.hostname.length!=0)?e.hostname:'';
			$('atftp_CtlgName').value = (e.catalogname!=null&&e.catalogname.length!=0)?e.catalogname:'';
			$('atftp_CtlgLoc').value = (e.sharename!=null&&e.sharename.length!=0)?e.sharename:'';
		}
		else if(e.sharetype.toLowerCase() == "http") {
			$('ahttp_rd').checked="checked";
			AutoUpdate.repoSel('http');
			$('ahttp_Addr').value = (e.hostname!=null&&e.hostname.length!=0)?e.hostname:'';
			$('ahttp_User').value = (e.username!=null&&e.username.length!=0)?e.username:'';
			$('ahttp_Passwd').value = (e.password!=null&&e.password.length!=0)?e.password:'';
			$('ahttp_CtlgName').value = (e.catalogname!=null&&e.catalogname.length!=0)?e.catalogname:'';
			$('ahttp_CtlgLoc').value = (e.sharename!=null&&e.sharename.length!=0)?e.sharename:'';
			if(e.proxyhostname!=null){
				$('ahttp_Proxy').checked = true;
				 this.httpProxySet()
				 $('ahttp_ProxyServer').value = (e.proxyhostname!=null&&e.proxyhostname.length!=0)?e.proxyhostname:'';
				 $('ahttp_ProxyPort').value = (e.proxyport!=null&&e.proxyport.length!=0)?e.proxyport:'';
				 $('ahttp_ProxyUserName').value = (e.proxyusername!=null&&e.proxyusername.length!=0)?e.proxyusername:'';
				 $('ahttp_ProxyPasswd').value = (e.proxypassword!=null&&e.proxypassword.length!=0)?e.proxypassword:'';	 
				 for(var i=0;i<$('ahttp_ProxyType').options.length;i++){
					if($('ahttp_ProxyType').options[i].value==e.proxytype){
						$('ahttp_ProxyType').selectedIndex=i;
						break;
					}
				}
			}
		}
		$('shour').value = (e.time).split(":")[0];
		$('smin').value = (e.time).split(":")[1];	
		if(e.dayofmonth=="*" && e.weekofmonth=="*" && e.dayofweek=="*" ){
			recurrenceRadioSel('daily');
			$('recurDailyChkBox').checked = "checked";		
			$('dailyTI').value=e.repeat;				
		}else if(e.dayofmonth=="*" && e.weekofmonth=="*" && e.dayofweek.length>2 ){
			recurrenceRadioSel('weekly');
			$('weEveryTI').value = e.repeat;
			$('recurWeekChkBox').checked = "checked";
			var daySel = e.dayofweek.split(",");
			for(var i=0;i<daySel.length;i++){
				var dayName= daySel[i].toLowerCase();
                                $(dayName).checked=true;
			}
		}else if(e.dayofmonth!="*" && e.weekofmonth=="*" && e.dayofweek=="*" ){			
			recurrenceRadioSel('monthly');
			$('recurMonRadio').checked = "checked";			
			$('domRadio').checked="checked";
			$('dayOfMonthTI').value = e.dayofmonth;
			$('repeatMonth1TI').value = e.repeat;
			
		}else if(e.weekofmonth!="*" && e.dayofweek!="*" && e.dayofmonth=="*" ){
			recurrenceRadioSel('monthly');
			$('recurMonRadio').checked = "checked";
			$('domLRadio').checked="checked";								
			for(var i=0;i<$('sMonth').options.length;i++){
				if(e.weekofmonth==$('sMonth').options[i].value){
					$('sMonth').selectedIndex = i;
					break;
				}
			}		
			for(var i=0;i<$('sMonthWeek').options.length;i++){
				if(e.dayofweek==$('sMonthWeek').options[i].value){
					$('sMonthWeek').selectedIndex = i;
					break;
				}
			}
			$('repeatMonth2TI').value = e.repeat;
		}
		if(e.applyreboot != undefined && e.applyreboot != null) {
			$("scheduleUpdateRadio").checked = (e.applyreboot == 0) ? true : false;
		}
		this.privilegeCheck();
	},
	networkLocSet:function()
	{
		
		var _paramTxt = '';		
		if($('sIpAddr').value.length!=0) _paramTxt+='"hostname":"'+$('sIpAddr').value+'",'
		if($('sShareName').value.length!=0) _paramTxt+='"sharename":"'+$('sShareName').value+'",'
		if($('sDomainName').value.length!=0) _paramTxt+='"domain":"'+$('sDomainName').value+'",'
		if($('sUserName').value.length!=0){
			//Fix for BITS182383 
			if($('sUserName').value.trim().indexOf("/")!=-1)
				_paramTxt+='"username":"'+$('sUserName').value.trim().replace(/\//g,'\\\\')+'",'
			else
				_paramTxt+='"username":"'+$('sUserName').value.trim().replace(/\\/g,'\\\\')+'",'
		}		
		if($('sPassword').value.length!=0) _paramTxt+='"password":"'+$('sPassword').value+'",'
		if($('scatalogLocation').value.length!=0) _paramTxt+='"sharepath":"'+$('scatalogLocation').value+'",'		
		if($('scatalogName').value.length!=0) _paramTxt+='"catalogname":"'+$('scatalogName').value+'",'
		if($('sCIFSradio').checked)
			_paramTxt+='"sharetype":"cifs",'
		else
			_paramTxt+='"sharetype":"nfs",'
		return _paramTxt;
		
	},
	ftpLocSet:function()
	{
		var _paramTxt = '';	
		if($('sFAddress').value.length!=0) _paramTxt+='"hostname":"'+$('sFAddress').value+'",';
		if($('sFuserName').value.length!=0) _paramTxt+='"username":"'+$('sFuserName').value+'",';
		if($('sFpassword').value.length!=0) _paramTxt+='"password":"'+$('sFpassword').value+'",';
		if($('sFcatalogFile').value.length!=0) _paramTxt+='"catalogname":"'+$('sFcatalogFile').value+'",';
		if($('sFcatalogLoc').value.length!=0) _paramTxt+='"sharename":"'+$('sFcatalogLoc').value+'",';
		_paramTxt+='"sharetype":"ftp",';
		if($('sFPenableServerCK').checked){			
			if($('sFPserver').value.length!=0) _paramTxt+='"proxyhostname":"'+$('sFPserver').value+'",';
			if($('sFPport').value.length!=0) _paramTxt+='"proxyport":"'+$('sFPport').value+'",';
			if($('sFPuserName').value.length!=0) _paramTxt+='"proxyusername":"'+$('sFPuserName').value+'",';
			if($('sFPpassword').value.length!=0) _paramTxt+='"proxypassword":"'+$('sFPpassword').value+'",';
			_paramTxt+='"proxytype":"'+$('sFPtype').value+'",';
		}
		return _paramTxt;
	},
	tftpLocSet: function() {
	    var _paramTxt = '';
		var shareTFTP = "tftp";
		_paramTxt += '"sharetype":"'+shareTFTP+'",';
		if($('atftp_Addr').value.length!=0) _paramTxt+='"hostname":"'+$('atftp_Addr').value+'",';
		if($('atftp_CtlgLoc').value.length!=0) _paramTxt+='"sharename":"'+$('atftp_CtlgLoc').value+'",';
		if($('atftp_CtlgName').value.length!=0) _paramTxt+='"catalogname":"'+$('atftp_CtlgName').value+'",';
		return _paramTxt;
	},
	httpLocSet: function() {
	    var _paramTxt = '';
		var shareHTTP = "http";
		_paramTxt+= '"sharetype":"'+shareHTTP+'",';
		if($('ahttp_Addr').value.length !=0) _paramTxt+='"hostname":"'+$('ahttp_Addr').value.trim()+'",';
		if($('ahttp_User').value.length !=0) _paramTxt+='"username":"'+$('ahttp_User').value.trim()+'",';
		if($('ahttp_Passwd').value.length !=0) _paramTxt+='"password":"'+$('ahttp_Passwd').value.trim()+'",';
		if($('ahttp_CtlgLoc').value.length !=0) _paramTxt+='"sharename":"'+$('ahttp_CtlgLoc').value.trim()+'",';
		if($('ahttp_CtlgName').value.length !=0) _paramTxt+='"catalogname":"'+$('ahttp_CtlgName').value.trim()+'",';

		if($('ahttp_Proxy').checked){
		    _paramTxt+= '"proxySupport": 0,';
		    if($('ahttp_ProxyServer').value.length !=0) _paramTxt+='"proxyhostname":"'+$('ahttp_ProxyServer').value.trim()+'",';
		    if($('ahttp_ProxyPort').value.length !=0) _paramTxt+='"proxyport":"'+$('ahttp_ProxyPort').value.trim()+'",';
		    if($('ahttp_ProxyUserName').value.length !=0) _paramTxt+='"proxyusername":"'+$('ahttp_ProxyUserName').value.trim()+'",';
			if($('ahttp_ProxyPasswd').value.length !=0) _paramTxt+='"proxypassword":"'+$('ahttp_ProxyPasswd').value.trim()+'",';
			if($('ahttp_ProxyType').value.length !=0) _paramTxt+='"proxytype":"'+$('ahttp_ProxyType').value.trim()+'",';
		}
		return _paramTxt;	
	},
	proxySet:function(){
		var flag = $('sFPenableServerCK').checked;
		var inputFields = $('sProxySetDiv').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
        inputFields.each(function(inputField){
            inputField.disabled = !flag;
        });		
		$('sFPtype').disabled = !flag;
	},	
	clearSettings:function()
	{
		if(!this.validateField()){
			return;
		}
		if (top.CAN_EXE_CMDS) {
			progressBar.show(true);
			var _bodyTxt = '{"action":"clear","jobtype":"autoupdate"}'
			URL = schedulerURI;
			_param = _bodyTxt;
			_methodType = 'put';
			this.clearSet = true;
			loadRESTdata();
		}else{
			$('modalDialogError').className = "error_modal";
			$('error_icon').className="critical";
			var msgObj = Localization.getLocaleMessageForID('RAC0506', "Storage");					
			modalError(msgObj.id+": "+msgObj.Message  + ' ' + msgObj.ResponseAction);
		}
	},
	enableSettings:function()
	{
		progressBar.show(true);
		var _bodyTxt='{"action":"enable","jobtype":"autoupdate"}' 
		URL  = schedulerURI;			
		_param = _bodyTxt;
        _methodType = 'put';
		this.clearSet=false;
		loadRESTdata();	
	},
	testNtrkConnection:function(){
		progressBar.show(true);
		_methodType = 'get';
		var testconn_username = $('sDomainName').value == "" ? ($('sUserName').value.trim().replace(/\//g,'\\')) : $('sUserName').value.trim();
		var bodyMsg = "username="+testconn_username;		
		bodyMsg += "&password="+($('sPassword').value.trim());
		bodyMsg += "&domain_name="+($('sDomainName').value.trim());
		bodyMsg += "&ipaddress="+($('sIpAddr').value.trim());
		bodyMsg += "&sharename="+($('sShareName').value.trim());
		
		
		if($('sCIFSradio').checked)
			bodyMsg += "&accesstype=2"
		else
			bodyMsg += "&accesstype=0"
		
		
		testAppendURI = networkTestURL + "/share?"+bodyMsg;				
		URL = testAppendURI;
        loadRESTdata();
	},
	clearJobAndFields:function(){		
		if ($('clearSetBtn').className == "container_button_disabled") {
			return;
		}
		Scheduler.clearAllDay();	
		Scheduler.isclearSetSel = true;
		$('enableSchedulerChkBox').checked=false;
		
		
		
		var inputFields = $('sNetworkSettings').select('input[type=text]', 'input[type=password]');
        inputFields.each(function(inputField){
            inputField.value = '';
        });
		
		var inputFields = $('sProxySetDiv').select('input[type=text]', 'input[type=password]');
        inputFields.each(function(inputField){
            inputField.value = '';
        });
		 
		$('sFPtype').selectedIndex=0;
		$('sMonth').selectedIndex=0; 
		$('sMonthWeek').selectedIndex=0;		
		$('shour').value='';
		$('smin').value='';
		$('domRadio').checked = "checked";		
		$('recurDailyChkBox').checked = "checked";
		recurrenceRadioSel('daily');
		$('scheduleUpdateRadio').checked = "checked";
		$('sCIFSradio').checked = "checked";
		$('sNetworkRadio').checked = "checked";
		$('sFPenableServerCK').checked = false;	
		
		
		var inputFields = $('sftpSetDiv').select('input[type=text]', 'input[type=password]');
        inputFields.each(function(inputField){
            inputField.value = '';
        });
		AutoUpdate.repoSel('ntkShare');		
		this.clearSettings();
		this.disableAllScheduler();		
		
	},
	validateField:function(){
		if(Scheduler.isclearSetSel){
			return true;
		}	
		if(lcState == "0") {
			$('error_icon').className="critical";
			var msgObj = Localization.getLocaleMessageForID('OSD35', "Configuration");                    
			modalError(msgObj.id+": "+msgObj.Message  + ' ' + msgObj.ResponseAction);
			return false;
		}				
		if($('sNetworkRadio').checked && $('sCIFSradio').checked && ($('sUserName').value.length==0||$('sPassword').value.length==0) ){
			$('error_icon').className="critical";
			var msgObj = Localization.getLocaleNewMessageForID('LC023');
        	modalError(msgObj.id + ": " + msgObj.Message+""+msgObj.ResponseAction);
			return false;
		}

		if (Scheduler.recurrencePattern == "weekly") {
			if(($('sun').checked==false) && ($('mon').checked==false) && ($('tue').checked==false) && ($('wed').checked==false) && ($('thu').checked==false) && ($('fri').checked==false) && ($('sat').checked==false)) {
				var msgObj = Localization.getLocaleNewMessageForID('RAC0646');
				modalError(msgObj.id + ": " + msgObj.Message+""+msgObj.ResponseAction);
				return false;
			}
		}

		if(parseInt($('dailyTI').value) < 1 || parseInt($('dailyTI').value) > 366) {
			var msgObj = Localization.getLocaleNewMessageForID('RAC0645');
			$('modalDialogError').className = "error_modal";
			$('error_icon').className="critical";
			modalError(msgObj.id + ":"+ msgObj.Message+""+msgObj.ResponseAction);
			return false;
		}
		return true;
			
	},
	privilegeCheck:function(){
		if (!top.CAN_EXE_CMDS) {				
				pageAlertMsg(Localization.getLocaleNewMessageForID('RAC0506'));
				this.disableAllScheduler();
				$('enableSchedulerChkBox').disabled = true;
				$('schApplyBtn').className = "container_button_disabled";
				$('schApplyBtn').onclick = "";
				$('clearSetBtn').className = "container_button_disabled"
				$('sLnkTestConnection').addClassName('disabled');
                $('sLnkTestConnection').href = "javascript:void(0);"
		}
	}
    
    
}
