var pdisk_Arr,vdisk_Arr,enclosure_Arr,pdiskPending_Arr,vdiskPending_Arr,enclosurePending_Arr,controllerPending_Arr;
var rowcount=0;var view_po=0;
var storage_params = {
	controller:'',
	enclosure:'name,status,requested_mode,current_mode,pending_changes',
	pdisk:'name,status,slot,hotspare',
	vdisk:'name,status,pending_status,pending_operations,pending_changes,read_policy,write_policy,disk_cache_policy,raidlevel,op_state,secured'
}
function new_adjusterrorpopupfields(_value){
	$('errorTitle').innerHTML = Localization.getLocaleStringForID("system_alert");
	if(_value == 0){
		$('a_ok_id').style.display = "";
		$('a_ok_id').href = "javascript:modalDialog.hide(\'modalDivError\', \'modalDialogError\');";
		$('a_jobcreate_id').style.display = "none";
		$('a_error_pendingops_id').style.display = "none";
		$('a_canceljob_id').style.display = "none";
	}else if(_value == 1){
		$('a_ok_id').style.display = "none";
		$('a_jobcreate_id').style.display = "";
		$('a_error_pendingops_id').style.display = "";
		$('a_canceljob_id').style.display = "";
	}else if(_value == 2){
		$('a_ok_id').style.display = "";
		$('a_ok_id').href = "javascript:modalDialog.hide(\'modalDivError\', \'modalDialogError\');";
		$('a_jobcreate_id').style.display = "none";
		$('a_error_pendingops_id').style.display = "";
		$('a_canceljob_id').style.display = "none";
	}
	modalDialog.show('modalDivError', 'modalDialogError');
}
function hideAllAlertContent(){
	$('alertContent').style.display = "none";
	$('secondAlertContent').style.display = "none";
	$('alertContent').innerHTML = '';
	$('secondAlertContent').innerHTML = '';
}
function copyStorageContent(e,p,value){ //value-1: Controller,2:Enclosure,3:Physical disks,4:Virtual disks
	if(value == 1){
		controller_Arr = new Array();controllerPending_Arr = new Array();
		for (var j in e){
			controller_Arr[j] = e[j];
			// controller_Arr[j].FQDD = j;
			controller_Arr[j].currentfqddkey = j;
			controller_Arr[j].pendingfqddkey = j.replace("|C|","|P|");
		}
		for (var k in p){
			controllerPending_Arr[k]=p[k];
			controllerPending_Arr[k].pendingfqddkey = k;
			controllerPending_Arr[k].currentfqddkey = k.replace("|P|","|C|");
		}
	}else if(value == 2){
		enclosure_Arr = new Array();enclosurePending_Arr = new Array();
		for (var j in e){
			enclosure_Arr[j] = e[j];
			enclosure_Arr[j].currentfqddkey = j;
			enclosure_Arr[j].pendingfqddkey = j.replace("|C|","|P|");
			enclosure_Arr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
		}
		for (var k in p){
			enclosurePending_Arr[k] = p[k];
			enclosurePending_Arr[k].pendingfqddkey = k;
			enclosurePending_Arr[k].currentfqddkey = k.replace("|P|","|C|");
			enclosurePending_Arr[k].adapterfqddkey = getKeyFromURI(p[k].controllers, controllerURL);
		}
	}else if(value == 3){
		pdisk_Arr = new Array();pdiskPending_Arr = new Array();
		var msgObj;
		for (var j in e){
			var isDirectDrive = ((j.split(":")[0].toLowerCase()).indexOf("direct") != -1) ? true : false;
			pdisk_Arr[j] = e[j];
			pdisk_Arr[j].currentfqddkey = j;
			pdisk_Arr[j].pendingfqddkey = j.replace("|C|","|P|");
			if(isDirectDrive){
				pdisk_Arr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
				pdisk_Arr[j].enclosurefqddkey = '';
			}else{
				pdisk_Arr[j].enclosurefqddkey = getKeyFromURI(e[j].enclosures, enclosureURL);
				msgObj = enclosure_Arr[pdisk_Arr[j].enclosurefqddkey];
				pdisk_Arr[j].adapterfqddkey = msgObj.adapterfqddkey;
			}
		}
		for (var k in p){
			pdiskPending_Arr[k] = p[k];
			pdiskPending_Arr[k].pendingfqddkey = k;
			pdiskPending_Arr[k].currentfqddkey = k.replace("|P|","|C|");
		}
	}else if(value == 4){
		vdisk_Arr = new Array();vdiskPending_Arr = new Array();
		for (var j in e){
			vdisk_Arr[j] = e[j];
			vdisk_Arr[j].currentfqddkey = j;
			vdisk_Arr[j].pendingfqddkey = j.replace("|C|","|P|");
			vdisk_Arr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
		}
		for (var k in p){
			vdiskPending_Arr[k] = p[k];
			vdiskPending_Arr[k].pendingfqddkey = k;
			vdiskPending_Arr[k].currentfqddkey = k.replace("|P|","|C|");
			vdiskPending_Arr[k].adapterfqddkey = getKeyFromURI(p[k].controllers, controllerURL);
		}
	}
}
function checkpoforallcontrollers(value){
	for(var j in controller_Arr){
		if(controller_Arr.hasOwnProperty(j)){
			if(controller_Arr[j].adapterType == 0){
				var adapterSel = j;
				processPendingOperations(adapterSel,"tbody_po_main_id");
			}
		}
	}
	if(value == 0){
		Table.clearAdvTableData($('tbody_po_main_id'));
	}

}
function processPendingOperations(controller_selected,table_id){
	var retval1=false;var retval2=false;var retval3=false;var retval4=false;
	view_po = 0;
	try{
		if(controller_selected != null && controller_selected != undefined && controller_selected != ''){
			if(controller_Arr[controller_selected] != undefined && controller_Arr[controller_selected] != null && controller_Arr[controller_selected] != ''){
				if(controller_Arr[controller_selected].supported_protocol != 0x40){
					Table.clearAdvTableData($(table_id));
					controller_Arr[controller_selected].FQDD = controller_Arr[controller_selected].currentfqddkey;
					$('span_po_devName_id').innerHTML = Localization.getLocaleStringForID("po_device_name") + ' ' +
						Conversion.getControllerName(controller_Arr[controller_selected]);
					rowcount=1;
					retval1=checkForControllerPO(controller_selected,table_id);
					retval2=checkForEnclosurePO(controller_selected,table_id);
					retval3=checkForPdiskPO(controller_selected,table_id);
					retval4=checkForVdiskPO(controller_selected,table_id);
					if(retval1 || retval2 || retval3 || retval4){
						return true;
					}else{
						return false;
					}
				}
			}
		}else{
			return false;
		}
	}catch(e){
		ErrorMessage.on500Status();
		console.log(e.message + "\n" +" In Filename "+ e.fileName +" at Line No: " +e.lineNumber);
	}
}
function checkForControllerPO(controller_selected,table_id){
	var tmpArray=new Array();var retval=false;
	var tmpCount=0;var tmpValue;
	var convControllerModeArr = [[Localization.getLocaleStringForID("convert_raid"), 1],
		[Localization.getLocaleStringForID("convert_hba"), 2]];
	var	convPatrolreadmode_Arr = [/*,[Localization.getLocaleStringForID("not_supported"), 1]*/[Localization.getLocaleStringForID("prm_disabled"), 2], [Localization.getLocaleStringForID("prm_auto"), 4], [Localization.getLocaleStringForID("prm_manual"), 8]];
	var convPatrolreadUnconfiguredAreas_Arr = [[Localization.getLocaleStringForID("prua_disabled"), 2],[Localization.getLocaleStringForID("prua_enabled"), 4]];
	var	convCheckconsistencymode_Arr = [/*[Localization.getLocaleStringForID("not_supported"), 0],*/[Localization.getLocaleStringForID("ccm_normal"), 1], [Localization.getLocaleStringForID("ccm_stop_on_error"), 2]];
	var convForeignConfig_Arr = [[Localization.getLocaleStringForID("efci_disabled"), 1],[Localization.getLocaleStringForID("efci_enabled"), 2]];
	var	convPatrolreadState_Arr = [[Localization.getLocaleStringForID("prs_start"), 0x40],[Localization.getLocaleStringForID("prs_running"), 0x20], [Localization.getLocaleStringForID("prs_stopped"), 0x10]];
	var convPatrolreadStateOptions_Arr = [[Localization.getLocaleStringForID("action"), 0xFF],[Localization.getLocaleStringForID("start_patrol_read"), 0x40],/*[Localization.getLocaleStringForID("running"), 0x20],*/ [Localization.getLocaleStringForID("stop_patrol_read"), 0x10]];
	var	convSecStatus_Arr = [[Localization.getLocaleStringForID("unknown"), 0],[Localization.getLocaleStringForID("encryption_capable"), 1], [Localization.getLocaleStringForID("security_key_assigned"), 2]];
	var	convEncryMode_Arr = [[Localization.getLocaleStringForID("none"), 0],[Localization.getLocaleStringForID("supported_with_lkm"), 1], [Localization.getLocaleStringForID("supported_with_dkm"), 2],[Localization.getLocaleStringForID("supported_with_dkm_pending"), 3]];
	var	convBatteryLearnMode_Arr = [[Localization.getLocaleStringForID("blm_setting_auto"), 1], [Localization.getLocaleStringForID("blm_setting_warn"), 2],[Localization.getLocaleStringForID("blm_setting_disabled"), 3]];
	var	convLBSet_Arr = [[Localization.getLocaleStringForID("lbm_set_to_auto"), 1], [Localization.getLocaleStringForID("lbm_disabled"), 2]];
	var	convCopyback_Arr = [[Localization.getLocaleStringForID("copybm_on"), 1], [Localization.getLocaleStringForID("copybm_on_smart_error"), 2],[Localization.getLocaleStringForID("copybm_off"), 3]];
	var	securityKeyOptions_Arr = [[Localization.getLocaleStringForID("action"), 0xFF],[Localization.getLocaleStringForID("create_security_key"), 1], [Localization.getLocaleStringForID("modify_security_key"), 2],[Localization.getLocaleStringForID("delete_security_key"), 3]];
	for (var j in controllerPending_Arr){
		if(controllerPending_Arr.hasOwnProperty(j) && (controller_selected == controllerPending_Arr[j].currentfqddkey) && (controllerPending_Arr[j].pending_changes)){
			var device_type = Localization.getLocaleStringForID("controller");
			var cKey = controllerPending_Arr[j].currentfqddkey;
			var adapterName;
			if(controller_Arr != undefined && controller_Arr != null){
				if(controller_Arr[cKey] != undefined && controller_Arr[cKey] != null && controller_Arr[cKey] != ''){
					adapterName = Conversion.getControllerName(controller_Arr[cKey]);
				}
			}
			if(!(adapterName != undefined || adapterName != null || adapterName != '')){
				controllerPending_Arr[j].FQDD = j;
				adapterName = Conversion.getControllerName(controllerPending_Arr[j]);
			}


			// Controller Mode
			if(controllerPending_Arr[j].requested_mode == 1 || controllerPending_Arr[j].requested_mode == 2){
				tmpValue = Localization.getLocaleStringForID("controller_mode") + " : " +
					convControllerModeArr.getDisplayString(controllerPending_Arr[j].requested_mode);
				tmpArray=[rowcount++,device_type,adapterName,tmpValue];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}

			//Load Balance Mode
			if(controllerPending_Arr[j].pending_changes & 0x00000020){
				tmpArray=[rowcount++,device_type,adapterName,convLBSet_Arr.getDisplayString(controllerPending_Arr[j].load_balance_mode)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Battery Learn Mode
			if(controllerPending_Arr[j].pending_changes & 0x00000040){
				tmpArray=[rowcount++,device_type,adapterName,convBatteryLearnMode_Arr.getDisplayString(controllerPending_Arr[j].battery_learn_mode)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Check Consistency Mode
			if(controllerPending_Arr[j].pending_changes & 0x00000080){
				tmpArray=[rowcount++,device_type,adapterName,convCheckconsistencymode_Arr.getDisplayString(controllerPending_Arr[j].check_consistency_mode)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Patrol Read Mode
			if(controllerPending_Arr[j].pending_changes & 0x00000100){
				tmpArray=[rowcount++,device_type,adapterName,convPatrolreadmode_Arr.getDisplayString(controllerPending_Arr[j].patrol_read_mode)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Copy Back Mode
			if(controllerPending_Arr[j].pending_changes & 0x00000200){
				tmpArray=[rowcount++,device_type,adapterName,convCopyback_Arr.getDisplayString(controllerPending_Arr[j].copyback_mode)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Rebuid Rate
			if(controllerPending_Arr[j].pending_changes & 0x00000400){
				tmpValue = (Localization.getLocaleStringForID("rebuild_rate") +' : ' +controllerPending_Arr[j].rebuild_rate + "%").escapeHTML();
				tmpArray=[rowcount++,device_type,adapterName,tmpValue];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Check Consistency Rate
			if(controllerPending_Arr[j].pending_changes & 0x00000800){
				tmpValue = (Localization.getLocaleStringForID("check_consistency_rate") +' : ' +controllerPending_Arr[j].check_consistency_rate + "%").escapeHTML();
				tmpArray=[rowcount++,device_type,adapterName,tmpValue];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Reconstruct Rate
			if(controllerPending_Arr[j].pending_changes & 0x00001000){
				tmpValue = (Localization.getLocaleStringForID("reconstruct_rate") +' : ' +controllerPending_Arr[j].reconstruct_rate + "%").escapeHTML();
				tmpArray=[rowcount++,device_type,adapterName,tmpValue];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//BGI Rate
			if(controllerPending_Arr[j].pending_changes & 0x00002000){
				tmpValue = (Localization.getLocaleStringForID("bgi_rate") +' : ' +controllerPending_Arr[j].bgi_rate + "%").escapeHTML();
				tmpArray=[rowcount++,device_type,adapterName,tmpValue];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Patrol Read Rate
			if(controllerPending_Arr[j].pending_changes & 0x00004000){
				tmpValue = (Localization.getLocaleStringForID("patrol_read_rate") +' : ' +controllerPending_Arr[j].patrol_read_rate + "%").escapeHTML();
				tmpArray=[rowcount++,device_type,adapterName,tmpValue];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//PR Unconfigured Areas
			if(controllerPending_Arr[j].pending_changes & 0x00010000){
				tmpArray=[rowcount++,device_type,adapterName,convPatrolreadUnconfiguredAreas_Arr.getDisplayString(controllerPending_Arr[j].patrol_read_unconfigured_areas)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Patrol Read State
			if(controllerPending_Arr[j].pending_changes & 0x00020000){
				tmpArray=[rowcount++,device_type,adapterName,convPatrolreadState_Arr.getDisplayString(controllerPending_Arr[j].patrol_read_state)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Enh Auto Import Mode
			if(controllerPending_Arr[j].pending_changes & 0x00040000){
				tmpArray=[rowcount++,device_type,adapterName,convForeignConfig_Arr.getDisplayString(controllerPending_Arr[j].enhance_auto_import_mode)];
				Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
			}
			//Boot Mode
			tmpCount++;
		}
	}
	if(tmpCount){
		retval = true;
		updPendingOpValue(controller_selected);
	}
	return retval;
}
function checkForEnclosurePO(controller_selected,table_id){
	var	convEnclosuremode_Arr = [[Localization.getLocaleStringForID("unified_mode"), 0x01], [Localization.getLocaleStringForID("split_mode"), 0x02]];
	var	convEnclosureNRmode_Arr = [[Localization.getLocaleStringForID("enclosure_unifiedmode_nr"), 0x01], [Localization.getLocaleStringForID("enclosure_splitmode_nr"), 0x02]];
	var tmpArray=new Array();
	var tmpCount=0;var retval=false;
	var device_type = Localization.getLocaleStringForID("enclosure");

	for (var j in enclosurePending_Arr){
		if((enclosurePending_Arr.hasOwnProperty(j)) && (controller_selected == enclosure_Arr[enclosurePending_Arr[j].currentfqddkey].adapterfqddkey) && (enclosurePending_Arr[j].pending_changes)){
		//Enclosure Mode
			if(enclosurePending_Arr[j].pending_changes & 0x00000004){
				if(enclosurePending_Arr[j].requested_mode){
					tmpArray = [rowcount++,device_type,enclosure_Arr[enclosurePending_Arr[j].currentfqddkey].name,convEnclosureNRmode_Arr.getDisplayString(enclosurePending_Arr[j].requested_mode)];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
			}
		}
	}
	if(tmpCount){
		retval = true;
		updPendingOpValue(controller_selected);
	}
	return retval;
}
function checkForVdiskPO(controller_selected,table_id){
	var tmpArray=new Array();
	var tmpCount=0;
	var opCount=0;var attrCount = 0;
	var key;var retval=false;
	var device_type = Localization.getLocaleStringForID("virtual_disk");
	var readPolicy_Arr = [[Localization.getLocaleStringForID("readpolicy_noreadahead"), 0x10], [Localization.getLocaleStringForID("readpolicy_readahead"), 0x20], [Localization.getLocaleStringForID("readpolicy_adaptivereadahead"), 0x40]];
	var writePolicy_Arr = [[Localization.getLocaleStringForID("writepolicy_writethrough"), 0x1], [Localization.getLocaleStringForID("writepolicy_writeback"), 0x2], [Localization.getLocaleStringForID("writepolicy_forcewriteback"), 0x4]];
	var diskCache_Arr = [[Localization.getLocaleStringForID("dcp_default"), 0x100], [Localization.getLocaleStringForID("dcp_enabled"), 0x200], [Localization.getLocaleStringForID("dcp_disabled"), 0x400]];

	for(var i in vdisk_Arr){
		if(vdisk_Arr.hasOwnProperty(i)){
			var obj = vdisk_Arr[i];
			if(obj["adapterfqddkey"] == controller_selected){
				if(obj["pending_status"] & 0x02){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("delete_vdisk")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
			}
		}
	}
	for(var i in vdiskPending_Arr){
		if(vdiskPending_Arr.hasOwnProperty(i)){
			var obj = vdiskPending_Arr[i];
			key=vdiskPending_Arr[i].adapterfqddkey;
			key=key.replace("|P|","|C|");
			if(key == controller_selected){
				if(obj["pending_changes"]&0x00000800){
					var tmpObj= vdisk_Arr[vdiskPending_Arr[i].currentfqddkey];
					if(tmpObj != null && tmpObj != undefined && tmpObj != undefined){
						tmpArray=[rowcount++,device_type,tmpObj["name"],Localization.getLocaleStringForID("rename")];
					}else{
						tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("rename")];
					}
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_status"] == 0x03){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("create_virtualdisk")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_operations"]&0x00000001){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("initialize_fast")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}else if(obj["pending_operations"]&0x00000002){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("initialize_full")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_operations"]&0x00000004){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("check_consistency")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_operations"]&0x00000010){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("cancel_init")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_operations"]&0x00000008){
					tmpArray=[rowcount++,device_type,obj["name"],Localization.getLocaleStringForID("cancel_check_consistency")];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_changes"]&0x00000020){
					tmpArray=[rowcount++,device_type,obj["name"],readPolicy_Arr.getDisplayString(obj["read_policy"])];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_changes"]&0x00000040){
					tmpArray=[rowcount++,device_type,obj["name"],writePolicy_Arr.getDisplayString(obj["write_policy"])];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
				if(obj["pending_changes"]&0x00000100){
					tmpArray=[rowcount++,device_type,obj["name"],diskCache_Arr.getDisplayString(obj["disk_cache_policy"])];
					Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
					tmpCount++;
				}
			}
		}
	}
	if(tmpCount){
		retval = true;
		updPendingOpValue(controller_selected);
	}
	return retval;
}
function checkForPdiskPO(controller_selected,table_id){
	var	hotspare_Arr = [[Localization.getLocaleStringForID("unassign_hotspare"), 0], [Localization.getLocaleStringForID("assign_dedicated_hs"), 1], [Localization.getLocaleStringForID("assign_global_hs"), 2]];
	var PDiskRAID_Arr = [[Localization.getLocaleStringForID("convert_raid"), 1],
		[Localization.getLocaleStringForID("convert_nonraid"), 8]];

	var tmpArray=new Array();var curObj;var pendingObj; var retval=false;
	var tmpCount=0;
	var device_type = Localization.getLocaleStringForID("physical_disk");

	for (var j in pdisk_Arr){
		if(pdisk_Arr.hasOwnProperty(j)){
			curObj = pdisk_Arr[j];
			if(curObj != null && curObj != undefined && curObj != ''){
				if(curObj["adapterfqddkey"] == controller_selected){
					if(pdiskPending_Arr[curObj["pendingfqddkey"]] != null && pdiskPending_Arr[curObj["pendingfqddkey"]] != undefined && pdiskPending_Arr[curObj["pendingfqddkey"]] != ''){
						pendingObj = pdiskPending_Arr[curObj["pendingfqddkey"]];
						if(curObj["hotspare"] != pendingObj["hotspare"]){
							tmpArray=[rowcount++,device_type,curObj["name"],hotspare_Arr.getDisplayString(pendingObj["hotspare"])];
							Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
							tmpCount++;
						}
						if (((curObj["state"] == 1) || (curObj["state"] == 8)) && ((pendingObj["state"] == 1) || (pendingObj["state"] == 8))) {
							if (curObj["state"] != pendingObj["state"]) {
								tmpArray=[rowcount++,device_type,curObj["name"],PDiskRAID_Arr.getDisplayString(pendingObj["state"])];
								Table.generateAdvTable("row_"+rowcount, $(table_id), tmpArray);
								tmpCount++;
							}
						}
					}
				}
			}
		}
	}
	if(tmpCount){
		retval = true;
		updPendingOpValue(controller_selected);
	}
	return retval;
}
function updPendingOpValue(controller_selected){
	var flag = 0;
	if(gen_controllerArr != undefined && gen_controllerArr != null){
		if(gen_controllerArr[controller_selected] != undefined && gen_controllerArr[controller_selected] != null && gen_controllerArr[controller_selected] != ''){
			gen_controllerArr[controller_selected].PassCnt = 1;
			gen_controllerArr[controller_selected].pendingoperations = 1
		}else{
			flag = 1;
		}
	}else{
		flag = 1;
	}
	if(flag){
		if(controllerArr != undefined && controllerArr != null){
			if(controllerArr[controller_selected] != undefined && controllerArr[controller_selected] != null && controllerArr[controller_selected] != ''){
				controllerArr[controller_selected].PassCnt = 1;
				controllerArr[controller_selected].pendingoperations = 1
			}
		}
	}
}