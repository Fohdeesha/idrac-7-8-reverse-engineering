var lang = top.lang;
var gen_totalValue = 1;
var gen_blink_Unblink=0xFF;
var gen_noPhysicalDisks = false;
var gen_msgObj,gen_msgTemplate,gen_show;
var adapterSelected,adapterPenKey,adapterName;
var inPageAlert = true;var inPageAlertContainer = '';
var gen_PDVDfrom,gen_PDVDto,gen_fqddParamStr,gen_PDVDfqddArr;
var gen_restData,gen_headerArr,gen_bodyMsg;var gen_headerArrFlag = 0;
var gen_finalscheduleDateFromTime,gen_finalscheduleDateToTime,gen_fromDpck_fieldname;

/*URLs*/
var controllerCurDataURL,controllerPenDataURL;
var URL,vdiskblinkunblinkURL,pdiskblinkunblinkURL;
var jobcreateURL,vdiskCreateURL,boundsURL,availableRaidLvlsURL,availableDisksForRaidLevelURL,controllerJobdetailsURL;

/*Arrays*/
var gen_sortedpdiskArr,gen_sortedvdiskArr;
var gen_jobTypeArr,gen_powerCycleOptionsArr,gen_timeOptionsArr;
var gen_size_UnitsArr,gen_units,gen_adapterRLarr,gen_RAIDlevelsArr;
var gen_pdiskURIArr = new Array();var gen_vdiskURIArr = new Array();
var gen_pdiskArr = new Array(); var gen_pdiskArrPending = new Array();
var gen_vdiskArr = new Array(); var gen_vdiskArrPending = new Array();
var gen_layoutArr,gen_readPolicyArr,gen_writePolicyArr,gen_mediaTypeArr;
var gen_pdiskCurURIArr = new Array();var gen_pdiskPenURIArr = new Array();
var gen_vdiskCurURIArr = new Array(); var gen_vdiskPenURIArr = new Array();
var gen_pdiskCurKeysArr = new Array();var gen_pdiskPenKeysArr = new Array();
var gen_vdiskCurKeysArr = new Array();var gen_vdiskPenKeysArr = new Array();
var gen_controllerArr = new Array();var gen_controllerArrPending = new Array();
var gen_enclosureArr = new Array(); var gen_enclosureArrPending = new Array();
var gen_mediaTypeArr1,gen_convDIFarr,gen_diskCacheArr,gen_stripeElemSizeArr,gen_spanDepthArr;


/*These params are used in looping and getting data*/
function URI_LOOP_PARAMS(){
	this.uriIndex = 0;
	this.reqInProcess = 0;
}
var pdiskcurdata_loopparams = new URI_LOOP_PARAMS();
var pdiskpendata_loopparams = new URI_LOOP_PARAMS();
var vdiskcurdata_loopparams = new URI_LOOP_PARAMS();
var vdiskpendata_loopparams = new URI_LOOP_PARAMS();
/*Need to use Const variable. But currently no support for this keyword on all browsers
Refer to below documentation for more info on const keyword:
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/const  */
var gen_const = {
	KEYS_PROP:0, //Both Keys and Properties
	KEYS:1, //Only keys
	REQ_COMPLETED:1,
	REQ_IN_PROCESS:2,
	MAXROW:25,
	NORANGE:'',
	NOBODY:'',
	CUROBJ:'|C|',
	PENOBJ:'|P|',
	CONTROLLERCURRENT:'/sysmgmt/2010/storage/controller/301|C|',
	CONTROLLERPENDING:'/sysmgmt/2010/storage/controller/301|P|',
	ENCLOSURECURRENT_PARENT_CONTROLLER:'/sysmgmt/2010/storage/enclosure?controller=301|C|',
	ENCLOSUREPENDING_PARENT_CONTROLLER:'/sysmgmt/2010/storage/enclosure?controller=301|P|',
	PDISKCURRENT_PARENT_CONTROLLER:'/sysmgmt/2010/storage/pdisk?controller=301|C|',
	PDISKPENDING_PARENT_CONTROLLER:'/sysmgmt/2010/storage/pdisk?controller=301|P|',
	VDISKCURRENT_PARENT_CONTROLLER:'/sysmgmt/2010/storage/vdisk?controller=301|C|',
	VDISKPENDING_PARENT_CONTROLLER:'/sysmgmt/2010/storage/vdisk?controller=301|P|',
	PDISKINFO_CURRENTKEYS:'/sysmgmt/2010/storage/pdisk?keys=304|C|',
	PDISKINFO_PENDINGKEYS:'/sysmgmt/2010/storage/pdisk?keys=304|P|',
	VDISKINFO_CURRENTKEYS:'/sysmgmt/2010/storage/vdisk?keys=305|C|',
	VDISKINFO_PENDINGKEYS:'/sysmgmt/2010/storage/vdisk?keys=305|P|',
	RAID_ADAPTER:0,
	PCI_EXTENDER:1,
	NONRAID_ADAPTER:2,
	EMBED_PCIESSD_ADAPTER:3,
	SWRAID_ADAPTER:4,
	RT_CAPBILITY:1,
	RAID:"RAID",
	PCIE_EXTENDER:"PCIE_EXTENDER",
	URL_NOT_PROCESSED:"URL NOT PROCESSED = ",
	EXCEPTION_IN_URL_PROCESS:"EXCEPTION GENERATED WHILE PROCESSING URL = ",
	INDEX:0,
	OBJ_INDEX:1,
	PDISK:'304',
	VDISK:'305',
	BP:'308',
	ADAPTER:'301'
}
var stor_range = {
	controller:'name,pci_slot,embedded,raid_object_hide',
	enclosure:'name',
	pdisk:'name,slot,form_factor',
	vdisk:'name'
}

/*
FUNCTION DETAILS:
Name:GetStorPropsKeys
Description: Function which returns an array, which contains either keys or properties of a storage device.
Return Value: Array
*/
function GetStorPropsKeys(e,requiredObj,keysprops){
	var compArr = new Array();
	for (var j in e){
		if(j.indexOf(requiredObj) != -1){
			if(keysprops == gen_const.KEYS_PROP){
				compArr[j] = e[j];
			}else if(keysprops == gen_const.KEYS){
				compArr.push(j);
			}
		}
	}
	return compArr;
}
/*Get All storage device details or keys*/
function gen_DevInfo(_devURL,_range,_keysprops){
	/*gen_headerArrFlag = 1; Will fetch only keys and not the entire properties.
	  gen_headerArrFlag = 0; Will fetch both keys and properties
	*/
	URL = _devURL;
	gen_headerArrFlag = (_keysprops == gen_const.KEYS)?(gen_const.KEYS):(gen_const.KEYS_PROP);
	gen_sendRESTrequest("get",'',_range);
}
function gen_formComponentURI(_deviceKeyArr,_length,_totalValue){
	var compURIArray = new Array();
	var curValue = 1;
	if(_length){
		if(_deviceKeyArr != null && _deviceKeyArr != undefined && _deviceKeyArr != ''){
			for (curValue=1;curValue <= _totalValue;curValue++){
				gen_PDVDfqddArr = new Array();
				gen_PDVDfrom = (curValue - 1) * gen_const.MAXROW;
				gen_PDVDto = (_length < curValue * gen_const.MAXROW) ? _length : curValue * gen_const.MAXROW;
				gen_PDVDfqddArr = (_deviceKeyArr.slice(gen_PDVDfrom, gen_PDVDto));
				gen_fqddParamStr = "";
				gen_fqddParamStr = gen_PDVDfqddArr.toString();
				if(gen_fqddParamStr){
					compURIArray.push(gen_fqddParamStr);
				}
			}
		}
	}
	return compURIArray;
}
function gen_GetDataInChunks(devTypeURL,compURIArr,compURIArrLen,paramsRange,loopParamsObj){
	if((devTypeURL != pdiskURL && devTypeURL != vdiskURL) ||(!compURIArrLen)){
		return false;
	}
	if (loopParamsObj.uriIndex < compURIArrLen){
		if(loopParamsObj.reqInProcess == 0) {
			URL = devTypeURL + "?keys=" + compURIArr[loopParamsObj.uriIndex++];
			loopParamsObj.reqInProcess++;
			gen_sendRESTrequest("get",'',paramsRange);
		}
		if((loopParamsObj.uriIndex < compURIArrLen) && (loopParamsObj.reqInProcess < 2)){
			URL = devTypeURL + "?keys=" + compURIArr[loopParamsObj.uriIndex++];
			loopParamsObj.reqInProcess++;
			gen_sendRESTrequest("get",'',paramsRange);
		}
		return gen_const.REQ_IN_PROCESS;
	}else{
		if((loopParamsObj.uriIndex == compURIArrLen) && (loopParamsObj.reqInProcess == 0)){
			progressBar.hide();
			return gen_const.REQ_COMPLETED;
		}
		return gen_const.REQ_IN_PROCESS;
	}
}
/*
function gen_GetDataInChunks(devTypeURL,compURIArr,compURIArrLen,paramsRange,loopParamsObj){
	if((devTypeURL != pdiskURL && devTypeURL != vdiskURL) ||(!compURIArrLen)){
		return false;
	}
	if((loopParamsObj.uriIndex == 0) && (loopParamsObj.uriIndex < compURIArrLen)){
		//Fire first two XHRs in parallel. At Any point of time, only two XHRs to be fired in parallel, as per HTTP spec
		URL = devTypeURL + "?keys=" + compURIArr[loopParamsObj.uriIndex++];
		loopParamsObj.reqInProcess++;
		gen_sendRESTrequest("get",'',paramsRange);
		//If only one set of 25 PD's or VD's or less than 25 available, then below request is invalid
		if(loopParamsObj.uriIndex < compURIArrLen){
			URL = devTypeURL + "?keys=" + compURIArr[loopParamsObj.uriIndex++];
			gen_sendRESTrequest("get",'',paramsRange);
			loopParamsObj.reqInProcess++;
		}
		return gen_const.REQ_IN_PROCESS;
	}else if((loopParamsObj.uriIndex != 0) && (loopParamsObj.uriIndex < compURIArrLen)){
		URL = devTypeURL + "?keys=" + compURIArr[loopParamsObj.uriIndex++];
		loopParamsObj.reqInProcess++;
		gen_sendRESTrequest("get",'',paramsRange);
		//f only one set of 25 PD's or VD's or less than 25 available, then below request is invalid
		if((loopParamsObj.reqInProcess < 2)&&(loopParamsObj.uriIndex < compURIArrLen)){
			URL = devTypeURL + "?keys=" + compURIArr[loopParamsObj.uriIndex++];
			loopParamsObj.reqInProcess++;
			gen_sendRESTrequest("get",'',paramsRange);
		}
		return gen_const.REQ_IN_PROCESS;
	}else{
		if((loopParamsObj.uriIndex == compURIArrLen) && (loopParamsObj.reqInProcess == 0)){
			progressBar.hide();
			return gen_const.REQ_COMPLETED;
		}
		return gen_const.REQ_IN_PROCESS;
	}
}
*/
function gen_HidePageDetails(dataArea,msgID,alertID){
	if(msgID != null && msgID != undefined && msgID != ''){
		if(alertID != null && alertID != undefined && alertID != ''){
		    NewpageAlertMsg(Localization.getLocaleNewMessageForID(msgID),alertID);
		}else{
		    NewpageAlertMsg(Localization.getLocaleNewMessageForID(msgID),1);
		}
	}else{
		/*message ID incorrect/not passed, then treat it is a generic error message and hide page*/
		NewpageAlertMsg(Localization.getLocaleNewMessageForID("RAC0508"),1);
	}
	dataArea.style.visibility="hidden";
}
function hide_popup(modalDiv,modalContainer){
	var modalpage = $(modalDiv);
	var modalgraphic = $(modalContainer);
	if (modalpage != null && modalgraphic != null) {
		modalpage.style.display = "none";
		addEvent.remove(window, "scroll", function(){
			modalDialog.setModalGraphic(modalContainer);
		});
		addEvent.remove(window, "resize", function(){
			modalDialog.setModalGraphic(modalContainer);
		});
	}
}
function getErrorMessageforHttpCode(_httperrorcode){
	var err_Msg;
	if(_httperrorcode == "400"){
		err_Msg = "RAC0507";
	}else if(_httperrorcode == "401"){
		err_Msg = "RAC0506";
	}else if(_httperrorcode == "404"){
		err_Msg = "RAC0507";
	}else if(_httperrorcode == "500"){
		err_Msg = "RAC0508";
	}else if(_httperrorcode == "503"){
		err_Msg = "RAC0509";
	}else{
		err_Msg = "RAC0508";
	}
 return err_Msg;
}
function gen_LoadTheRESTDetails(_methodType,_param){
	if(URL != lifecycleURI)
		URL = encodeURI(URL);
	new RESTrequest(URL, {
		method: _methodType,
		onSuccess: RESTsuccessHandler,
		postBody: (_param),
		requestHeaders: gen_headerArr,
		onFailure: onErrorAction,
		on1223: on204Action,
		on204: on204Action
	});
}
function gen_sendRESTrequest(_method,_bodyMsg,_range){
	progressBar.show(true);
	if(!gen_headerArrFlag){
		if(_range != undefined && _range != null && _range != ""){
			gen_headerArr = ["X_SYSMGMT_OPTIMIZE", "true", "X_SYSMGMT_RANGE", _range];
		}else{
			gen_headerArr = ["X_SYSMGMT_OPTIMIZE", "true"];
		}
	}else{
		gen_headerArr = new Array();
	}
	gen_headerArrFlag = 0;
	gen_LoadTheRESTDetails(_method,_bodyMsg);
}
function updateDeviceArr(devSrcArr){
	var devDestArr = new Array();
	var tmpCount = 0;
	for (var j in devSrcArr){
		if(devSrcArr.hasOwnProperty(j)){
			devDestArr[tmpCount++] = devSrcArr[j];
		}
	}
	return devDestArr;
}
function gen_GetControllerType(AdapterObj){
	if((AdapterObj.currentfqddkey.toLowerCase()).indexOf("nonraid") != -1){
		return gen_const.NONRAID_ADAPTER; //12Gbps SAS controller
	}else if(AdapterObj.supported_disk_protocol == 0x40){
		return gen_const.PCI_EXTENDER; //PCI Extender
	}else{
		return gen_const.RAID_ADAPTER; //RAID controller
	}
}
function gen_CheckAdaptersProp(adapterArr,prop){
	var retval = 0;
	for (var j in adapterArr){
		if(adapterArr.hasOwnProperty(j)){
			var adapterObj = adapterArr[j];
			if(prop == gen_const.RAID){
				if(adapterObj.adapterType == 0){
					return ++retval;
				}
			}else if(prop == gen_const.PCIE_EXTENDER){
				if(adapterObj.adapterType == 1){
					return ++retval;
				}
			}else if(prop == gen_const.RT_CAPBILITY){
				retval++;
			}
		}
	}
	return retval;
}
function gen_CheckServerPrivilege(){
	var rVal = true;
	if(!top.CAN_EXE_CMDS){
		ErrorMessage.on401Status();
		$('dataarea').style.visibility = "hidden";
		rVal = false;
	}
	return rVal;
}
function gen_InitControllerDpDwn(CntrllDpDwn,adapterArr){
	for (var j in adapterArr){
		if(adapterArr.hasOwnProperty(j)){
			if(adapterArr[j].adapterType == 0){ //Excluded 12Gbps SAS controller and PCIe-SSD Extenders(0x40)
				adapterName = Conversion.getControllerName(adapterArr[j]);
				CntrllDpDwn.options[CntrllDpDwn.options.length] = new Option(adapterName, j, true, false);
			}
		}
	}
}
function gen_ClearDropdownList(_comp){
	for (var i = 0; i < _comp.options.length; i++) {
		_comp.removeChild(_comp.options[i]);
		i = i - 1;
	}
}
function gen_GetContData(adapter,range,reqKey){
	var ApplyURL,AdapterKey;
	if(reqKey.indexOf(gen_const.CUROBJ) != -1){
		if(adapter.indexOf(gen_const.CUROBJ) != -1){
			AdapterKey = adapter;
		}else{
			AdapterKey = adapter.replace(gen_const.PENOBJ,gen_const.CUROBJ);
		}
		ApplyURL = controllerCurDataURL = controllerURL+"/"+AdapterKey;
	}else if(reqKey.indexOf(gen_const.PENOBJ) != -1){
		if(adapter.indexOf(gen_const.PENOBJ) != -1){
			AdapterKey = adapter;
		}else{
			AdapterKey = adapter.replace(gen_const.CUROBJ,gen_const.PENOBJ);
		}
		ApplyURL = controllerPenDataURL = controllerURL+"/"+AdapterKey;
	}
	gen_DevInfo(ApplyURL,range,gen_const.KEYS_PROP);
}
function gen_getControllerJobdetails(adapter,range){
	controllerJobdetailsURL = controllerURL+"/"+adapter;
	gen_DevInfo(controllerJobdetailsURL,range,gen_const.KEYS_PROP);
}
function gen_ProcessContData(e){ //e-both current and pending
	gen_controllerArr=new Array();gen_controllerArrPending=new Array();
	controller_Arr = new Array();controllerPending_Arr = new Array();
	for (var j in e){
		if(j.indexOf(gen_const.CUROBJ) != -1){
			gen_controllerArr[j]=e[j];
			gen_controllerArr[j].FQDD = j;
			gen_controllerArr[j].currentfqddkey = j;
			gen_controllerArr[j].pendingfqddkey = j.replace(gen_const.CUROBJ,gen_const.PENOBJ);
			gen_controllerArr[j].pendingoperations = 0;
			gen_controllerArr[j].adapterType = 0;
			gen_controllerArr[j].intdisks = 0;
			gen_controllerArr[j].extdisks = 0;
			gen_controllerArr[j].action = 0xFF;
			gen_controllerArr[j].vdiskpresent = 0;
			gen_controllerArr[j].securevdpresent = 0;
			gen_controllerArr[j].foreignconfigpresent = 0;
			gen_controllerArr[j].propertiesaction = 0xFF;//0xFF-default value;0x01: Success; Other values errormessages
			gen_controllerArr[j].skeyoperations = 0xFF;//0xFF-default value;0x01: create skey;0x02:modify skey;0x03:delete skey; Other values errormessages
			gen_controllerArr[j].splitmodeenclosurepresent = 0;
			gen_controllerArr[j].adapterType = gen_GetControllerType(gen_controllerArr[j]);
			controller_Arr[j]= gen_controllerArr[j];
		}else if(j.indexOf(gen_const.PENOBJ) != -1){
			gen_controllerArrPending[j]= e[j];
			gen_controllerArrPending[j].pendingfqddkey = j;
			gen_controllerArrPending[j].currentfqddkey = j.replace(gen_const.PENOBJ,gen_const.CUROBJ);
			controllerPending_Arr[j] = gen_controllerArrPending[j];
		}
	}
}
function gen_onContCurDataSuccess(e,adapter){
	gen_ProcessAdapterData(e,gen_const.CUROBJ);
	/*Get controller pending data*/
	adapterPenKey = adapter.replace(gen_const.CUROBJ,gen_const.PENOBJ);
	gen_GetContData(adapterPenKey,gen_const.NORANGE,gen_const.PENOBJ);
}
function gen_onContPenDataSuccess(e,adapter,range){
	gen_ProcessAdapterData(e,gen_const.PENOBJ);
	gen_GetAdapterChilds(adapter,enclosureURL,gen_const.KEYS_PROP,range);
}
function gen_ProcessAdapterData(e,reqKey){
	if(reqKey == gen_const.CUROBJ){
		controller_Arr = new Array();
	}else if(reqKey == gen_const.PENOBJ){
		gen_controllerArrPending=new Array();
		controllerPending_Arr = new Array();
	}
	for (var j in e){
		if((j.indexOf(gen_const.CUROBJ) != -1) && (reqKey == gen_const.CUROBJ)){
			controller_Arr[j] = e[j];
			controller_Arr[j].currentfqddkey = j;
			controller_Arr[j].pendingfqddkey = j.replace(gen_const.CUROBJ,gen_const.PENOBJ);
		}else if((j.indexOf(gen_const.PENOBJ) != -1) && (reqKey == gen_const.PENOBJ)){
			gen_controllerArrPending[j] = e[j];
			gen_controllerArrPending[j].pendingfqddkey = j;
			gen_controllerArrPending[j].currentfqddkey = j.replace(gen_const.PENOBJ,gen_const.CUROBJ);
			controllerPending_Arr[j] = gen_controllerArrPending[j];
		}
	}
}
function gen_onEnclCurDataSuccess(e,adapter){
	gen_ProcessEnclData(e,gen_const.CUROBJ);
	/*Get enclosure pending data*/
	adapterPenKey = adapter.replace(gen_const.CUROBJ,gen_const.PENOBJ);
	gen_GetAdapterChilds(adapterPenKey,enclosureURL,gen_const.KEYS_PROP,storage_params.enclosure);
}
function gen_onEnclPenDataSuccess(e,adapter){
	gen_ProcessEnclData(e,gen_const.PENOBJ);
	/*Get controller specific pdisk cur keys*/
	gen_pdiskCurKeysArr = new Array();gen_pdiskPenKeysArr = new Array();
	gen_pdiskCurURIArr = new Array();gen_pdiskPenURIArr = new Array();
	gen_GetAdapterChilds(adapter,pdiskURL,gen_const.KEYS,gen_const.NORANGE);
}
function gen_ProcessEnclData(e,reqKey){
	if(reqKey == gen_const.CUROBJ){
		gen_enclosureArr = new Array();
		enclosure_Arr = new Array();
	}else if(reqKey == gen_const.PENOBJ){
		gen_enclosureArrPending = new Array();
		enclosurePending_Arr = new Array();
	}
	for (var j in e){
		if((j.indexOf(gen_const.CUROBJ) != -1) && (reqKey == gen_const.CUROBJ)){
			gen_enclosureArr[j] = e[j];
			gen_enclosureArr[j].currentfqddkey = j;
			gen_enclosureArr[j].pendingfqddkey = j.replace(gen_const.CUROBJ,gen_const.PENOBJ);
			gen_enclosureArr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
			gen_enclosureArr[j].enclosureType = 0;//0-Normal Backplane,1-Backplane connected to PCIeSSD,2-Backplane connected to 12Gbps SAS controller
			gen_enclosureArr[j].operation = 0xFF; //0x01-Unified Mode,0x02-Split Mode,0xFF-initialization value.
			gen_enclosureArr[j].errorCode = ''; //''-Initialization value
			gen_enclosureArr[j].operationStatus = 0xFF;	//0x00-Failure,0x01-Success,0xFF-initialization value,0xFFFF-Some error occured
			if(gen_enclosureArr[j].protocol_supported == 0x40){
				gen_enclosureArr[j].enclosureType = 1;
			}else{
				var tmpValue = gen_enclosureArr[j].adapterfqddkey;
				if(tmpValue.indexOf("NonRAID") != -1){
					gen_enclosureArr[j].enclosureType = 2;
				}
			}
			enclosure_Arr[j] = gen_enclosureArr[j];
		}else if((j.indexOf(gen_const.PENOBJ) != -1) && (reqKey == gen_const.PENOBJ)){
			gen_enclosureArrPending[j] = e[j];
			gen_enclosureArrPending[j].pendingfqddkey = j;
			gen_enclosureArrPending[j].currentfqddkey = j.replace(gen_const.PENOBJ,gen_const.CUROBJ);
			gen_enclosureArrPending[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
			enclosurePending_Arr[j] = gen_enclosureArrPending[j];
		}
	}
}
function gen_onPdiskCurKeysSuccess(pdiskKeyArr,adapter){
	var rVal = gen_ProcessPDKeyData(pdiskKeyArr,gen_const.CUROBJ);
	if(rVal){
		//Get Pending Keys
		adapterPenKey = adapter.replace(gen_const.CUROBJ,gen_const.PENOBJ);
		gen_GetAdapterChilds(adapterPenKey,pdiskURL,gen_const.KEYS,gen_const.NORANGE);
	}else{
		// Skip pdisk pen data as no pdisk current keys. Now get vdisk current keys.
		// Ideally this condition should not hit. If hit, handle it gracefully.
		gen_vdiskCurKeysArr = new Array();gen_vdiskPenKeysArr = new Array();
		gen_vdiskCurURIArr = new Array();gen_vdiskPenURIArr = new Array();
		gen_GetAdapterChilds(adapter,vdiskURL,gen_const.KEYS,gen_const.NORANGE);
	}
}
function gen_onPdiskPenKeysSuccess(pdiskKeyArr,adapter,range){
	gen_ProcessPDKeyData(pdiskKeyArr,gen_const.PENOBJ);
	var rVal = gen_ValidatePDkeysData();
	if(rVal){
		/*Received both cur and pen keys of pdisk. Now get pdisk cur data using the keys*/
		gen_pdiskArr = new Array();pdisk_Arr = new Array();
		pdiskcurdata_loopparams.uriIndex = 0; pdiskcurdata_loopparams.reqInProcess = 0;
		gen_GetPDiskCurDataInLoops(adapter,pdiskURL,gen_pdiskCurURIArr,gen_pdiskCurURIArr.length,range,pdiskcurdata_loopparams);
	}else{
		/*Get vdisk current keys, as either pdisk cur keys or pdisk pen keys were not existing*/
		gen_vdiskCurKeysArr = new Array();gen_vdiskPenKeysArr = new Array();
		gen_vdiskCurURIArr = new Array();gen_vdiskPenURIArr = new Array();
		gen_GetAdapterChilds(adapter,vdiskURL,gen_const.KEYS,gen_const.NORANGE);
	}
}
function gen_GetPDiskCurDataInLoops(adapter,devURL,deviceURIArr,deviceURIArrLen,paramsRange,loopParams){
	 var gen_retVal; var flag = 0;
	if((deviceURIArrLen)&&(devURL == pdiskURL)){
		gen_retVal = gen_GetDataInChunks(devURL,deviceURIArr,deviceURIArrLen,paramsRange,loopParams);
		if(gen_retVal == gen_const.REQ_COMPLETED){
			//Completed the pdisk current data fetching. Now get pdisk pending data using pending keys
			flag = 1;
		}
	}else{
		//This condition should not hit in ideal condition. It will hit only , if the passed arguments to the function are incorrect.
		//If hit also handle it gracefully.
		flag = 1;
	}
	if(flag){
		gen_pdiskArrPending = new Array();pdiskPending_Arr = new Array();
		pdiskpendata_loopparams.uriIndex = 0; pdiskpendata_loopparams.reqInProcess = 0;
		gen_GetPDiskPenDataInLoops(adapter,pdiskURL,gen_pdiskPenURIArr,gen_pdiskPenURIArr.length,paramsRange,pdiskpendata_loopparams);
	}
}
function gen_onPDCurDataSuccess(e,adapter,range,loopParams){
	for (var j in e){
		var isDirectDrive = ((j.split(":")[0].toLowerCase()).indexOf("direct") != -1) ? true : false;
		gen_pdiskArr[j] = e[j];
		gen_pdiskArr[j].currentfqddkey = j;
		gen_pdiskArr[j].pendingfqddkey = j.replace(gen_const.CUROBJ,gen_const.PENOBJ);
		if(isDirectDrive){
			gen_pdiskArr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
			gen_pdiskArr[j].controller = Conversion.getControllerName(gen_controllerArr[gen_pdiskArr[j].adapterfqddkey]);
			gen_pdiskArr[j].enclosurefqddkey = '';
			gen_pdiskArr[j].enclosure = '' ;
		}else{
			if(e[j].enclosures != null && e[j].enclosures != undefined && e[j].enclosures != ''){
				gen_pdiskArr[j].enclosurefqddkey = getKeyFromURI(e[j].enclosures, enclosureURL);
				gen_msgObj = gen_enclosureArr[gen_pdiskArr[j].enclosurefqddkey];
				if(gen_msgObj != null && gen_msgObj !=undefined && gen_msgObj != ''){
					gen_pdiskArr[j].adapterfqddkey = gen_msgObj.adapterfqddkey;
					gen_pdiskArr[j].enclosure = gen_msgObj.name;
					gen_pdiskArr[j].controller = Conversion.getControllerName(gen_controllerArr[gen_pdiskArr[j].adapterfqddkey]);
				}else{
					gen_pdiskArr[j].enclosurefqddkey = '';
					gen_pdiskArr[j].enclosure = '' ;
					gen_pdiskArr[j].controller = '';
				}
			}else{
				if(e[j].controllers != undefined && e[j].controllers != null && e[j].controllers != ''){
					gen_pdiskArr[j].enclosurefqddkey = '';
					gen_pdiskArr[j].enclosure = '' ;
					gen_pdiskArr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
					gen_pdiskArr[j].controller = Conversion.getControllerName(gen_controllerArr[gen_pdiskArr[j].adapterfqddkey]);
				}else{
					gen_pdiskArr[j].enclosurefqddkey = '';
					gen_pdiskArr[j].enclosure = '' ;
					gen_pdiskArr[j].controller = '';
				}
			}
		}
		pdisk_Arr[j] = gen_pdiskArr[j];
	}
	gen_GetPDiskCurDataInLoops(adapter,pdiskURL,gen_pdiskCurURIArr,gen_pdiskCurURIArr.length,range,loopParams);
}
function gen_GetPDiskPenDataInLoops(adapter,devURL,deviceURIArr,deviceURIArrLen,paramsRange,loopParams){
	 var gen_retVal;var flag = 0;
	if((deviceURIArrLen)&&(devURL == pdiskURL)){
		gen_retVal = gen_GetDataInChunks(devURL,deviceURIArr,deviceURIArrLen,paramsRange,loopParams);
		if(gen_retVal == gen_const.REQ_COMPLETED){
			//Completed the pdisk pending data fetching. Now get vdisk current keys
			flag = 1;
		}
	}else{
		//This condition should not hit in ideal condition. It will hit only , if the passed arguments to the function are incorrect.
		//If hit also handle it gracefully.
		flag = 1;
	}
	if(flag){
		/*Get Vdisk Cur data*/
		gen_vdiskCurKeysArr = new Array();gen_vdiskPenKeysArr = new Array();
		gen_vdiskCurURIArr = new Array();gen_vdiskPenURIArr = new Array();
		gen_GetAdapterChilds(adapter,vdiskURL,gen_const.KEYS,gen_const.NORANGE);
	}
}
function gen_onPDPenDataSuccess(e,adapter,range,loopParams){
	for (var j in e){
		gen_pdiskArrPending[j] = e[j];
		gen_pdiskArrPending[j].pendingfqddkey = j;
		gen_pdiskArrPending[j].currentfqddkey = j.replace(gen_const.PENOBJ,gen_const.CUROBJ)
		pdiskPending_Arr[j] = gen_pdiskArrPending[j];
	}
	gen_GetPDiskPenDataInLoops(adapter,pdiskURL,gen_pdiskPenURIArr,gen_pdiskPenURIArr.length,range,loopParams);
}
function gen_ProcessPDKeyData(pdiskKeyArr,reqKey){
/*Form URIs of current and pending keys and use it later
  25 keys-one URI*/
	var gen_ArrLength = pdiskKeyArr.length;
	if(gen_ArrLength){
		gen_totalValue = Math.ceil(gen_ArrLength / gen_const.MAXROW);
		if(gen_totalValue == 0){
			gen_totalValue = 1;
		}
	}
	if(reqKey == gen_const.CUROBJ){
		gen_pdiskCurKeysArr = new Array();
		gen_pdiskCurKeysArr = pdiskKeyArr;
		gen_pdiskCurURIArr = new Array();
		gen_pdiskCurURIArr = gen_formComponentURI(gen_pdiskCurKeysArr,gen_ArrLength,gen_totalValue);
	}else if(reqKey == gen_const.PENOBJ){
		gen_pdiskPenKeysArr = new Array();
		gen_pdiskPenKeysArr = pdiskKeyArr;
		gen_pdiskPenURIArr = new Array();
		gen_pdiskPenURIArr = gen_formComponentURI(gen_pdiskPenKeysArr,gen_ArrLength,gen_totalValue);
	}
	return gen_ArrLength;
}

function gen_ValidatePDkeysData(){
/*If either pdisk cur or pen keys are not present, Do not fetch pdisk data.
  If pdisk cur and pen keys are present, then return true to fetch the data of pdisk(cur & pen) using keys
 */
	var rVal = false;
	try{
		if(gen_pdiskCurURIArr != undefined && gen_pdiskCurURIArr != null && gen_pdiskCurURIArr != ''){
			if(gen_pdiskPenURIArr != undefined && gen_pdiskPenURIArr != null && gen_pdiskPenURIArr != ''){
				if(gen_pdiskCurURIArr.length && gen_pdiskPenURIArr.length){
					rVal = true;
				}
			}
		}
		return rVal;
	}catch(err){
		/*Do not break code flow. Handle exception and get vdisk data next*/
		console.log(err);
		rVal = false;
		return rVal;
	}
}
function gen_onVdiskCurKeysSuccess(vdiskKeyArr){
	gen_ProcessVDKeyData(vdiskKeyArr,gen_const.CUROBJ);
}
function gen_onVdiskPenKeysSuccess(vdiskKeyArr){
	gen_ProcessVDKeyData(vdiskKeyArr,gen_const.PENOBJ);
}
function gen_ProcessVDKeyData(vdiskKeyArr,reqKey){
/*Form URIs of current and pending keys and use it later
  25 keys-one URI*/
	var gen_ArrLength = vdiskKeyArr.length;
	if(gen_ArrLength){
		gen_totalValue = Math.ceil(gen_ArrLength / gen_const.MAXROW);
		if(gen_totalValue == 0){
			gen_totalValue = 1;
		}
	}
	if(reqKey == gen_const.CUROBJ){
		gen_vdiskCurKeysArr = new Array();
		gen_vdiskCurKeysArr = vdiskKeyArr;
		gen_vdiskCurURIArr = new Array();
		gen_vdiskCurURIArr = gen_formComponentURI(gen_vdiskCurKeysArr,gen_ArrLength,gen_totalValue);
	}else if(reqKey == gen_const.PENOBJ){
		gen_vdiskPenKeysArr = new Array();
		gen_vdiskPenKeysArr = vdiskKeyArr;
		gen_vdiskPenURIArr = new Array();
		gen_vdiskPenURIArr = gen_formComponentURI(gen_vdiskPenKeysArr,gen_ArrLength,gen_totalValue);
	}
	return gen_ArrLength;
}
function gen_ValidateVDkeysData(reqKey){
	var rVal = false;
	if(reqKey == gen_const.CUROBJ){
		if(gen_vdiskCurURIArr != undefined && gen_vdiskCurURIArr != null && gen_vdiskCurURIArr != ''){
			if(gen_vdiskCurURIArr.length){
				rVal = true;
				return rVal;
			}
		}
	}else if(reqKey == gen_const.PENOBJ){
		if(gen_vdiskPenURIArr != undefined && gen_vdiskPenURIArr != null && gen_vdiskPenURIArr != ''){
			if(gen_vdiskPenURIArr.length){
				rVal = true;
				return rVal;
			}
		}
	}
	return rVal;
}
function gen_GetAdapterChilds(adapterSel,devURL,keysProps,range){
	var compURL='';
	if(devURL == controllerURL){
		compURL = devURL+"/"+adapterSel;
	}else{
		compURL = devURL+"?controller="+adapterSel;
	}
	gen_DevInfo(compURL,range,keysProps);
}
function DisplayPendingOperations(adapter){
	var tmpValue = processPendingOperations(adapter,"tbody_po_main_id");
	if(tmpValue){
		$('po_containerAlert').parentNode.parentNode.style.display = 'none';
	}else{
		inPageAlertContainer=$('po_containerAlert');
		containerAlertMsg(Localization.getLocaleNewMessageForID('RAC0745'));
	}
	modalDialog.show('modalDivInfo_po_info', 'modalDialogInfo_po_info');
}
function gen_CheckAdapterPO(adapter,tableid){
	/*Below function is common for displaying po and for calculating po
	  .Hence need to pass table id. Clearing the table data, as the check
	  is only for existence of PO and not displaying PO*/
	processPendingOperations(adapter,tableid);
	Table.clearAdvTableData($(tableid));
}
function gen_showJobSuccess(e){
	var jobKey;
	if(e.Jobqueue.Commit.joburi != null && e.Jobqueue.Commit.joburi != undefined && e.Jobqueue.Commit.joburi != ''){
		jobKey = e.Jobqueue.Commit.joburi;
		jobKey = jobKey.substring(jobKey.lastIndexOf('/')+1,jobKey.length);
	}else{
		jobKey = Localization.getLocaleStringForID("info_not_available");
	}
	gen_msgObj = Localization.getLocaleNewMessageForID('RAC0609');
	gen_msgTemplate = new Template(gen_msgObj.Message);
	gen_show = {jobID: jobKey};
	var _msg = (gen_msgObj.id+": "+ gen_msgTemplate.evaluate(gen_show)  + ' <br /><br /> ' + gen_msgObj.ResponseAction);
	gen_showSuccessBox(_msg);
}
function gen_showSuccessBox(msg){
	$('successMessage').innerHTML = msg;
	$('modalDialogSuccess').className = "ok_modal";
	$('successTitle').innerHTML = Localization.getLocaleStringForID("Success");
	$('success_icon').className="ok";
	modalDialog.show('modalDivSuccess', 'modalDialogSuccess');
}
function gen_showExceptions(logMsg,devURL,msgId){
	progressBar.hide();
	var log = logMsg+devURL;
	console.log(log);
	NewpageAlertMsg(Localization.getLocaleNewMessageForID(msgId),1);
}
function gen_showErrorsOfDataReception(msgId,divNumber){
	/*Show errors in the reception of data. Data reception might be on page load or while fetching pending operations*/
	/*Page load errors might not be required to show, as currently all the pd,vd,enclosure data is fetched to process pending operations*/
	/*Depending upon page context, displaying errors will be correct. Example: Enclosure seup does not require to show error on getting
	 vdisk data on page load. But for getting pending operations, the same vdisk url fails, need to show error,even though its from enclosure setup page*/
	/*Once pending operations value is available from LL-RE, fetching all data on page load may not be required*/
	if(view_po){
		NewpageAlertMsg(Localization.getLocaleNewMessageForID(msgId),divNumber);
	}
}
function InitCalendarArrays(){
	gen_jobTypeArr = [[Localization.getLocaleStringForID("apply_immediately"), 0x00], [Localization.getLocaleStringForID("apply_on_next_reboot"), 0x01],[Localization.getLocaleStringForID("apply_at_scheduled_time"), 0x02],[Localization.getLocaleStringForID("add_to_pendingoperations"), 0x03]];

	gen_powerCycleOptionsArr = [[Localization.getLocaleStringForID("graceful_shutdown"), 42],[Localization.getLocaleStringForID("force_shutdown"), 41],[Localization.getLocaleStringForID("power_cycle_system"),40],[Localization.getLocaleStringForID("no_reboot"), 1]];

	gen_timeOptionsArr = [
		[Localization.getLocaleStringForID("select_time"), ""],["00:00","00:00"],["00:30","00:30"],["01:00","01:00"],["01:30","01:30"],["02:00","02:00"],["02:30","02:30"],["03:00","03:00"],["03:30","03:30"],["04:00","04:00"],["04:30","04:30"],["05:00","05:00"],["05:30","05:30"],
		["06:00","06:00"],["06:30","06:30"],["07:00","07:00"],["07:30","07:30"],["08:00","08:00"],["08:30","08:30"],["09:00","09:00"],["09:30","09:30"],["10:00","10:00"],["10:30","10:30"],["11:00","11:00"],["11:30","11:30"],["12:00","12:00"],["12:30","12:30"],
		["13:00","13:00"],["13:30","13:30"],["14:00","14:00"],["14:30","14:30"],["15:00","15:00"],["15:30","15:30"],["16:00","16:00"],["16:30","16:30"],["17:00","17:00"],["17:30","17:30"],["18:00","18:00"],["18:30","18:30"],["19:00","19:00"],["19:30","19:30"],
		["20:00","20:00"],["20:30","20:30"],["21:00","21:00"],["21:30","21:30"],["22:00","22:00"],["22:30","22:30"],["23:00","23:00"],["23:30","23:30"] ];
}
function gen_checkforLCState(){
	lifecycleURI = lifecycleURI.replace(/\#/g, "%23");
	gen_DevInfo(lifecycleURI,gen_const.NORANGE,gen_const.KEYS_PROP);
}
function gen_updateCompsArr(){
	/*This function is mainly used when there are multiple controllers and user changes controller,
	 Pdisk and vdisk arrays are re-initialized, as GUI FE gets these data in chunks*/
	gen_pdiskArr = new Array();pdisk_Arr = new Array();
	gen_pdiskArrPending = new Array();pdiskPending_Arr = new Array();
	gen_vdiskArr = new Array();vdisk_Arr = new Array();
	gen_vdiskArrPending = new Array();vdiskPending_Arr = new Array();
	gen_updateURIArr();
}
function gen_updateURIArr(){
	/*This function is mainly used when there are multiple controllers and user clicks po button,
	 Pdisk and vdisk arrays are re-initialized, as GUI FE gets these data in chunks*/
	gen_pdiskCurKeysArr = new Array();gen_pdiskPenKeysArr = new Array();
	gen_vdiskCurKeysArr = new Array();gen_vdiskPenKeysArr = new Array();
	gen_pdiskCurURIArr = new Array();gen_pdiskPenURIArr = new Array();
	gen_vdiskCurURIArr = new Array();gen_vdiskPenURIArr = new Array();
}
function gen_updateAdapterData(e,reqKey){
	if(reqKey == gen_const.CUROBJ){
		controller_Arr = new Array();
	}else if(reqKey == gen_const.PENOBJ){
		controllerPending_Arr = new Array();
	}
	for (var j in e){
		if((j.indexOf(gen_const.CUROBJ) != -1) && (reqKey == gen_const.CUROBJ)){
			controller_Arr[j] = e[j];
			controller_Arr[j].currentfqddkey = j;
			controller_Arr[j].pendingfqddkey = j.replace(gen_const.CUROBJ,gen_const.PENOBJ);
		}else if((j.indexOf(gen_const.PENOBJ) != -1) && (reqKey == gen_const.PENOBJ)){
			controllerPending_Arr[j] = e[j];
			controllerPending_Arr[j].pendingfqddkey = j;
			controllerPending_Arr[j].currentfqddkey = j.replace(gen_const.PENOBJ,gen_const.CUROBJ);
			if(gen_controllerArrPending != undefined && gen_controllerArrPending != null){
				gen_controllerArrPending[j] = controllerPending_Arr[j];
			}
		}
	}
}
function gen_updateEncData(e,reqKey){
	if(reqKey == gen_const.CUROBJ){
		enclosure_Arr = new Array();
	}else if(reqKey == gen_const.PENOBJ){
		enclosurePending_Arr = new Array();
	}
	for (var j in e){
		if((j.indexOf(gen_const.CUROBJ) != -1) && (reqKey == gen_const.CUROBJ)){
			enclosure_Arr[j] = e[j];
			enclosure_Arr[j].currentfqddkey = j;
			enclosure_Arr[j].pendingfqddkey = j.replace(gen_const.CUROBJ,gen_const.PENOBJ);
			enclosure_Arr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
		}else if((j.indexOf(gen_const.PENOBJ) != -1) && (reqKey == gen_const.PENOBJ)){
			enclosurePending_Arr[j] = e[j];
			enclosurePending_Arr[j].pendingfqddkey = j;
			enclosurePending_Arr[j].currentfqddkey = j.replace(gen_const.PENOBJ,gen_const.CUROBJ);
			enclosurePending_Arr[j].adapterfqddkey = getKeyFromURI(e[j].controllers, controllerURL);
		}
	}
}
function gen_updateEnclosureArr(value){
	enclosure_Arr = new Array();enclosurePending_Arr = new Array();
	if(value){
		gen_enclosureArr = new Array();gen_enclosureArrPending = new Array();
	}
}
function gen_updateControllerArr(){
	controller_Arr = new Array();controllerPending_Arr = new Array();
}
function gen_CheckJob(adapterArr,adapterKey,pageName){
	var jobValue = false;
		if(adapterArr != undefined && adapterArr != null){
			if(adapterKey != undefined && adapterKey != null && adapterKey != ''){
				if(adapterArr[adapterKey] != undefined && adapterArr[adapterKey] != null && adapterArr[adapterKey] != ''){
					if(adapterArr[adapterKey].commit_job == true){
						jobValue = true;
					}
				}else{
					console.log("ControllerArrPending is undefined. Probably lower layers are not sending pending key information.Occurred in page:"+pageName);
				}
			}else{
				console.log("pending key is undefined. Occurred in page:"+pageName);
			}
		}else{
			console.log("ControllerArrPending is undefined. Probably lower layers are not sending pending key information.Occurred in page:"+pageName);
		}
	return jobValue;
}
/*Storage device type identification*/
function gen_Identify_DevType(devKey){
	var pd = "physicaldisk";
	var vd = "virtualdisk";
	var enc = "enclosure";
	var cont = "controller";
	var pcidisk = "pciessd";
	var devtype = "unknown";

	try{
		var dKey = devKey.toUpperCase();
		/*Other than Software RAID: PERC, HBA, DIRECT disks, controllers, enclosures*/
		if(dKey.indexOf("EMBEDDED") == -1){
			if(dKey.indexOf(gen_const.VDISK) != -1){
				/*Virtual disk*/
				devtype = vd;
			}else if(dKey.indexOf(gen_const.PDISK) != -1){
				/*Physical disk and PCIe SSD*/
				if(dKey.indexOf("NONRAID") == -1){
					/*RAID disks*/
					if((dKey.indexOf("DISK.DIRECT") == -1) && (dKey.indexOf("PCI") == -1)){
						/*Bay disks aka Normal physical disks*/
						devtype = pd;
					}else if((dKey.indexOf("DISK.DIRECT") == -1) && (dKey.indexOf("PCIEEXTENDER") != -1)){
						/*PCIe SSD connected to PCIE extender */
						devtype = pcidisk;
					}else if((dKey.indexOf("DISK.DIRECT") != -1) && (dKey.indexOf("PCIE") != -1)){
						/*Direct PCIeSSD*/
						devtype = "direct"+pcidisk;
					}else if((dKey.indexOf("DISK.DIRECT") != -1) && (dKey.indexOf("PCIE") == -1)){
						/*Direct disk*/
						devtype = "direct"+pd;
					}
				}else{
					/*HANDLE HBA disks here*/
				}

			}else if(dKey.indexOf(gen_const.BP) != -1){
				/*enclosures*/

			}else if(dKey.indexOf(gen_const.ADAPTER) != -1){
				/*CONTROLLERS*/
			}
		}else{
			/*Handle Software RAID here*/
		}
		return devtype;
	}catch(err){
		return "unknown";
	}
}
