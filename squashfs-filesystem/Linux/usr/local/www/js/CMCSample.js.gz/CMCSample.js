﻿var duration = { duration: 0.1 };
var chassis_detail = false;
if (typeof document.observe == 'function') {
  //animation using scriptaculous and prototype
  document.observe("dom:loaded", function () {
    var ac = $('accordian_container');
        if (ac != null) {
    ac.observe('mouseover', function () { this.style.cursor = "pointer"; });
    ac.observe('mouseout', function () { this.style.cursor = "default"; });
    ac.observe('dblclick', function () { return false; });
    ac.observe('click', accordian_container_click);
        }
  });

  function accordian_container_click() {
    var obj = $('accordian_container');
    obj.toggleClassName('container_top_right_accordian_closed');
    if (obj.hasClassName('container_top_right_accordian_closed')) {
      Effect.SlideUp('system_summary');
      $('system_condition_icon').setStyle({ display: "none" });
      //hide all the annotation divs
      imageMap.hideAll();

    } else {
      Effect.SlideDown('system_summary');
      $('system_condition_icon').setStyle({ display: "inline" });
      //show all the annotation divs
      imageMap.showAll();
    }
    obj.select('div.container_gradient').first().toggleClassName('container_gradient_closed');
    obj.up().select('div.container_bottom').first().toggleClassName('container_bottom_closed');
    if (typeof pullTab.changePullTab == 'function') {
        setTimeout(function () { pullTab.changePullTab(); }, 300);
    }
  }
}
function showDetail(container) {
  var item = $(container);
  if (item != null && !chassis_detail) {
    //I would make an AJAX call to go get the data here.
    $('chassis_detail').innerHTML = item.innerHTML;
    $('right_panel').className = 'right_detail';
    $('detail_arrow').show();
    $('chassis_detail').show();
    $('chassis_summary').hide();
    $('summary_title').innerHTML = "Chassis Health / Detail";
    chassis_detail = true;
  }
}
function showSummary() {
  if (chassis_detail) {
    $('right_panel').className = 'right';
    $('detail_arrow').hide();
    $('chassis_detail').hide();
    $('chassis_summary').show();
    $('summary_title').innerHTML = "Chassis Health";
    chassis_detail = false;
    imageMap.removeOutline();
  }
}

