﻿var support = "Support";
var about = "About";
var logout = "Log out";
var version = "Version: 1.15.51";
var date = "Date: 04/02/2012";
var user = "User";
var privilege = "Admin"

var privilege = "256";

var userRights = "";
function userPriv(priv) {
    if (priv == 0) {
        return (true);
    }
    else {
        //took &amp; out and changed it to & so that is would work without XML transforms - REH
        var value = userRights & priv;
        //alert('userRights: ' + userRights + ', priv: ' + priv + ', value = ' + value);
        return (value == priv);
    }
}