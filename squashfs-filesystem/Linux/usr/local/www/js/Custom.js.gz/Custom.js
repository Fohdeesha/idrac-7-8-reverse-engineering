
var whtSpEnds = new RegExp("^\\s*|\\s*$", "g");
var whtSpMult = new RegExp("\\s\\s+", "g");
var _sortRevOrder;
var colIndex;
var count = 0;

var quickTableSort = {
  startSort: function(obj, id, col, rev, headers, footer, isDate) {
    this.sortStarted = true;
    obj.blur();
    obj.style.cursor = "wait";
    window.document.body.style.cursor = "wait";
    this.sortTable(id, col, rev, headers, footer, isDate);
    this.timer = setInterval(function() { quickTableSort.checkProgress(obj) }, 500);
    return this.sortStarted;
  },
  checkProgress: function(obj) {
    if (!this.sortStarted) {
      obj.style.cursor = "";
      window.document.body.style.cursor = "default";
      clearInterval(this.timer);
    }
  },
  SortCells: function (a, b) {
  	var magnitude = 0;
  	var a_v = quickTableSort.__getTextValue(a.cells[colIndex]);
  	var b_v = quickTableSort.__getTextValue(b.cells[colIndex]);
	if (a_v > b_v) {
		magnitude = 1;
	} else if  (a_v < b_v) {
		magnitude = -1;
	}
	return magnitude;
  },
  SortDateCells: function (a, b) {
  	var magnitude = 0;
  	var a_v = quickTableSort.__getDateTextValue(a.cells[colIndex]);
  	var b_v = quickTableSort.__getDateTextValue(b.cells[colIndex]);

  	var date1 = new Date(a_v);
  	var date2 = new Date(b_v);

	if (date1.getTime() > date2.getTime()) {
		magnitude = 1;
	} else if  (date1.getTime() < date2.getTime()) {
		magnitude = -1;
	}

	return magnitude;
  },
  sortTable: function(id, col, rev, headers, footer, isDate) {

    // Style class names.
    this.rowClsNm = "fill";
    this.colClsNm = "topsorted";
    this.colClsNmDesc = "topsorteddescend";

    if (document.ELEMENT_NODE == null) {
      document.ELEMENT_NODE = 1;
      document.TEXT_NODE = 3;
    }
    // Get the table or table section to sort.
    var tblEl = document.getElementById(id);

    // The first time this function is called for a given table, set up an
    // array of reverse sort flags.
    if (tblEl.reverseSort == null) {
      tblEl.reverseSort = new Array();
      // Also, assume the date/time column is initially sorted.
      tblEl.lastColumn = 4;
    }

    // If this column has not been sorted before, set the initial sort direction.
    if (tblEl.reverseSort[col] == null)
    { tblEl.reverseSort[col] = rev; }

    // If this column was the last one sorted, reverse its sort direction.
    if (col == tblEl.lastColumn)
    { tblEl.reverseSort[col] = !tblEl.reverseSort[col]; }

    // Remember this column as the last one sorted.
    tblEl.lastColumn = col;

    // Set the table display style to "none" - necessary for Netscape 6
    // browsers.
    var oldDsply = tblEl.style.display;
    tblEl.style.display = "none";


    // begin the sort
   	var aTable = tblEl;
   	//Get the table rows
   	var rows = aTable.rows;

   	//var headingRows = new Array();
   	var dataRows = new Array();
   	var allRows = new Array();
   	//JS interpreter doesn't seem to want to slice rows,
   	//  concat to a new array and slice that.
   	var TabLen = rows.length-footer;
   	for (var x=0; x<TabLen; x++) {
   		allRows[x] = rows[x];
   		if (x >= headers)
	   		dataRows[x-headers] = allRows[x];
   	}

   	colIndex = col;

   	if(!isDate) {
   	   dataRows.sort(quickTableSort.SortCells);
   	} else {
   	   dataRows.sort(quickTableSort.SortDateCells);
   	}

   	if (!tblEl.reverseSort[col]) {
   		//render data in ascending order
   	} else {
   		dataRows.reverse();
   	}

   	for (var x=headers; x < allRows.length-1; x++)
   	{
   		if (aTable.tBodies!=null)
	   		aTable.tBodies[0].insertBefore(dataRows[x-headers],aTable.rows[x]);
   	}

    // Make it look pretty.
    quickTableSort.__makePretty(tblEl, col, tblEl.reverseSort[col]);

    // Restore the table's display style.
    tblEl.style.display = oldDsply;

	oldDsply = null;

    tblEl = null;

    this.sortStarted = false;

  },
  __normalizeString: function(s) {

    // Regular expressions for normalizing white space.
    s = s.replace(whtSpMult, " ");  // Collapse any multiple whites space.
    s = s.replace(whtSpEnds, "");   // Remove leading or trailing white space.

    return s;
  },
  __getTextValue: function(el) {
    var i;
    var s;

    if ((el == null) || (el.childNodes == null))
    	return "";

    // Find and concatenate the values of all text nodes contained within the
    // element.
    s = "";
    for (i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType == document.TEXT_NODE)
      { s += el.childNodes[i].nodeValue; }
      else if (el.childNodes[i].nodeType == document.ELEMENT_NODE &&
             el.childNodes[i].tagName == "BR")
      { s += " "; }
      else
      { s += quickTableSort.__getTextValue(el.childNodes[i]); }
    }

    return quickTableSort.__normalizeString(s);
  },
__getDateTextValue: function(el) {
    var i;
    var s;

    if ((el == null) || (el.childNodes == null))
    	return "";

    // Find and concatenate the values of all text nodes contained within the
    // element.
    s = "";
    for (i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType == document.TEXT_NODE && el.className != "hidden")
      { s += el.childNodes[i].nodeValue; }
      else if (el.childNodes[i].nodeType == document.ELEMENT_NODE &&
             el.childNodes[i].tagName == "BR")
      { s += " "; }
      else
      { s += quickTableSort.__getDateTextValue(el.childNodes[i]); }
    }

    return quickTableSort.__normalizeString(s);
  },
  __compareValues: function(v1, v2) {
    var f1, f2;

    // If the values are numeric, convert them to floats.

    f1 = parseFloat(v1);
    f2 = parseFloat(v2);
    if (!isNaN(f1) && !isNaN(f2)) {
      v1 = f1;
      v2 = f2;
    }

    // Compare the two values.
    if (v1 == v2)
    { return 0; }
    if (v1 > v2)
    { return 1; }
    return -1;
  },
  __makePretty: function(tblEl, col, descendingsort) {
    // Regular expressions for setting class names.
    var rowTest = new RegExp(quickTableSort.rowClsNm, "gi");
    var colTest = new RegExp(quickTableSort.colClsNm, "gi");
    var colTestDescend = new RegExp(quickTableSort.colClsNmDesc, "gi");

    var i, j;
    var rowEl, cellEl;

    // Set style classes on each cell to alternate their appearance step the first and last cell in a row.
    for (i = 0; i < tblEl.rows.length; i++) {
      rowEl = tblEl.rows[i];
      rowEl.className = rowEl.className.replace(rowTest, "");
      if (i % 2 != 0)
      { rowEl.className += " " + quickTableSort.rowClsNm; }
      rowEl.className = quickTableSort.__normalizeString(rowEl.className);
    }

    // Find the table header and highlight the column that was sorted.
    var el = tblEl.tHead; //tblEl.parentNode.tHead;
    rowEl = el.rows[0];
    // Set style classes for each column as above.
    for (i = 0; i < rowEl.cells.length; i++) {
      cellEl = rowEl.cells[i];
      cellEl.className = cellEl.className.replace(colTest, "");
      cellEl.className = cellEl.className.replace(colTestDescend, "");
      // Highlight the header of the sorted column.
      if (i == col) {
        if (descendingsort)
        { cellEl.className += " " + quickTableSort.colClsNmDesc; }
        else
        { cellEl.className += " " + quickTableSort.colClsNm; }
      }
      cellEl.className = quickTableSort.__normalizeString(cellEl.className);
    }
  }
};

//This is for the Progress Bar
var progressBar = {
  show: function() {
    var modalpage = document.getElementById('progressPage');
    var modalgraphic = document.getElementById('progressGraphic');
    if (modalpage != null && modalgraphic != null) {
      modalgraphic.style.top = this.calculatepos();
      modalpage.style.display = "block";
      addEvent.add(window, "scroll", progressBar.setModalGraphic);
      addEvent.add(window, "resize", progressBar.setModalGraphic);
    }
  },
  hide: function() {
    var modalpage = document.getElementById('progressPage');
    if (modalpage != null) {
      modalpage.style.display = "none";
      addEvent.remove(window, "scroll", progressBar.setModalGraphic);
      addEvent.remove(window, "resize", progressBar.setModalGraphic);
    }
  },
  calculatepos: function() {
    var pos = 0;
    try {
      var viewheight = document.documentElement.clientHeight;
      var scrollheight = document.body.scrollHeight ? document.body.scrollHeight : document.documentElement.offsetHeight;
      var scrolltop = document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop;
      var viewportheight = scrollheight > viewheight ? scrollheight : viewheight;

      if (scrollheight > viewheight) {
        pos = viewheight * .5 - 100 + scrolltop;
      } else {
        pos = viewheight * .5 - 100;
      }
      if (pos < 0) {
      	pos = viewportheight * .5 - 100;
      }
      pos = pos + 'px'
    }
    catch (err) { }


    return pos;
  },
  setModalGraphic: function() {
    var modalgraphic = document.getElementById('progressGraphic');
    if (modalgraphic != null) {
      modalgraphic.style.top = progressBar.calculatepos();
    }
  }
};

var pullTab = {
  Debug: false,
  ra_resizeStart: function(e, splitter) {
    this.dragging = true;
    this.rightSectionMinWidth = 200;
    this.ra_splitter = splitter;
    splitter.parrentOffsetX = pullTab.ra_GetX(splitter.parentNode) + e.clientX - pullTab.ra_GetX(splitter);
    document.onmousemove = function(e) { if (!e) { e = window.event; } pullTab.ra_mouseMove(e); };
    document.onmouseup = function(e) { if (!e) { e = window.event; } pullTab.ra_resizeStop(e); };
    document.body.ondrag = function() { return !pullTab.dragging; };
    return false;
  },
  ra_GetX: function(oElement) {
    var x = 0;
    while (oElement != null) {
      x += oElement.offsetLeft;
      oElement = oElement.offsetParent;
    }
    return x;
  },
  ra_mouseMove: function(e) {
    var splitter = this.ra_splitter;
    x = e.clientX - splitter.parrentOffsetX;
    if (x >= splitter.parentNode.offsetWidth - splitter.offsetWidth - pullTab.rightSectionMinWidth) {
      x = splitter.parentNode.offsetWidth - splitter.offsetWidth - pullTab.rightSectionMinWidth;
    }
    splitter.style.left = x + "px";
    return false;
  },
  ra_resizeStop: function() {
    document.onmousemove = null;
    document.onmouseup = null;
    var frameset = top.document.getElementById("contentframeset");
    var splitter = this.ra_splitter;
    var cols = frameset.cols.split(',');
    cols[0] = parseInt(cols[0], 10);
    cols[0] += splitter.offsetLeft;
    cols[1] = '*';
    splitter.style.left = '0px';
    frameset.cols = cols.join(',');
    pullTab.dragging = false;
    //clear the document selection
    if (document.selection) { document.selection.empty(); }
    else if (window.getSelection)
    { window.getSelection().removeAllRanges(); }
  },
  changePullTab: function() {
    try {
      var viewwidth = document.documentElement.clientWidth;
      var viewheight = document.documentElement.clientHeight;
      var scrollwidth = document.body.scrollWidth ? document.body.scrollWidth : document.documentElement.offsetWidth;
      var scrollheight = document.body.scrollHeight ? document.body.scrollHeight : document.documentElement.offsetHeight;
      var scrolltop = document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop;
      var scrollleft = document.documentElement.scrollLeft ? document.documentElement.scrollLeft : document.body.scrollLeft;

      var viewportwidth = scrollwidth > viewwidth ? scrollwidth : viewwidth;
      var viewportheight = scrollheight > viewheight ? scrollheight : viewheight;

      var rightside = document.getElementById('rightside');
      if (rightside) {
        if (scrollheight > viewheight) {
          rightside.style.display = "none";
        }
        else {
          rightside.style.display = "block";
          rightside.style.height = viewportheight + 'px';
          rightside.style.right = scrollleft * -1 + 'px';
        }
      }
      var pullstrip = document.getElementById('pullstrip');
      if (pullstrip) {
        pullstrip.style.height = viewportheight + 'px';
        pullstrip.style.left = scrollleft + 'px';
      }

      //    var pulltab = document.getElementById('pulltab');
      //    if (pulltab) {
      //      var pos = 0;
      //      if (scrollheight > viewheight) {
      //        pos = scrollheight - viewheight - scrolltop + 42;
      //      } else {
      //        pos = 42;
      //      }
      //      pulltab.style.bottom = pos + 'px';
      //      pulltab.style.left = '5px';
      //    }
    }
    catch (e) { }
  }
};

//*********************************************//
// LCD and LED Object and Methods
//*******************************************//
var power_guage = {
    Capacity: 0,
    /*Warning Markers*/
    WarningMarkerId: 'power_guage_lower_marker',
    WarningMarkerTextId: 'power_guage_lower_text',
    WarningThreshold: 0,
    WarningThresholdPercent: 0,
    WarningThresholdTextPercent: 0,
    /*Critical Markers*/
    CriticalMarkerId: 'power_guage_upper_marker',
    CriticalMarkerTextId: 'power_guage_upper_text',
    CriticalThreshold: 0,
    CriticalThresholdPercent: 0,
    CriticalThresholdTextPercent: 0,
    /*Current Markers*/
    CurrentReadingMarkerId: 'power_guage_current_marker',
    CurrentReadingTextId: 'power_guage_current_marker_text',
    CurrentReadingPercent: 0,
    CurrentReadingTextPercent: 0,
    CurrentReading: 0,
    /*Budget Markers*/
    BudgetReadingMarkerId: 'power_guage_budget_marker',
    BudgetReadingTextId: 'power_guage_budget_marker_text',
    BudgetReadingPercent: 0,
    BudgetReadingTextPercent: 0,
    BudgetReading: 0,
    BudgetLicensed:0,
    /*Offsets*/
    offsetNoConflict: 1.7,
    offsetConflict: 5,

        setThresholds: function (warningPercentOfCapacity, criticalPercentofCapacity,capacity,warningThreshold,criticalThreshold) {
              power_guage.verifyThresholds(warningPercentOfCapacity, criticalPercentofCapacity,capacity,warningThreshold,criticalThreshold);
			  if(count == 0)
			  {
              power_guage.renderThresholds(warningPercentOfCapacity, criticalPercentofCapacity);
			  }else{
				$(power_guage.BudgetReadingMarkerId).hide();
				$(power_guage.BudgetReadingTextId).hide();
				$(power_guage.CurrentReadingMarkerId).hide();
				$(power_guage.CurrentReadingTextId).hide();
				$(power_guage.CriticalMarkerId).hide();
				$(power_guage.CriticalMarkerTextId).hide();
				$(power_guage.WarningMarkerId).hide();
				$(power_guage.WarningMarkerTextId).hide();
			  }


          },


    verifyThresholds: function (warningPercent, criticalPercent,capacity,warningThreshold,criticalThreshold) {
        try {
			power_guage.setMinMidMaxLabels(capacity);
			if(capacity == 0 || warningPercent == NaN || criticalPercent == NaN )
			{
				throw  maxThresholdError; //Maximum Threshold Error;
			}

      if(!(top.aimGetBoolPropObj['platform_bool_is_blade'] == "true")) { // BITS223968 - Minimum Threshold Error not applicable for for Blade Server
            if (parseInt(warningPercent) < 0 || parseInt(warningPercent) > 100 || parseInt(warningPercent) >= parseInt(criticalPercent)) {
				count++;
				throw  minThresholdError; //Minimum Threshold Error;
            }
            if (parseInt(criticalPercent) < 0 || parseInt(criticalPercent) > 100 || parseInt(criticalPercent) <= parseInt(warningPercent)) {
				count++;
                 throw  maxThresholdError; //Maximum Threshold Error;
            }
        }

            power_guage.Capacity = capacity;
            power_guage.WarningThresholdPercent = warningPercent;
            power_guage.WarningThreshold = warningThreshold;
            power_guage.CriticalThresholdPercent = criticalPercent;
            power_guage.CriticalThreshold = criticalThreshold;

        }
        catch (e) {
		   alert(e);
        }
    },

    setMinMidMaxLabels: function (capacity) {

				$('maxLabel').innerHTML = capacity;
				$('midLabel').innerHTML = capacity / 2;
				$('minLabel').innerHTML = 0;
    },
    renderThresholds: function (warningPercent, criticalPercent) {
        try {
            // BITS271514: Pink watermark line hovers outside the bar graph when Power Cap Policy reaches max end value; ie:100%
            if (power_guage.CriticalThresholdPercent > 99) power_guage.CriticalThresholdPercent = 99;

            $(power_guage.CriticalMarkerId).style.bottom = power_guage.CriticalThresholdPercent + '%';
            $(power_guage.CriticalMarkerTextId).innerHTML = power_guage.CriticalThreshold + " " + wattsUnit + " - " + failureThresholdLabel;
            power_guage.CriticalThresholdTextPercent = power_guage.CriticalThresholdPercent - power_guage.offsetNoConflict;
            $(power_guage.CriticalMarkerTextId).style.bottom = power_guage.CriticalThresholdTextPercent + "%";

            $(power_guage.WarningMarkerId).style.bottom = power_guage.WarningThresholdPercent + '%';
            $(power_guage.WarningMarkerTextId).innerHTML = power_guage.WarningThreshold + " " +  wattsUnit +" - " +warningThresholdLabel;
            power_guage.WarningThresholdTextPercent = power_guage.WarningThresholdPercent - power_guage.offsetNoConflict;
            $(power_guage.WarningMarkerTextId).style.bottom = power_guage.WarningThresholdTextPercent + '%';

	   $(power_guage.CriticalMarkerId).show();
	  $(power_guage.CriticalMarkerTextId).show();

	  $(power_guage.WarningMarkerId).show();
	  $(power_guage.WarningMarkerTextId).show();


            power_guage.adjustThresholds();
        }
        catch (e) {
            alert(e);
        }
    },


    resetPowerMeter: function()
   {
        $(power_guage.BudgetReadingMarkerId).hide();
       	$(power_guage.BudgetReadingTextId).hide();

        $(power_guage.CurrentReadingMarkerId).hide();
        $(power_guage.CurrentReadingTextId).hide();

	$(power_guage.CriticalMarkerId).hide();
	$(power_guage.CriticalMarkerTextId).hide();

	$(power_guage.WarningMarkerId).hide();
	$(power_guage.WarningMarkerTextId).hide();

        $('maxLabel').innerHTML = "";
        $('midLabel').innerHTML = ""
        $('minLabel').innerHTML = ""

   },


     setReadings: function (currentReading, budgetReading,isBlade,isBudgetLicensed) {

	power_guage.BudgetLicensed = isBudgetLicensed;
	if(count != 0)
	{
	$(power_guage.BudgetReadingMarkerId).hide();
				$(power_guage.BudgetReadingTextId).hide();
				$(power_guage.CurrentReadingMarkerId).hide();
				$(power_guage.CurrentReadingTextId).hide();
				$(power_guage.CriticalMarkerId).hide();
				$(power_guage.CriticalMarkerTextId).hide();
				$(power_guage.WarningMarkerId).hide();
				$(power_guage.WarningMarkerTextId).hide();
	}
	else{

		if (power_guage.BudgetLicensed == 0)
		{
				$(power_guage.BudgetReadingMarkerId).show();
				$(power_guage.BudgetReadingTextId).show();
		}
			$(power_guage.CurrentReadingMarkerId).show();
			$(power_guage.CurrentReadingTextId).show();

			power_guage.CurrentReadingPercent =power_guage.calPercentOfCapacity(currentReading);


			power_guage.CurrentReading = currentReading;
			$(power_guage.CurrentReadingMarkerId).style.bottom = power_guage.CurrentReadingPercent + '%';
			$(power_guage.CurrentReadingTextId).innerHTML = power_guage.CurrentReading +" " + wattsUnit + " - " +currentReadingLabel;
			power_guage.CurrentReadingTextPercent = power_guage.CurrentReadingPercent - power_guage.offsetNoConflict;
			$(power_guage.CurrentReadingTextId).style.bottom = power_guage.CurrentReadingTextPercent + "%";


		if (power_guage.BudgetLicensed == 0)
		{
				power_guage.BudgetReadingPercent =power_guage.calPercentOfCapacity(budgetReading);
				power_guage.BudgetReading = budgetReading;
				$(power_guage.BudgetReadingMarkerId).style.bottom = power_guage.BudgetReadingPercent + '%';
				$(power_guage.BudgetReadingTextId).innerHTML = power_guage.BudgetReading +" " + wattsUnit + " - " +powerBudgetLabel;
				power_guage.BudgetReadingTextPercent = power_guage.BudgetReadingPercent - power_guage.offsetNoConflict;
				$(power_guage.BudgetReadingTextId).style.bottom = power_guage.BudgetReadingTextPercent + "%";
		}

			power_guage.adjustReadings();
	}
    },

     adjustThresholds: function () {
        var critBottom = power_guage.percentToInt($(power_guage.CriticalMarkerTextId).style.bottom);
        var warnBottom = power_guage.percentToInt($(power_guage.WarningMarkerTextId).style.bottom);
        var difference = critBottom - warnBottom;

        if (difference >= power_guage.offsetConflict) {
            return;
        }

        var differential = (power_guage.offsetConflict - difference) / 2;

        $(power_guage.CriticalMarkerTextId).style.bottom = (critBottom + differential) + '%';
        $(power_guage.WarningMarkerTextId).style.bottom = (warnBottom - differential) + '%';
    },
    adjustReadings: function () {
        var readings = power_guage.createReadingsArray();

        for (var x = 0; x < readings.length; x++) {
            $(readings[x][0]).style.bottom = readings[x][2] + '%';

            if (x >= readings.length - 1) { continue; }

            var diff = power_guage.offsetConflict - (readings[x][2] - readings[x + 1][2]);

            if (diff > 0) {
                readings[x + 1][2] = readings[x + 1][2] - diff;
            }
        }
          diff = 0;
        //Now adjust for the bottom of the guage
        if (readings.length > 0) {
            var pushDelta = 0;
            for (var x = 0; x < readings.length; x++) {
                var tmpPush = (readings[x][2] * -1) + 1;
                if (tmpPush > pushDelta) {
                    pushDelta = tmpPush;
                }
            }

            if (pushDelta > 0) {
                for (var x = readings.length - 1; x >= 0; x--) {
                    if (readings[x][2] <= 0) {
                        readings[x][2] = readings[x][2] + pushDelta;
                        if (x != readings.length - 1) {
                            diff = power_guage.offsetConflict - (readings[x + 1][2] - readings[x][2]);
                        }
                        if (diff > 0) {
                            readings[x][2] = readings[x][2] + diff;
                        }
                    }
                    $(readings[x][0]).style.bottom = readings[x][2] + '%';
                    if (x != 0) {
                        diff = power_guage.offsetConflict + (readings[x][2] - readings[x - 1][2]);
                        if (diff > 0) {
                            readings[x - 1][2] = readings[x - 1][2] + diff;
                        }
                    }
                }
            }
        }

    },
    createReadingsArray: function () {
        var orderTemp = new Array();

        orderTemp.push(new Array(power_guage.CriticalMarkerTextId, power_guage.CriticalThreshold, power_guage.percentToInt($(power_guage.CriticalMarkerTextId).style.bottom)));
        orderTemp.push(new Array(power_guage.WarningMarkerTextId, power_guage.WarningThreshold, power_guage.percentToInt($(power_guage.WarningMarkerTextId).style.bottom)));
        orderTemp.push(new Array(power_guage.CurrentReadingTextId, power_guage.CurrentReading, power_guage.percentToInt($(power_guage.CurrentReadingTextId).style.bottom)));
	if (power_guage.BudgetLicensed == 0)
        	orderTemp.push(new Array(power_guage.BudgetReadingTextId, power_guage.BudgetReading, power_guage.percentToInt($(power_guage.BudgetReadingTextId).style.bottom)));

        orderTemp = power_guage.sort(orderTemp);
        orderTemp.reverse();

        return orderTemp;
    },
    sort: function (arr) {
        for (i = 0; i < arr.length; i++) {
            tmp = arr[i];
            for (j = i - 1; j >= 0 && parseInt(arr[j][1]) > parseInt(tmp[1]); j--) {
                arr[j + 1] = arr[j];
            }
            arr[j + 1] = tmp;
        }

        return arr;
    },

    calPercentOfCapacity: function (val)
    {
         if (power_guage.Capacity != 0)
        {
             var percentOfCapacity = val / power_guage.Capacity * 100;
            return Math.round(percentOfCapacity * 100) / 100;
         }
            else
                    return 0;

      },

    percentToInt: function (percent) {
        if (percent.indexOf("%") <= 0)
            throw "Error Converting Percent to Integer"
        return parseInt(percent.replace('%', ''));
    }
}
