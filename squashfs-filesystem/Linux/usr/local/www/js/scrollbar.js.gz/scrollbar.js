﻿var scrollBar = {
    setupScrollBars: function (item) {
        setupScrollArea(item);
    }
};

var slidersArr = [];

function setupScrollArea(item) {

    var scrollbarId = item.id + '_scrollbar_track';

    // make sure needed divs exist, and item is displayed ie. width > 0

    if (item && (item.getWidth() > 0) && item.down('.scrollAreaInnerContainer') && item.down('.scrollAreaContent') && $(scrollbarId)) {
        // reset area content position
        item.down('.scrollAreaContent').setStyle({ left: '0px' });

        //alert(item.down('.scrollAreaContent').getWidth() + '                  ' + item.down('.scrollAreaInnerContainer').getWidth())
        if (item.down('.scrollAreaContent').getWidth() > item.down('.scrollAreaInnerContainer').getWidth()) {
            // show scrollbar
            $(scrollbarId).show();
            $(scrollbarId).removeClassName('disabled');
            $(scrollbarId).down('.scrollBarHandle').show();

            // destroy slider, if it already exists
            if (slidersArr[item.id]) {
                slidersArr[item.id].dispose();
                slidersArr[item.id] = null;
            }

            // setup slider object
            slidersArr[item.id] = new Control.Slider($(scrollbarId).down('.scrollBarHandle'), $(scrollbarId), {
                range: $R(0, (item.down('.scrollAreaContent').getWidth() - item.down('.scrollAreaInnerContainer').getWidth())),
                sliderValue: 0,
                onSlide: function (value) {
                    item.down('.scrollAreaContent').setStyle({ left: -value + 'px' });
                },
                onChange: function (value) {
                    item.down('.scrollAreaContent').setStyle({ left: -value + 'px' });
                }
            });
        } else {
            // hide scrollba
            $(scrollbarId).hide();
        }
    }
}

function disableScrollbar(item) {

    var scrollbarId = item.id + '_scrollbar_track';

    // make sure needed divs exist, and item is displayed ie. width > 0
    if (item && (item.getWidth() > 0) && item.down('.scrollAreaInnerContainer') && item.down('.scrollAreaContent') && $(scrollbarId)) {
        // reset area content position
        item.down('.scrollAreaContent').setStyle({ left: '0px' });


        // disable slider, if it already exists
        if (slidersArr[item.id]) {
            slidersArr[item.id].setValue(0);
            slidersArr[item.id].setDisabled();

            $(scrollbarId).addClassName('disabled');

            if ($(scrollbarId).down('.scrollBarHandle')) {
                $(scrollbarId).down('.scrollBarHandle').hide();
            }
        }
    }

}