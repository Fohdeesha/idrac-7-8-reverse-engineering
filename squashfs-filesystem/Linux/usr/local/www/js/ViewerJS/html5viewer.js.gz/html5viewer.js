/* Copyright 2015 Avocent Corporation and its affiliates.
 *  All Rights Reserved.
 *
 *  This is Example code, and is provided "as is".  Its 
 *  functionality is intended to be re-written and refined
 *  by a GUI design team.
 */
/******** Initialization Start **************************/

var mUsername;
var mPassword;
var mPort;
var mIPAddress;
var colorArgs = new Array(1, 2, 3, 4, 7, 9, 12, 15, 18, 21, 23); //array entries 0 - 3 are BW, 4 - 10 are color
var ColorArgsMax = colorArgs.length;
var bLaunchViewer = false;
var bLaunchVMedia = false;
var htmlViewer = null;
var dialogTitle = 'HTML5 Viewer';
var sharingTimeout = null;
var sessionUserList = null;
var bDragSettingDialog = false;
var bDragChatDialog = false;
var mediaDriveList = null;
var mediaDriveMapped = null;
var bSessionReadonly = false;
var viewerWidth;
var viewerHeight;
var clientWidth;
var clientHeight;
var html5ErrorFunc = null;
var html5ErrorCode = null;
var invData = [];

var mediaDriveList = null;
var mediaDriveMapped = null;

var bKeyboardFirstTime = true;

// clear local storage by default
localStorage.removeItem("VIEWER_CHAT_DATA");


var localeObj1;
localeObj1 = window.opener.top.localeObj;

/******** Initialization End **************************/

// text begins
var strConnectingViewer = EntityDecode(localeObj1['viewer_connectingViewer']);	// 'Connecting Viewer...'
var strViewerError = EntityDecode(localeObj1['viewer_errorOccurred']);			// 'A viewer error has occurred'
var strBadBrowserHTML5 = EntityDecode(localeObj1['viewer_badBrowserHTML5']);	// "Your browser is not compatible with HTML5 "
var strBadBrowserWS = EntityDecode(localeObj1['viewer_badBrowserWS']);			// "Your browser doesn't support websocket");
var strNoPopupBrowser = EntityDecode(localeObj1['viewer_NoPopupBrowser']);		// "Turn off your pop-up blocker and try again!");
var strReadOnlyViewer = EntityDecode(localeObj1['viewer_ReadOnlyGranted']);	// "Read Only privilege granted."
var strVideoCalibrating = EntityDecode(localeObj1['viewer_VideoCalibrating']);	// "Calibrating";
var strVideoNoSignal = EntityDecode(localeObj1['viewer_VideoNoSignal']);		// "No Signal";
var strVideoOutOfRange = EntityDecode(localeObj1['viewer_VideoOutOfRange']);	// "Out of Range";
var strVideoKVMDisabled = EntityDecode(localeObj1['viewer_VideoKVMDisabled']);	// "The remote vKVM feature\nhas been currently disabled\nby the local system administrator";
var strVideoBadRes = EntityDecode(localeObj1['viewer_VideoBadRes']);			// "Out of Range\nReason:Resolution Not Supported\nDetected Resolution:";
var strVideoVidCapFail = EntityDecode(localeObj1['viewer_VideoVidCapFail']);	// "Out of Range\nReason:Video Capture Failure\nDetected Resolution:";
var strVideoDetectColorDepth = EntityDecode(localeObj1['viewer_VideoDetectColorDepth']); // "Detected Color Depth":
var strVideoNoSignal = EntityDecode(localeObj1['viewer_VideoNoSignal']);		// "No Signal";
var strClientShutdown = EntityDecode(localeObj1['viewer_ClientShutdown']);		// "Client Has Been Shut Down Reason : ";
var strAdministratorDrop = EntityDecode(localeObj1['viewer_AdministratorDrop']); // "Administrator Disconnect";
var strTimeOut = EntityDecode(localeObj1['viewer_TimeOut']);					// "Exceeded Idle Time Out";
var strNetworkDrop = EntityDecode(localeObj1['viewer_NetworkDrop']);			// "The network connection has been dropped.";
var strApplianceReboot = EntityDecode(localeObj1['viewer_ApplianceReboot']);	// "Appliance Reboot";
var strDSRIQUpgrade = EntityDecode(localeObj1['viewer_DSRIQUpgrade']);			// "Pending DSRIQ Upgrade";
var strUserPreempt = EntityDecode(localeObj1['viewer_UserPreempt']);			// "Local User Channel Premption";
var strActiveUserGone = EntityDecode(localeObj1['viewer_ActiveUserGone']);		// "Last Active User Disconnection";
var strUserExclusiveMode = EntityDecode(localeObj1['viewer_UserExclusiveMode']); // "Primary User Getting into Exclusive Mode";
var strTerminated = EntityDecode(localeObj1['viewer_Terminated']);				// "The viewer has terminated.";
var strBadUserName = EntityDecode(localeObj1['viewer_BadUserName']);			// "Login failed.\n\nInvalid User name or Password.";
var strLoginDenied = EntityDecode(localeObj1['viewer_LoginDenied']);			// "Login denied";
var strMaxSessions = EntityDecode(localeObj1['viewer_MaxSessions']);			// "Login failed\n\nThe max number of session has been exceeded.";
var strSharingDenied = EntityDecode(localeObj1['viewer_SharingDenied']);		// "Sharing request has been denied.";
var strBadCert = EntityDecode(localeObj1['viewer_BadCert']);					// "Failed to connect viewer. Certificate may not be verified.";
var strCertTimeout = EntityDecode(localeObj1['viewer_CertTimeout']);			// "The session has timed out waiting for verification of the certificate.\nAll the connections will be closed.";
var strSocketException = EntityDecode(localeObj1['viewer_SocketException']);	// "Failed to connect viewer due to Websocket exception.";
var strLoginFailed = EntityDecode(localeObj1['viewer_LoginFailed']);				// "Login failed.";
var strSharingRequestTxt = EntityDecode(localeObj1['viewer_SharingRequestTxt']);	//"A connection request has been received from user: "
var strChatUserJoined = EntityDecode(localeObj1['viewer_ChatUserJoined']); 	// " User Has Joined.";
var strChatUserLeft = EntityDecode(localeObj1['viewer_ChatUserLeft']);			// " User has left.";
var strWantToShare = EntityDecode(localeObj1['viewer_WantToShare']);			// "A session to this device already exists. Do you want to try to share this session?";
var Alert_ok = EntityDecode(localeObj1['viewer_Alert_OK']);					// "OK"

var strNumIconTooltip = EntityDecode(localeObj1['viewer_NumIconTooltip']); // "Display Number Pad"
var strIncreaseIconTooltip = EntityDecode(localeObj1['viewer_IncreaseIconTooltip']); // "Increase keyboard size"
var strDecreaseIconTooltip = EntityDecode(localeObj1['viewer_DecreaseIconTooltip']); // "Decrease keyboard size"

var strMediaDetached = EntityDecode(localeObj1['vmedia_detached']);         // "Error Virtual Media is detached.  Please check your Attached Media settings and try again."
var shutdownVMMessage = EntityDecode(localeObj1['vmedia_shutdown']); 		// "Virtual Media has been shutdown as a result of :"
var shutdownVMMessage_socketException = EntityDecode(localeObj1['vmedia_shutdown_socketException']); // "Socket Exception "
var shutdownVMMessage_unkndown = EntityDecode(localeObj1['vmedia_shutdown_unknown']); // "a network error"
var strVMediaMaxSessions = EntityDecode(localeObj1['vmedia_MaxSessions']); //"Virtual Media is currently unavailable.\n\nA Virtual Media or Remote File Share session is in use."

var strReconnectingMsg = EntityDecode(localeObj1['reconnecting_status']);
var strLinkInterrupted = EntityDecode(localeObj1['link_interrupted']);
var strReconnectFailed = EntityDecode(localeObj1['vc_reconnect_failed']);

// text ends

// language
var strLanguage = window.opener.top.lang.toLowerCase();
// end language

var ALERT_TITLE = "";

if (isMobileBrowser())
{
    window.addEventListener("orientationchange",fitToScreen, false);
    
}
else
{
    bindEvent(window,'resize', fitToScreen);
}

/**
 * Function is used to resize the canvas based on browser's size.
 * 
 */
function fitToScreen()
{
    var parentDiv = document.getElementById("canvasParentDiv");
    viewerWidth = parentDiv.clientWidth;
    viewerHeight = parentDiv.clientHeight;
    if (htmlViewer !== null)
    {
        htmlViewer.setRPEmbeddedViewerSize(viewerWidth, viewerHeight);
    }


}

function bindEvent(el, eventName, eventHandler) {
  if (el.addEventListener){
    el.addEventListener(eventName, eventHandler, false);
  } else if (el.attachEvent){
    el.attachEvent('on'+eventName, eventHandler);
  }
}

 window.addEventListener("beforeunload",function(event){
    disconnectVM();
    exitViewer();
});

/**
 * 
 * This function will be called after page is loaded.
 */
function loadLoginPopup()
{
    document.getElementsByName("ddlTouchMode").value = 1;
    //loadSettingsTab();
    document.getElementById("ddlAspect").value = 0;
    //Create Object for RPViewer
    htmlViewer = new RPViewer("kvmCanvas", viewerAPIErrorCallback);
    htmlViewer.setRPDebugMode(true);
    //document.getElementById('version').innerHTML = "Version " + htmlViewer.getRPVersion();

}

/**
 * This function will be called to connect the viewer
 * 
 */
function launchKVM(user, pass, port, ip)
{
    if (html5ErrorCode !== null)
    {
        viewerAPIErrorCallback(html5ErrorFunc, html5ErrorCode);
        return;
    }
    
   var parentDiv = document.getElementById("canvasParentDiv");
   viewerWidth = parentDiv.clientWidth;
   viewerHeight = parentDiv.clientHeight;    

    
    //document.getElementById('login').style.display = 'none';


    sessionUserList = null;
    if (bLaunchViewer === false)
    {

        var tempUserName = user;
        var tempPassword = pass;
        mPort = port;
        mIPAddress = ip;

        mUsername = tempUserName;
        mPassword = tempPassword;
        //Configuration APIs
        htmlViewer.setRPCredential(tempUserName, tempPassword);
        htmlViewer.setRPServerConfiguration(mIPAddress, mPort);
        htmlViewer.setRPEmbeddedViewerSize(viewerWidth, viewerHeight);
        htmlViewer.setRPAllowSharingRequests(true);
        htmlViewer.setRPMouseInputSupport(true);
        htmlViewer.setRPTouchInputSupport(true);
        htmlViewer.setRPKeyboardInputSupport(true);
        htmlViewer.setRPDebugMode(true);
        htmlViewer.setRPMaintainAspectRatio(true);
        htmlViewer.setRPInitialBackgroundColor('burlywood');
        htmlViewer.setRPInitialMessageColor('black');
        htmlViewer.setRPKeyboardLanguage(strLanguage);

        htmlViewer.setRPVKNumIconTooltip(strNumIconTooltip);
        htmlViewer.setRPVKIncreaseIconTooltip(strIncreaseIconTooltip);
        htmlViewer.setRPVKDecreaseIconTooltip(strDecreaseIconTooltip);

        htmlViewer.setRPInitialMessage(strConnectingViewer);
             
        htmlViewer.setRPWebSocketTimeout(12); // set websocket timeout to 12 seconds


        //Setting Callbacks
        htmlViewer.registerRPLoginResponseCallback(loginResponseCallback);//
        htmlViewer.registerRPSharingRequestCallback(sharingRequestCallback);
        htmlViewer.registerRPSharedRequestCancelCallback(sharingCancelRequestCallback);
        htmlViewer.registerRPExitViewerCallback(exitViewerCallback);
        htmlViewer.registerRPUserListChangeCallback(userListChangeCallback);
        htmlViewer.registerRPColorModeChangeCallback(reportColorModeChange);
        htmlViewer.registerRPChatMessageCallback(chatMessageCallback);
        htmlViewer.registerRPMouseAccelerationChangeCallback(mouseAccelerationCallback);
        htmlViewer.registerRPSessionReadOnlyCallback(sessionReadonlyCallback);
        htmlViewer.registerRPSessionTerminationCallback(sessionTermCallback);
        htmlViewer.registerRPVideoStoppedCallback(videoStoppedCallback);
        htmlViewer.registerRPLEDKeyStatusCallback(ledStatusCallback);
        htmlViewer.registerRPInventoryCallback(inventoryCallback);
        //htmlViewer.registerRPUserInteractionCallback(userInteractionCallback);

        // VMedia Callbacks
        htmlViewer.registerRPVMLoginResponseCallback(loginVMCallback);
        htmlViewer.registerRPVMDeviceInfoUpdateCallback(vmDevicesCallback);
        htmlViewer.registerRPVMDeviceStatusUpdateCallback(statusVMDeviceCallback);
        htmlViewer.registerRPVMSessionDisconnectCallback(vmDisconnectCallback);
       //  htmlViewer.disableRPCertPopup();

        htmlViewer.setRPSupportReconnect(true);
        htmlViewer.setRPLinkInterruptMessage(strLinkInterrupted);
        htmlViewer.setRPReconnectingMessage(strReconnectingMsg);
        htmlViewer.setRPLinkInterruptMessageColor('red');
        htmlViewer.registerRPSessionStatusCallback(sessionStatusCallback);
        
        //Connect Viewer
        htmlViewer.connectRPViewer();
        bLaunchViewer = true;
    }
    else
    {
        bLaunchViewer = false;
        exitViewer();
    }
}

function disconnectKVM()
{
    bLaunchViewer = false;
    exitViewer();
    window.close();
}

function sessionStatusCallback(status)
{
    console.log('sessionStatusCallback status::'+status);
    switch(status) {
        case RPViewer.RP_SESSION_STATE.SESSION_LINK_INTERRUPTED:
            bLaunchViewer = false;
            closeChat();
            htmlViewer.closeRPVirtualKeyboard();            
            break;
        case RPViewer.RP_SESSION_STATE.SESSION_RUNNING:
        case RPViewer.RP_SESSION_STATE.SESSION_RETURNTONORMAL_FROM_LINK_INTERRUPT:
            bLaunchViewer = true;            
            break;
        case RPViewer.RP_SESSION_STATE.SESSION_RECONNECTING:
            bLaunchViewer = false;
            closeChat();
            htmlViewer.closeRPVirtualKeyboard();            
            break;
        case RPViewer.RP_SESSION_STATE.SESSION_RECONNECTED:
            bLaunchViewer = true;            
            break;
        case RPViewer.RP_SESSION_STATE.RECONNECT_FAILED:
            bLaunchViewer = false;
            closeChat();
            htmlViewer.closeRPVirtualKeyboard();            
            alert(strReconnectFailed);
            window.close();
            break;
    }
}


/**
 * Callback function for RPViewer API errors.
 * @param {type} errorFunctionName
 * @param {type} errorCode
 * 
 */
function viewerAPIErrorCallback(errorFunctionName, errorCode)
{
    //console.log('viewerAPIErrorCallback::errorFunctionName::' + errorFunctionName + " errorCode::" + errorCode);
    html5ErrorFunc = errorFunctionName;
    html5ErrorCode = errorCode;
    if (errorCode === RPViewer.RP_API_ERROR.HTML5_NOT_SUPPORTED_BY_BROWSER)
    {
        OrigAlert(strBadBrowserHTML5);
    }
    else if (errorCode === RPViewer.RP_API_ERROR.WEBSOCKET_NOT_SUPPORTED_BY_BROWSER)
    {
        OrigAlert(strBadBrowserWS);
    }
    else if (errorCode === RPViewer.RP_API_ERROR.POPUP_BLOCKED)
    {
        OrigAlert(strNoPopupBrowser);
    }
    else if (errorCode === RPViewer.RP_API_ERROR.INVALID_CANVAS_ID)
    {
        console.log("Invalid Canvas ID");
        OrigAlert(strViewerError);
    }
    else
    {
        console.log('API Error: Function Name:' + errorFunctionName + " Error Code:" + errorCode);
        OrigAlert(strViewerError);
    }
}

/**
 * Callback function for RPViewer user list change.
 * @param {type} userList
 * 
 */
function userListChangeCallback(userList)
{
    Logger.logDebug('myUserListChangeCallback No.of Users::' + userList.length);
    var i = 0;

    if (sessionUserList === null)
    {//if here, this is a new instance of a viewer
        if (userList.length === 1)
        {
            var chatMsgData = localStorage.getItem("VIEWER_CHAT_DATA");
            if (chatMsgData === null)
            {
                //Logger.logDebug('First userName:: '+userList[0].userName + " sessionID::"+userList[0].sessionID);
                var msg = userList[0].userName + ":" + userList[0].sessionID + strChatUserJoined;
                localStorage.setItem("VIEWER_CHAT_DATA", msg);
                //addRow(msg, true);
                addUserChangeRow(msg);
            }
        }
        else
        {
            for (i = 0; i < userList.length; i++)
            {
                var userRecord = userList[i];
                if (userRecord.isCurrentUser === false)
                {
                    var chatMsgData = localStorage.getItem("VIEWER_CHAT_DATA");
                    if (chatMsgData === null)
                    {
                        var msg = userList[i].userName + ":" + userList[i].sessionID + strChatUserJoined;
                        localStorage.setItem("VIEWER_CHAT_DATA", userList[i].userName + ":" + userList[i].sessionID + "User has Joined.");
                        //addRow(msg, false);
                		addUserChangeRow(msg);
                    }
                    break;
                }
            }
        }
    }
    else if (sessionUserList !== null)
    {   //not a new viewer session if here.
        Logger.logDebug('myUserListChangeCallback userList.length::' + userList.length + " sessionUserList.length::" + sessionUserList.length);
        if (userList.length > sessionUserList.length)//Someone has joined.
        {
            for (i = 0; i < userList.length; i++)
            {//Search for new user
                var bFound = false;
                var userRecord = userList[i];
                if (userRecord.isCurrentUser === false) //we know I am not the new user, so don't check "true".
                {
                    var newUserId = userRecord.userID;
                    var newSessionID = userRecord.sessionID;
                    //Check this user Id is already in the list
                    for (var j = 0; j < sessionUserList.length; j++)
                    {
                        var userOldRecord = sessionUserList[j];
                        if ((newUserId === userOldRecord.userID) && (newSessionID === userOldRecord.sessionID))
                        {
                            bFound = true;
                            Logger.logDebug('myUserListChangeCallback found Old user: ' + newUserId + "  " + newSessionID + " Skipping to next.");
                            break;
                        }
                    }
                    if(bFound) continue;   //check others in userList?
                }
            }
            if (bFound === false)
            {
                //This is the new user
                i--;
                var chatUserMsg = userList[i].userName + ":" + userList[i].sessionID + strChatUserJoined;
                Logger.logDebug('myUserListChangeCallback New user::' + chatUserMsg);
                var chatMsgData = localStorage.getItem("VIEWER_CHAT_DATA");
                chatMsgData += "�" + chatUserMsg;
                localStorage.setItem("VIEWER_CHAT_DATA", chatMsgData);
                //addRow(chatUserMsg, false);
                addUserChangeRow(chatUserMsg);
            } else {
                Logger.logDebug('myUserListChangeCallback *** ERROR: Expecting a new user and did not find one.');
            }
            
        }
        else
        {
            //Someone has left
            for (i = 0; i < sessionUserList.length; i++)
            {
                var userOldRecord = sessionUserList[i];
                if (userOldRecord.isCurrentUser === false)
                {
                    var exisUserId = userOldRecord.userID;
                    //Check this user still exists in uesrList
                    var bFound = false;
                    for (var j = 0; j < userList.length; j++)
                    {
                        var userRecord = userList[j];
                        if (exisUserId === userRecord.userID)
                        {
                            bFound = true;
                            break;
                        }
                    }

                    if (bFound === false)
                    {
                        var chatUserMsg = sessionUserList[i].userName + ":" + sessionUserList[i].sessionID + strChatUserLeft;
                        Logger.logDebug('myUserListChangeCallback ::' + chatUserMsg);
                        var chatMsgData = localStorage.getItem("VIEWER_CHAT_DATA");
                        chatMsgData += chatUserMsg;
                        localStorage.setItem("VIEWER_CHAT_DATA", chatMsgData);
                        //addRow(chatUserMsg, false);
               		 	addUserChangeRow(chatUserMsg);
                        break;
                    }
                }
            }
        }
    }

    sessionUserList = userList;
    for (var i = 0; i < userList.length; i++)
    {
        var userRecord = userList[i];
        console.log('actSession UserName:: ' + i + " " + userRecord.userName + " userID::" + userRecord.userID
                + " IPAddress:" + userRecord.ipAddress + " Current User:" + userRecord.isCurrentUser +
                " SessionId::" + userRecord.sessionID);
    }
}


/**
 * Callback function for login response 
 * @param {type} loginStatus
 * 
 */
function loginResponseCallback(loginStatus)
{
    console.log('loginResponseCallback::' + loginStatus);
    if (loginStatus === RPViewer.RP_LOGIN_RESULT.LOGIN_SUCCESS)
    {

       // document.getElementById("viewerButtons").style.display = 'inline';
        
        return;
    }
    if (loginStatus === RPViewer.RP_LOGIN_RESULT.LOGIN_INUSE)
    {
        console.log('another user is using session. sending sharing request');
        var confirmMsg = strWantToShare;
        var ans = tconfirm(confirmMsg);
        // console.log('confirm ans..'+ans);
        htmlViewer.requestRPSharedMode(ans);
        return;
    }               //shared session 
    else
    {
        reportLoginStatus(loginStatus, false); //report status via user exposed routine.
    }
}

/**
 * Callback function for session read-only info update
 * @param {type} bReadOnly
 * 
 */
function sessionReadonlyCallback(bReadOnly)
{
    bSessionReadonly = bReadOnly;
    if (bReadOnly)
    {
    	setReadOnlySession();
        alert(strReadOnlyViewer);
    }
}

/**
 * Callback function for session termination.
 * @param {type} reason
 * 
 */
function sessionTermCallback(reason)
{
    console.log('onSessionTermination...' + reason);
    reportTerminationReason(reason); //report status via user exposed routine.
}

/**
 * Callback function to update message for video stopped reasons.
 * @param {type} reason
 * @param {type} xRes
 * @param {type} yRes
 * @param {type} colorDepth
 * @returns {String}
 */
function videoStoppedCallback(reason, xRes, yRes, colorDepth)
{
    //Logger.logDebug('videoStoppedCallback...'+reason);
    var videoStoppedMsg;
    switch (reason)
    {
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_CALIBRATING:
            videoStoppedMsg = strVideoCalibrating;
            break;
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_NO_SIGNAL:
            videoStoppedMsg = strVideoNoSignal;
            break;
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_OUT_OF_RANGE:
            videoStoppedMsg = strVideoOutOfRange;
            break;
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_PERMISSION_DENIED:
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_BLOCKED:
            videoStoppedMsg = strVideoKVMDisabled;
            break;
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_RESOLUTION_NOT_SUPPORTED:
            videoStoppedMsg = strVideoBadRes;
            videoStoppedMsg += " " + xRes + "x" + yRes;
            break;
        case RPViewer.RP_VIDEO_STOPPED_REASON.VIDEO_CAPTURE_FAILED:
            videoStoppedMsg = strVideoVidCapFail;
            videoStoppedMsg += " " + xRes + "x" + yRes;
            videoStoppedMsg += "\n" + strVideoDetectColorDepth + colorDepth + "bpp";
            break;
        default:
            videoStoppedMsg = strVideoNoSignal;
            break;
    }

    return videoStoppedMsg;
}


/**
 * Callback function for user interaction status update.
 * @param {type} userInteraction
 * 
 */
function userInteractionCallback(userInteraction)
{
    console.log('userInteractionCallback..userInteraction::' + userInteraction);
}

/**
 * Callback function to update keyborad LED (Caps,Num,Scroll) status.
 * @param {type} bCapsOn
 * @param {type} bNumOn
 * @param {type} bScrollOn
 * 
 */
function ledStatusCallback(bCapsOn, bNumOn, bScrollOn)
{
    console.log('ledStatusCallback..bCapsOn::'+bCapsOn + "bNumOn::"+bNumOn + " bScrollOn::"+bScrollOn);
 /*   var capsElem = document.getElementById("capsStatusDiv");
    var numElem = document.getElementById("numStatusDiv");
    var ScrollElem = document.getElementById("scrollStatusDiv");
    if (bCapsOn)
    {
        capsElem.className = "led-green";
    }
    else
    {
        capsElem.className = "led-green-off";
    }
    if (bNumOn)
    {
        numElem.className = "led-green";
    }
    else
    {
        numElem.className = "led-green-off";
    }
    if (bScrollOn)
    {
        ScrollElem.className = "led-green";
    }
    else
    {
        ScrollElem.className = "led-green-off";
    }*/

}



/**
 * Callback function to update RPViewer inventory data.
 * @param {type} data
 * 
 */
function inventoryCallback(data)
{
    var jsonData = JSON.parse(data);
    var rootKey;
    invData.length = 0;
    for (var prop in jsonData) {
        if (typeof (jsonData[prop]) === 'object' && !(jsonData[prop] instanceof Array))
        {
            rootKey = prop;
            getInvValues(jsonData, rootKey);
        }
        else
        {
            var propName = "jsonobj." + prop;
            var propValue = jsonData[prop];
            invData.push({name: propName, value: propValue});
            //console.log(propName +" = "+ propValue);
        }

    }
}

/**
 * Function is used to push inventory data to an array
 * @param {type} json
 * @param {type} rootKey
 * 
 */
function getInvValues(json, rootKey)
{
    for (var key in json[rootKey])
    {
        for (var key1 in json[rootKey][key])
        {
            if (typeof json[rootKey][key][key1] === "object")
            {
                var arr = json[rootKey][key][key1];
                for (var prop in arr)
                {
                    if (typeof arr[prop] === "object")
                    {
                        for (var elem in arr[prop])
                        {
                            var propName = "jsonobj." + rootKey + "." + key + "." + key1 + "." + prop + "." + elem;
                            var propValue = arr[prop][elem];
                            invData.push({name: propName, value: propValue});
                            //console.log("jsonobj."+rootKey+ "."+  key + "." + key1  + "."+prop + "."+ elem + " = "+arr[prop][elem]);     
                        }

                    }
                    else
                    {
                        var propName = "jsonobj." + rootKey + "." + key + "." + key1 + "." + prop;
                        var propValue = arr[prop];
                        invData.push({name: propName, value: propValue});
                        //console.log( propName+ " = "+propValue); 
                    }
                }
            }
            else
            {
                var propName = "jsonobj." + rootKey + "." + key + "." + key1;
                var propValue = json[rootKey][key][key1];
                invData.push({name: propName, value: propValue});
                //console.log(propName + " = "+ propValue );
            }
        }
    }
}

/**
 * 
 * Function is used to display inventory data in a separate window.
 */
function showInventory()
{
    if (invData.length === 0)
    {
        console.log('Inventory data is not available.');
    }
    else
    {
        //window.open("inventory.html", "Inventory", "width=800,height=500,scrollbars=yes,left=200,top=200,resizable=yes");
    }

}


/**
 * 
 * Function is used close the RPViewer.
 */
function exitViewer()
{
	try {
		if ( window.opener )
			window.opener.htmlViewerWindow = null;
	} catch (e) { }
    
    if (htmlViewer !== null)
    {
        htmlViewer.closeRPViewerSession();
    }
}


/**
 * 
 * Callback function
 */
function exitViewerCallback()
{
	try {
	    //called on page unload, or indirectly from a disconnect button press.
	    invData.length = 0;
	    console.log('exitViewerCallback...');
	    bLaunchViewer = false;
	    bSessionReadonly = false;
	    localStorage.removeItem("VIEWER_CHAT_DATA");
	
	    //Close Chat window if already open
	    closeChat();
	/*
	    var chatTable = document.getElementById("messageTable");
	    chatTable.innerHTML = '';
	
	    sessionUserList = null;
	    document.getElementById("settingsDiv").style.display = 'none';
	    document.getElementById("viewerButtons").style.display = 'none';
	    if (document.getElementById('keyboardTd').style.display === 'none')
	    {
	        document.getElementById('keyboardTd').style.display = 'block';
	    }
	    document.getElementById("macroFieldSet").style.display = 'block';*/
	    addAllSettingsTabs();
	    loadLoginPopup();
	} catch (error) {
        return;
    }
}


/**
 * 
 * Function is used to build Settings dialog.
 */
function addAllSettingsTabs()
{
    var parentDiv = document.getElementById("tabsList");
    var scaleTab = document.getElementById("tabHeader_1");
    var touchTab = document.getElementById("tabHeader_2");
    if (touchTab === null)
    {
        touchTab = document.createElement("li");
        touchTab.appendChild(document.createTextNode("Touch"));
        touchTab.setAttribute("id", "tabHeader_2");
    }
    var mouseTab = document.getElementById("tabHeader_3");
    if (mouseTab === null)
    {
        mouseTab = document.createElement("li");
        mouseTab.appendChild(document.createTextNode("Mouse"));
        mouseTab.setAttribute("id", "tabHeader_3");
    }
    var colorTab = document.getElementById("tabHeader_4");
    if (colorTab === null)
    {
        colorTab = document.createElement("li");
        colorTab.appendChild(document.createTextNode("Color Mode"));
        colorTab.setAttribute("id", "tabHeader_4");
    }

    var perfTab = document.getElementById("tabHeader_5");
    if (perfTab === null)
    {
        perfTab = document.createElement("li");
        perfTab.appendChild(document.createTextNode("Performance"));
        perfTab.setAttribute("id", "tabHeader_5");
    }


    while (parentDiv.firstChild)
    {
        parentDiv.removeChild(parentDiv.firstChild);
    }

    parentDiv.appendChild(scaleTab);
    parentDiv.appendChild(touchTab);
    parentDiv.appendChild(mouseTab);
    parentDiv.appendChild(colorTab);
    parentDiv.appendChild(perfTab);



}


/**
 * 
 * Function is used to open Chat dialog
 */
function openChatDialog()
{

    var elem = document.getElementById("chatDiv");
    var chatText = document.getElementById('txtChat');
    if (elem.style.display !== 'block')
    {
        var headerelem = document.getElementById("chatHeader");
        headerelem.addEventListener('dragstart', drag_startChat, false);
        document.body.addEventListener('dragover', drag_overChat, false);
        document.body.addEventListener('drop', dropChat, false);

        elem.style.left = ((window.innerWidth / 2) - 100) + "px";
        elem.style.top = ((window.innerHeight / 2) - 50) + "px";
        elem.style.display = 'block';

        headerelem.addEventListener('touchmove', function (event)
        {
            var elem = document.getElementById("chatDiv");
            var touch = event.targetTouches[0];
            // Place element where the finger is
            elem.style.left = touch.pageX + 'px';
            elem.style.top = touch.pageY + 'px';
            event.preventDefault();
        }, false);
        if (htmlViewer !== null)
        {
            htmlViewer.setRPFocus(false);
        }
    }
    chatText.focus();
}


/**
 * 
 * Function is used to close the Chat dialog
 */
function closeChatDialog()
{
    var elem = document.getElementById("chatDiv");
    elem.style.display = 'none';
    var headerelem = document.getElementById("chatHeader");
    headerelem.removeEventListener('dragstart', drag_startChat, false);
    document.body.removeEventListener('dragover', drag_overChat, false);
    document.body.removeEventListener('drop', dropChat, false);
    if (htmlViewer !== null)
    {
        htmlViewer.setRPFocus(true);
    }

}

/**
 * 
 * Function is used to send Chat message
 */
function sendChatMsg()
{
    var chatText = document.getElementById('sendMessage');
    var msg = chatText.innerHTML;
     if(msg !==null && msg.length>0)
    {
    	// remove all <br>
    	msg = msg.replace(/<br?\/?>/g, ' ');
    	// replace &amp; with &
    	msg = msg.replace(/&amp;/g, '&');
        htmlViewer.sendRPChatMessage(EntityDecode(msg));
    }
    chatText.innerHTML = "";
    chatText.focus();
}

/**
 * Function is used to build row for Chat dialog
 * @param {type} message
 * @param {type} bCurrentUser
 * 
 */
 /*
function addRow(message, bCurrentUser)
{
    console.log('add Chat Row....');
    // Get a reference to the table
    var tableRef = document.getElementById("messageTable");
    var rowCount = tableRef.rows.length;
    // Insert a row in the table at row index 0
    var newRow = tableRef.insertRow(rowCount);
    // Insert a cell in the row at index 0
    var newCell1 = newRow.insertCell(0);
    if (bCurrentUser)
    {
        newCell1.className = "odd-row";
    }
    else
    {
        newCell1.className = "even-row";
    }

    newCell1.style.width = "100%";
    newCell1.innerHTML = message;

    var elem = document.getElementById("chatDiv");
    if (elem.style.display === 'block')
    {
        var dataDiv = document.getElementById("chatDataDiv");
        dataDiv.scrollTop = dataDiv.scrollHeight;
    }


}*/

/**
 * Callback function to update chat message.
 * @param {type} userName
 * @param {type} sessionId
 * @param {type} message
 * @param {type} bCurrentUser
 */
function chatMessageCallback(userName, sessionId, message, bCurrentUser)
{
    var str = "<b>" + userName + ":" + sessionId + "</b>   " + message;
    var chatMsgData = localStorage.getItem("VIEWER_CHAT_DATA");
    chatMsgData += "�" + str;
    localStorage.setItem("VIEWER_CHAT_DATA", chatMsgData);
    //addRow(str, bCurrentUser);
    //openChatDialog();
    openChat();
    
    addChatData(HTMLEncode(message.trim()), userName, sessionId, bCurrentUser);
    
}



/**
 * 
 * Function is used to show RPViewer in full screen mode.
 */
function showFullScreen()
{
    var bSupport = htmlViewer.showRPFullScreen();
    if (bSupport === false)
    {
        alert("Your browser doesn't support full screen mode");
    }
    else
    {
        fullScreen = true;
    }
}


/**
 * 
 * Function is used to apply selected color mode from the dropdown list for DVC platform.
 */
function applyColorMode()
{
    var x = document.getElementById("cboColorMode");
    var value_x = parseInt(x.value);
    if (value_x > 6)
    {
        htmlViewer.setRPVideoColorMode(value_x, true);
    }
    else
    {
        htmlViewer.setRPVideoColorMode(value_x, false);
    }
}


/**
 * 
 * Function is used to apply selected color from the slider for DVC platform.
 */
function applyColorQuality()
{
    var x = document.getElementById("vqVperf");
    var index_x = parseInt(x.value);
    if (index_x < ColorArgsMax)
    {
        var value_x = colorArgs[index_x];
        if (value_x > 6)
        {
            htmlViewer.setRPVideoColorMode(value_x, true);
        }
        else
        {
            htmlViewer.setRPVideoColorMode(value_x, false);
        }

    }
    else
    {
        Logger.logDebug('*** Color index too high: ' + index_x);
    }
}


/**
 * Function is used to determine the index of the selected macro. It
 * then makes a call to callMacro passing the appropriate index value.
 * 
 */
function applyMacro()
{
	if (bSessionReadonly)
		return;
		
    var x = document.getElementById("cboMacro");
    var macroIndex = x.selectedIndex; //this is a numerical index (from 0)
    var macroName = null;
    var macroLanguage = RPViewer.RP_VKEYBOARD_LANGUAGE.ENGLISH_EN;
    switch (macroIndex)
    {
        case 0://Ctrl+Alt+Del
            macroName = "Ctrl+Alt+Del";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_CONTROL_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_DELETE;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_CONTROL_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 1://Alt-Tab
            macroName = "Alt+Tab";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_TAB;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 2://Alt-Esc
            macroName = "Alt+Esc";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ESCAPE;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 3://Ctrl-Esc
            macroName = "Ctrl+Esc";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_CONTROL_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ESCAPE;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_CONTROL_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 4://Alt-Space
            macroName = "Alt+Space";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_SPACE;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 5://Alt-Enter
            macroName = "Alt+Enter";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ENTER;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 6://Alt-Hyphen
            macroName = "Alt+Hyphen";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_HYPHEN;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 7://Alt-F4
            macroName = "Alt+F4";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_F4;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 8://Prt Scr
            macroName = "Prt Scr";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_PRINTSCREEN;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            break;
        case 9://Alt + PrintScreen
            macroName = "Alt+PrintScreen";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_PRINTSCREEN;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 10://F1
            macroName = "F1";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_F1;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            break;
        case 11://Pause
            macroName = "Pause";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_PAUSE;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            break;
        case 12://Tab
            macroName = "Tab";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_TAB;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            break;
        case 13://Ctrl+Enter
            macroName = "Ctrl+Enter";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_CONTROL_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ENTER;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 14://SysRq
            macroName = "SysRq";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_PRINTSCREEN;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            break;
            case 15://Alt+SysRq+B
            macroName = "Alt+SysRq+B";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_PRINTSCREEN;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_B;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_PRINTSCREEN;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_ALT_LEFT;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_BREAK;
            break;
        case 16://Windows Start
            macroName = "Windows Start";
            macroName += "," + macroLanguage;
            macroName += "," + RPViewer.RP_KEY_NAMES.KEY_WINDOWS_START;
            macroName += "," + RPViewer.RP_MACRO_CONSTANT.KEY_MAKE_AND_BREAK;
            break;
    }

    htmlViewer.sendRPMacro(macroName);


}

function getAccelSelection()
{
    var list = document.getElementsByName("mouseAccer");
    for (var i = 0; i < list.length; i++) {
        if (list.item(i).checked) {
            return list.item(i).value;
        }
    }
}

function setAccelSelection(val)
{
    var list = document.getElementsByName("mouseAccer");
    for (var i = 0; i < list.length; i++) {
        if (list.item(i).value == val) {
            list.item(i).checked = true;
        } else {
            list.item(i).checked = false;
        }
    }
}

/**
 * 
 * Function is used to change mouse acceleration of RPViewer.
 */
function applyAcceleration()
{
    if (bSessionReadonly) {
        return;
    }
    htmlViewer.setRPMouseAccelerationMode(getAccelSelection());
    window.hasAppliedAcceleration = true;
}

/**
 * Function is used to report login status.
 * @param {type} loginStatus
 * 
 */
function reportLoginStatus(loginStatus, isVmedia)
{
    //report login exception status caught in notifications.js.  Reported 
    //here to allow customized handling.  0 <= loginStatus <= 15
    console.log('loginStatus::' + loginStatus);
    var message;
    var loginResult = RPViewer.RP_LOGIN_RESULT;
    switch (loginStatus)
    {
        case loginResult.LOGIN_INVALID_USER:
        case loginResult.LOGIN_INVALID_PASSWORD:
            message = strBadUserName;
            //message = ResourceManager.ConnectionDialog_LoginFailed_Invalid;
            break;
        case loginResult.LOGIN_DENIED:
            message = strLoginDenied;
            //message = ResourceManager.ConnectionDialog_AccessDenied;
            break;
        case loginResult.LOGIN_FULL:
    		message = ( isVmedia ? strVMediaMaxSessions : strMaxSessions );
            //message = ResourceManager.ConnectionDialog_NoChannelsAvailable;
            break;
        case loginResult.LOGIN_NOSHARE:
            message = strSharingDenied;
            //message = ResourceManager.ConnectionDialog_SharingDenied;
            break;
        case loginResult.LOGIN_CERTIFICATE_NOT_VERIFIED:
            message = strBadCert;
            break;
        case loginResult.LOGIN_CERTIFICATE_TIMEDOUT:
            message = strCertTimeout;
            break;
        case loginResult.LOGIN_WEBSOCKET_EXCEPTION:
            message = strSocketException;
            break;
        default:
            message = strLoginFailed;
            //message = ResourceManager.ConnectionDialog_LoginFailed;
            break;
    }
    if (message !== '')
    {
        OrigAlert(message);
    }

    if (isVmedia)
    {
        disconnectVM();
    }
    else {
        htmlViewer.closeRPViewerSession();
        window.close();
    }
}

/**
 * Function is used to report RPViewer terminate reason.
 * @param {type} messageNum
 * 
 */
function reportTerminationReason(messageNum)
{
    //report termination status caught in notifications.js.  Reported 
    //here to allow customized handling. 
    Logger.logDebug('Termination Reason::' + messageNum);
    var message = strClientShutdown;
    var shutdownReason = RPViewer.RP_SHUTDOWN_REASON;
    var reason;
    switch (messageNum)
    {
        case shutdownReason.SHUTDOWN_ADMIN:
            reason = strAdministratorDrop;
            break;
        case shutdownReason.SHUTDOWN_TIMEOUT:
            reason = strTimeOut;
            break;
        case shutdownReason.SHUTDOWN_WEBSOCKET:
            message = strNetworkDrop;
            reason = '';
            break;
        case shutdownReason.SHUTDOWN_REBOOT:
            reason = strApplianceReboot;
            break;
        case shutdownReason.SHUTDOWN_UPGRADE:
            reason = strDSRIQUpgrade;
            break;
        case shutdownReason.SHUTDOWN_PREEMPT:
            reason = strUserPreempt;
            break;
        case shutdownReason.SHUTDOWN_UNSHARE:
            reason = strActiveUserGone;
            break;
        case shutdownReason.SHUTDOWN_EXLUSIVE:
            reason = strUserExclusiveMode;
            break;
        default:
            message = strTerminated;
            reason = '';
            break;
    }
    message += reason;
    htmlViewer.closeRPViewerSession();
    OrigAlert(message);
    
    window.close();
}

/**
 * Function is used to change color mode based on color mode recevied from RPViewer.
 * @param {type} dvcColorMode
 * @param {type} dvcColorDepth
 * 
 */
function reportColorModeChange(dvcColorMode, dvcColorDepth)
{
    console.log('dvcColorMode:' + dvcColorMode + '   dvcColorDepth:' + dvcColorDepth);
    //the following is highly dependent upon the presence & layout of the "cboColorMode" selector DOM object.
    //the following is highly dependent upon the presence & layout of the "vqVperf" slider DOM object.
    var x = document.getElementById("cboColorMode");
    var y = document.getElementById("vqVperf");

    var colorDepth = RPViewer.RP_COLOR_DEPTH;

    if (dvcColorMode) {
        //x index is within 4 to 10
        //y array entries 0 - 3 are BW, 4 - 10 are color
        switch (dvcColorDepth) {
            case colorDepth.COLOR_7_BIT:
                if (x !== null)
                    x.options[4].selected = true;
                if (y !== null)
                    y.value = "4";
                break;

            case colorDepth.COLOR_9_BIT:
                if (x !== null)
                    x.options[5].selected = true;
                if (y !== null)
                    y.value = "5";
                break;

            case colorDepth.COLOR_12_BIT:
                if (x !== null)
                    x.options[6].selected = true;
                if (y !== null)
                    y.value = "6";
                break;

            case colorDepth.COLOR_18_BIT:
                if (x !== null)
                    x.options[8].selected = true;
                if (y !== null)
                    y.value = "8";
                break;

            case colorDepth.COLOR_21_BIT:
                if (x !== null)
                    x.options[9].selected = true;
                if (y !== null)
                    y.value = "9";
                break;

            case colorDepth.COLOR_23_BIT:
                if (x !== null)
                    x.options[10].selected = true;
                if (y !== null)
                    y.value = "10";
                break;

            case colorDepth.COLOR_15_BIT:
            default:
                if (x !== null)
                    x.options[7].selected = true;
                if (y !== null)
                    y.value = "7";
        }
    } else {
        //x index is within 0 - 3
        //y array entries 0 - 3 are BW, 4 - 10 are color
        switch (dvcColorDepth) {

            case colorDepth.GRAY_SCALE_16_SHADES:
                if (x !== null)
                    x.options[0].selected = true;
                if (y !== null)
                    y.value = "0";
                break;

            case colorDepth.GRAY_SCALE_32_SHADES:
                if (x !== null)
                    x.options[1].selected = true;
                if (y !== null)
                    y.value = "1";
                break;

            case colorDepth.GRAY_SCALE_64_SHADES:
                if (x !== null)
                    x.options[2].selected = true;
                if (y !== null)
                    y.value = "2";
                break;

            case colorDepth.GRAY_SCALE_128_SHADES:
            default:
                if (x !== null)
                    x.options[3].selected = true;
                if (y !== null)
                    y.value = "3";
        }
    }
}

/**
 * Callback function is used to update mouse acceleration value.
 * @param {type} val
 * 
 */
function mouseAccelerationCallback(val)
{
    var elem = document.getElementsByName("mouseAccer");
    if (elem !== null)
    {
        for (var i = 0; i < elem.length; i++)
        {
            if (elem[i].value == val)
            {
                elem[i].checked = true;
                break;
            }
        }
    }

}

/**
 * 
 * Function is used when canceling sharing, auto reject
 */
function sharingRejectAction()
{
	closeSharing();

    clearTimeout(sharingTimeout);
    htmlViewer.sendRPSharingResponse(RPViewer.RP_SESSION_SHARING.SHARING_REJECT);
}


/**
 * 
 * Function is used to handle sharing action.
 */
function sharingAction()
{
	closeSharing();

    clearTimeout(sharingTimeout);
    var actionVal;
    var radioElems = document.getElementsByName("rdoAction");
    if (radioElems[0].checked)
    {
        actionVal = RPViewer.RP_SESSION_SHARING.SHARING_ACCEPT;
    } else if (radioElems[1].checked)
    {
        actionVal = RPViewer.RP_SESSION_SHARING.SHARING_REJECT;
    } else
    {
        actionVal = RPViewer.RP_SESSION_SHARING.SHARING_PASSIVE;
    }
    htmlViewer.sendRPSharingResponse(actionVal);
}
/**
 * Close the sharing request dialog and 
 * send SHARING_TIMEOUT if user is not responded within 30 seconds. 
 *
 */
function sendSharingTimeout()
{
	closeSharing();
	
    sharingTimeout = null;
    htmlViewer.sendRPSharingResponse(RPViewer.RP_SESSION_SHARING.SHARING_TIMEOUT);
}


/**
 * Callback function to report sharing request.
 * @param {type} userName
 * 
 */
function sharingRequestCallback(userName)
{

    htmlViewer.exitRPFullScreen();
    console.log('sharingRequestCallback...userName::' + userName);
    
    var radioElems = document.getElementsByName("rdoAction");
    radioElems[1].checked = true; // default is  RP_SESSION_SHARING.SHARING_REJECT
    

    sharingTimeout = setTimeout("sendSharingTimeout()", 30000);
    var elem = document.getElementById("sharedDialog");
    var msgElem = document.getElementById("pHeader");
    
    if (msgElem)
	    msgElem.innerHTML = strSharingRequestTxt + userName;

	openSharing();
}


/**
 * 
 * Callback function to report sharing cancel request.
 */
function sharingCancelRequestCallback()
{
    console.log('sharingCancelRequestCallback.....');
    if (sharingTimeout !== null)
    {
        clearTimeout(sharingTimeout);
        sharingTimeout = null;
    }
    
	closeSharing();
}



/**
 * 
 * Function is used to request refresh RPViewer
 */
function sendRefresh()
{
    htmlViewer.requestRPRefresh();
}


/**
 * 
 * Function is used to request capture RPViewer screen shot.
 */
function captureScreenShot()
{
    htmlViewer.requestRPCaptureScreenShot();
}

/**
 * 
 * Function is used to show virtual keyboard
 */
function showKeyboard()
{
	if ( bKeyboardFirstTime )
	{
		bKeyboardFirstTime = false;
		
		
	    var parentDiv = document.getElementById("canvasParentDiv");
	    var viewerWidth = parentDiv.clientWidth;
	    var viewerHeight = parentDiv.clientHeight;
	    
	    var buttonBar = document.getElementById("buttonBarTop");
	    var mediaBar = document.getElementById("mediaBarTop");
	    
	    
	    var ButtonBarHeight = buttonBar.offsetHeight;
	    var MediaBarHeight = buttonBar.offsetHeight;
    
		var kbleft = ( viewerWidth - 640 ) / 2; // keyboard is 650 pixels sometimes...
		var kbtop = ( viewerHeight - 188 ) / 2; // keyboard is 188 pixels sometimes...
		
		kbtop = kbtop + ButtonBarHeight;
		if (bLaunchVMedia)
			kbtop = kbtop + MediaBarHeight;
		
		htmlViewer.setRPVirtualKeyboardPosition(kbleft, kbtop);
	}
	
    if (htmlViewer.isRPVirtualKeyboardPoppedUp())
    {
        htmlViewer.closeRPVirtualKeyboard();
    }
    else
    {
    	if (strLanguage == "de")
	        htmlViewer.showRPVirtualKeyboard(RPViewer.RP_VKEYBOARD_LANGUAGE.GERMAN_DE);
    	else if (strLanguage == "es")
	        htmlViewer.showRPVirtualKeyboard(RPViewer.RP_VKEYBOARD_LANGUAGE.SPANISH_ES_ES);
    	else if (strLanguage == "fr")
	        htmlViewer.showRPVirtualKeyboard(RPViewer.RP_VKEYBOARD_LANGUAGE.FRENCH_FR);
    	else if (strLanguage == "ja")
	        htmlViewer.showRPVirtualKeyboard(RPViewer.RP_VKEYBOARD_LANGUAGE.JAPANESE_JA);
    	else if (strLanguage == "zh")
	        htmlViewer.showRPVirtualKeyboard(RPViewer.RP_VKEYBOARD_LANGUAGE.CHINESE_ZH);
    	else
	        htmlViewer.showRPVirtualKeyboard(RPViewer.RP_VKEYBOARD_LANGUAGE.ENGLISH_EN);
    }
}

/*
 CHINESE_ZH        Simplified Chinese language
 DANISH_DA         Danish language
 DUTCH_NL          Dutch language
 ENGLISH_EN        English language
 FRENCH_FR         French language
 GERMAN_DE         German language
 ITALIAN_IT        Italian language
 JAPANESE_JA       Japanese language
 PORTUGUESE_PT     Continental Portuguese language
 PORTUGUESE_PT_BR  Brazilian Portuguese language
 SPANISH_ES_ES     Continental Spanish language
 SPANISH_ES_LA     Latin American Spanish language 
*/

/**
 * 
 * Function is used to change relative touch position option
 */
function changeMouse()
{
	if (bSessionReadonly)
		return;

    var elem = document.getElementById("ddlTouchMode");
    if (elem !== null)
    {
        if (elem.value == 1)  //direct
        {
            htmlViewer.setRPSupportRelativeTouchPosition(false);
        }
        else
        {
            htmlViewer.setRPSupportRelativeTouchPosition(true);  //relative
        }
    }

}

/**
 * 
 * Function is used to change aspect ratio status
 */
function changeRatio()
{
    var elem = document.getElementById("ddlAspect");
    if (elem !== null)
    {
        if (elem.value == 0)
        {
            htmlViewer.setRPMaintainAspectRatio(true);
        }
        else
        {
            htmlViewer.setRPMaintainAspectRatio(false);
        }
    }

    fitToScreen();

}

/* ----------------------- BEGIN VMEDIA ---------------------------- */
function launchVM() {
    if (htmlViewer != null) {
        if (bLaunchVMedia === false) {
            console.log('Launching VMedia ...');

            var bNeedTempCredentials = true;   // only ibm does not use temp credentials

            htmlViewer.setRPVMPort(mPort);
            htmlViewer.activateRPVMedia(bNeedTempCredentials);

            bLaunchVMedia = true;
        }

        //document.getElementById("btnVMedia").checked = bLaunchVMedia;
        //document.getElementById("btnVMedia").setAttribute("class", bLaunchVMedia ? "media_checked" : "media");
    }

}

function deActivateVM()
{
    if ( htmlViewer != null)
    {
        console.log('Closing VMedia ...');

        if (mediaDriveMapped != null)
        {
            htmlViewer.unMapRPDevice(mediaDriveMapped);
            mediaDriveMapped = null;
        }

        htmlViewer.deactivateRPVMedia();
        mediaDriveList = null;
        bLaunchVMedia =  false;
    }
}

function resetUSB()
{
    if (htmlViewer != null)
    {
        htmlViewer.requestRPVMResetUSB();
    }
}

MEDIA_CONNECTION_STATUS =
{
    "DISCONNECTED" : 0,
    "CONNECTING"   : 2,
    "CONNECTED"    : 3,
    "RECONNECTING" : 4
};

function getVMConnectionStatus()
{
    if (bLaunchVMedia && (mediaDriveList != null))
        return MEDIA_CONNECTION_STATUS.CONNECTED;
    if (bLaunchVMedia)
        return MEDIA_CONNECTION_STATUS.CONNECTING;
        
    return MEDIA_CONNECTION_STATUS.DISCONNECTED
}

/**
* Callback function for VMedia login response
* @param {type} loginStatus
*
*/
function loginVMCallback(loginStatus) {
    Logger.logDebug('loginVMCallback response::' + loginStatus);

    bLaunchVMedia = (loginStatus == RPViewer.RP_LOGIN_RESULT.LOGIN_SUCCESS);
    if (!bLaunchVMedia) {
        reportLoginStatus(loginStatus, true); //report status via user exposed routine.
    }
    //document.getElementById("btnVMedia").checked = bLaunchVMedia;
    //document.getElementById("btnVMedia").setAttribute("class", bLaunchVMedia ? "media_checked" : "media");
}

/**
* Callback function for VMedia device list change.
* @param {type} deviceList
*
*/
function vmDevicesCallback(deviceList) {
    Logger.logDebug('vmDevicesCallback No.of Devices::' + deviceList.length);

	if ( deviceList.length == 0 )
		mediaDriveList = null;
	
    // check the devices to see if i need to detach/ disconnect
    var count = 0;
    for (var i = 0; (i < deviceList.length); i++)
    {
        if (deviceList[i].deviceType != 0)
            count++;
    }

    if (count > 0) {
        mediaDriveList = deviceList;
        setDriveTypes();
    } else {
    	var timeout = 5000;
    	if (bLaunchVMedia == false)
    		timeout = 1000;
    	
        setTimeout(function() {
            finalCheckVMDevices();
        }, timeout);
    }
}

function finalCheckVMDevices()
{
    //if (bLaunchVMedia == false)
     //   return;
        
    if (mediaDriveList == null)
    {
        bLaunchVMedia = false;
        alert(strMediaDetached);
        disconnectVM();
    }
}

/**
* Callback function for VMedia device status change.
* @param {type} deviceList
*
*/

function statusVMDeviceCallback(deviceId, isMapped, statusRemote, statusLocal)
{
    Logger.logDebug('statusVMDeviceCallback Device::' + deviceId + ' ismapped:'+ isMapped + ' Status::' + statusRemote  + ' Local::' + statusLocal);

	// display an error
	if (! (((statusRemote == RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_OK)||(statusRemote == RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_STATUS_UNKNOWN)) &&
		  ((statusLocal == RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_OK)||(statusLocal == RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_STATUS_UNKNOWN))) )
	{
		var msgError = "Unspecified error";
		
		if ((statusRemote != RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_OK) &&
			(statusRemote != RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_STATUS_UNKNOWN))
		{
			switch (statusRemote)
			{
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_INVALID:
				msgError = "Command not supported";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_UNSUPPORTED:
				msgError = "Device not supported";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_DISCONNECTED:
				msgError = "Device not connected";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_DISABLED:
				msgError = "Drive disabled";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_ATTACHED:
				msgError = "Drive already attached";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_OPTION:
				msgError = "Unknown configuration option";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_DEVICE_ERROR:
				msgError = "Unknown cause";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_FAILED_REQUEST:
				msgError = "Request failed";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_FAILED_READ:
				msgError = "Read failed on device";
				break;
			case RPViewer.RP_MEDIA_REMOTE_STATUS.REMOTE_FAILED_WRITE:
				msgError = "Write failed device";
				break;
			}
		}
		
		if ((statusLocal != RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_OK) &&
			(statusLocal != RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_STATUS_UNKNOWN))
		{
			switch (statusLocal)
			{
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_DRIVE_INVALID:
				msgError = "Invalid drive identifer";
				break;
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_DRIVE_UNKNOWN:
				msgError = "Unknown file type";
				break;
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_DRIVE_UNSUPPORTED:
				msgError = "File type is not supported";
				break;
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_DRIVE_ERROR:
				msgError = "Unknown file error";
				break;
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_FAILED_READ:
				msgError = "Failed to read file";
				break;
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_SIZE_EMPTY:
				msgError = "The file contains no data";
				break;
			case RPViewer.RP_MEDIA_LOCAL_STATUS.LOCAL_SIZE_BIG:
				msgError = "The size of the selected file is greater than 2.8 MB.";
				break;
			}
		}
		
        Logger.logDebug('statusVMDeviceCallback call unmapFromServer ' + deviceId + " : " + msgError);
        unmapFromServer(deviceId);
	}
	else if ( isMapped == false )
	{
        Logger.logDebug('statusVMDeviceCallback call unmapFromServer ' + deviceId + " : no error");
        unmapFromServer(deviceId);
	}

}

function vmDisconnectCallback(reason) {
    Logger.logDebug('vmDisconnectCallback reason:' + reason);

	var strReason = shutdownVMMessage;
    // disconnected show reason and close.
    switch (reason)
    {
        case 0:
            //reasonTerminate = RPViewer.RP_SHUTDOWN_REASON.SHUTDOWN_ADMIN;
            strReason += strAdministratorDrop;
            break;
        case 1:
            //reasonTerminate = RPViewer.RP_SHUTDOWN_REASON.SHUTDOWN_TIMEOUT;
            strReason += strTimeOut;
            break;
        case 2:
            //reasonTerminate = RPViewer.RP_SHUTDOWN_REASON.SHUTDOWN_REBOOT;
            strReason += strApplianceReboot;
            break;
        case 3:
            //reasonTerminate = RPViewer.RP_SHUTDOWN_REASON.SHUTDOWN_UPGRADE;
            strReason += strDSRIQUpgrade;
            break;
        case ReconnectingWebSocket.ERROR_SOCKET_EXCEPTION:
            //reasonTerminate = RPViewer.RP_SHUTDOWN_REASON.SHUTDOWN_WEBSOCKET;
            strReason += shutdownVMMessage_socketException;
            break;
        default:
        	//RP_SHUTDOWN_REASON.SHUTDOWN_UNKNOWN
            strReason += shutdownVMMessage_unkndown + reason;
        	break;
    };
    alert(strReason);
    disconnectVM();
    
}

/* ----------------------- END   VMEDIA ---------------------------- */



/**
 * Function is used to check HTML5 local storage support
 * @returns {Boolean}
 */
function isSupportHTML5Storage()
{
    try {
        window.localStorage.setItem('checkLocalStorage', true);
        window.localStorage.removeItem('checkLocalStorage');
        return true;
    } catch (error) {
        return false;
    }
    ;
}
;

/**
 * Function is used to test whether the OS is Touch supported or not.
 * @returns {Boolean}
 */
function isTouchOS()
{
    var touchOS = false;

    if ('ontouchstart' in window)
    {
        touchOS = true;
    }
    else if ("PointerEvent" in window && navigator.maxTouchPoints > 0)
    {
        touchOS = true;
    }

    return touchOS;

}
;

/**
 * Function is used to test whether the browser is Mobile browser or not.
 * @returns {Boolean}
 */
function isMobileBrowser()
{

    if (navigator.userAgent.match(/Android/i)
            || navigator.userAgent.match(/webOS/i)
            || navigator.userAgent.match(/iPhone/i)
            || navigator.userAgent.match(/iPad/i)
            || navigator.userAgent.match(/iPod/i)
            || navigator.userAgent.match(/BlackBerry/i)
            || navigator.userAgent.match(/Windows Phone/i)
            ) {
        return true;
    }
    else {
        return false;
    }

}
;


