var browser = getBrowser();
var isProgressbar = false;
document.write("<meta http-equiv='cache-control' content='private'>");

function getBrowser() {
		if (navigator==null)
		{
				return null;
		}
		return navigator.appName;
}
//if( isIE() ) {
//    document.write( "<script type='text/javascript' src='./ie.js'></script>" );
//}
//else {
//    document.write( "<script type='text/javascript' src='./other.js'></script>" );
//}

function isIE5up() {
		if( browser == "Microsoft Internet Explorer" ) {
				return( true );
		}
		return( false );
}

function getInternetExplorerVersion()
// Returns the version of Internet Explorer or a -1
// (indicating the use of another browser).
{
	var rv = -1; // Return value assumes failure.
	if (navigator.appName == 'Microsoft Internet Explorer')
	{
		var ua = navigator.userAgent;
		var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
		if (re.exec(ua) != null)
			rv = parseFloat( RegExp.$1 );
	}
	return rv;
}

var AJAXDebug=0;

///////////
//  Function to generate progress image.  This would probably be replace
// with server side include.
//
function formatProgressPanel()
{
	//var txt = '<br><br><table id="progressTable" style="text-align: left; width: 585px; height: 77px;" border="0" cellpadding="2" cellspacing="2"><tbody><tr align="center"><td style="vertical-align: top;"><h1>'+ top.formatProgressMsg + '</h1></td></tr><tr align="center"><td style="vertical-align: top;"><img alt="Please wait" src="images/progress.gif" style="width: 111px; height: 14px;"><br></td></tr></tbody></table>';
	var txt = '<div id="progressPage"><div class="progressBackground"></div><div class="progressContainer"><div id="progressGraphic"></div></div></div>';
	document.write( txt );
	if(!isProgressbar){
		 progressBar.show(true);
		 isProgressbar = true;
	}
}


var requestCtxt = new Object();
requestCtxt.m_fieldMapping = null;
requestCtxt.updateComplete = null;
//
var FieldMapping;
FieldMapping.TYPE_HTML     = 0;
FieldMapping.TYPE_TEXT     = 1;
FieldMapping.TYPE_CHECKBOX = 2;
FieldMapping.TYPE_SELECT   = 3;
FieldMapping.TYPE_RADIO    = 4;
FieldMapping.TYPE_CALLBACK = 5;

var xmlRequestObject;

var Cell;
Cell.ICON       = 0;
Cell.CONTENT    = 1;
Cell.BLANK      = 2;
Cell.HIDDEN     = 3;

var Message_OK = "ok";
var Message_Caution = "nc";
var Message_Alert = "c";
var Message_Info = "info";

function Cell(type, value, align)
{
		this.m_type     = type;
		this.m_value    = value;
		this.m_align    = align;
}

///////////////////////////////////////////////////////////////
//
//Each field has a fieldName and a dataName.
//  The fieldName is used to map the field to the display value on a page,
//  if there is no field name then the field is only accessed on
//  edits.  In this way a page can iterate through all values returned by
//  the server to populate data for the page, but still skip element that
//  have no display value that would otherwise cause a "field xxxx not found"
//  message to be displayed.
function FieldMapping( n, d, type, encoder, decoder )
{
		//fieldName used for displaying data
		this.m_fieldName = n;
		//dataName used for updating data
		this.m_dataName = d == null ? n : d;
		this.m_type = type == null  ? FieldMapping.TYPE_HTML : type;
		this.m_encoder = encoder == null ? encodeText : encoder;
		this.m_decoder = decoder == null ? decodeText : decoder;
}

//Convenience object that "extends" FieldMapping with specific checkbox behaviors pre-defined.
function CheckboxMapping( n, d )
{
		return new FieldMapping(n, d, FieldMapping.TYPE_CHECKBOX, encodeCheckbox, decodeBoolean);
}

//Convenience object that "extends" FieldMapping with specific radio button behaviors pre-defined.
function RadioMapping( n, d )
{
		return new FieldMapping(n, d, FieldMapping.TYPE_RADIO, encodeRadio, decodeRadio);
}

/////////////////////////////////////
//
function encodeSetValue( text )
{
	 if( text == null )
		 return "";
	 else
	 {
		 var newUrl = text.replace(/\\/g, "\\\\" );
		 newUrl = newUrl.replace(/:/g, "\\:" );
		 //  ConnectionHandler's tokenizer uses:  (),=&?
		 newUrl = newUrl.replace(/,/g, "\\," );
		 newUrl = newUrl.replace(/\(/g, "\\(" );
		 newUrl = newUrl.replace(/\)/g, "\\)" );
		 newUrl = newUrl.replace(/\=/g, "\\=" );
		 newUrl = newUrl.replace(/&/g, "\\&" );
		 newUrl = newUrl.replace(/\?/g, "\\?" );

		 return encodeURIComponent(newUrl);
	 }
}

////////////////////////////////////
//  Function to encode text fields.
function encodeText( formElement )
{
		return encodeSetValue( formElement.value );
}

////////////////////////////////////
//  Function to encode checkbox's as 1=true or 0=false.
function encodeCheckbox( formElement )
{
		return formElement.checked ? "1" : "0";
}

////////////////////////////////////
//  Function to encode checkbox's as 1=true or 0=false.
function encodeSelect( formElement )
{
		if( formElement.selectedIndex >= 0 )
				{
				//alert("call to encodeSelect: " + formElement.options[ formElement.selectedIndex ].value);
				return formElement.options[ formElement.selectedIndex ].value;
				}
		else
				return '';
}

////////////////////////////////////
//  Function to encode checkbox's as 1=true or 0=false.
function encodeRadio( formElement )
{
		for( var i=0 ; i<formElement.length ; ++i )
		{
				if( formElement[i].checked )
						return formElement[i].value;
		}
		//
		return '';
		//return formElement.options[ formElement.selectedIndex ].value;
}

////////////////////////////////////
//  Function to encode checkbox's as 1=true or 0=false.
function decodeSelect( fieldMapping, value )
{
		var selectedIndex = -1;
		var elem = document.getElementById( fieldMapping.m_fieldName );
		if( elem != null & elem.options != null )
		{
				for( var i=0 ; i<elem.options.length ; ++i )
				{
						if( elem.options[i].value == value )
						{
								selectedIndex = i;
								break;
						}
				}
				//
				elem.options.selectedIndex = selectedIndex;
		}
}

///////////////////////////////////
//  Default decoder.
function decodeText( fieldMapping, value )
{
		var myVal = value;
		if (value == null) myVal = "";

		if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
			 setTextField( fieldMapping.m_fieldName, myVal );
		else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
			 setDiv( fieldMapping.m_fieldName, myVal );
			 //appendChild( fieldMapping.m_fieldName, myVal );
		else if( fieldMapping.m_type == FieldMapping.TYPE_SELECT )
			 setSelectedOption( fieldMapping.m_fieldName, myVal );
}

///////////////////////////////////
//  Decode Encryption string values
function decodeEncryption ( fieldMapping, value )
{
		var myVal = value;
		if (value == null) myVal = "";
		if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
			 setTextField( fieldMapping.m_fieldName, myVal );
		else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
			 setDiv( fieldMapping.m_fieldName, myVal );
		else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX )
		{
				var bVal = "1"; //true
				if (myVal == "NONE" || myVal == "0" || myVal == "") bVal = "0"; //false
				setCheckbox( fieldMapping.m_fieldName, bVal );
		}
}


///////////////////////////////////
//
function decodeBooleanNoneYes( fieldMapping, value )
{
		//alert("Decode bool yes/no: " + value );
		if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
			 setTextField( fieldMapping.m_fieldName, value == true ? top.yesStr : top.noneRole );
		else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
			 setDiv( fieldMapping.m_fieldName, value == true ? top.yesStr : top.noneRole );
			 //appendChild( fieldMapping.m_fieldName, value == true ? "Yes" : "None" );
		else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX )
			 setCheckbox( fieldMapping.m_fieldName, value );
}


///////////////////////////////////
//  Default decoder for boolean parameters.
function decodeBoolean( fieldMapping, value )
{
		//alert("Decode bool yes/no: " + value );
		if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
			 setTextField( fieldMapping.m_fieldName, value == true ? top.yesStr : top.noStr );
		else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
			 setDiv( fieldMapping.m_fieldName, value == true ? top.yesStr : top.noStr );
			 //appendChild( fieldMapping.m_fieldName, value == true ? "Yes" : "No" );
		else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX )
			 setCheckbox( fieldMapping.m_fieldName, value );
}

///////////////////////////////////
//  Default decoder for boolean parameters.
function decodeBooleanTrueFalse( fieldMapping, value )
{
		if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
			 setTextField( fieldMapping.m_fieldName, value == true ? top.trueStr : top.falseStr );
		else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
			 setDiv( fieldMapping.m_fieldName, value == true ? top.trueStr : top.falseStr );
			 //appendChild( fieldMapping.m_fieldName, value == true ? "true" : "false" );
		else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX )
			 setCheckbox( fieldMapping.m_fieldName, value );
//
}

///////////////////////////////////
//  Default decoder for boolean parameters.
function decodeBooleanEnabledDisabled( fieldMapping, value )
{
		if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
			 setTextField( fieldMapping.m_fieldName, value == true ? top.enabledStr : top.disabledStr );
		else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
			 setDiv( fieldMapping.m_fieldName, value == true ? top.enabledStr : top.disabledStr );
			 //appendChild( fieldMapping.m_fieldName, value == true ? "Enabled" : "Disabled" );
		else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX )
			 setCheckbox( fieldMapping.m_fieldName, value );
}

///////////////////////////////////
//
function decodeRadio( fieldMapping, value )
{
		if( value != null )
		{
				var elemList = document.getElementsByName( fieldMapping.m_fieldName );
				if( elemList != null )
				{
						for( var i=0 ; i<elemList.length ; ++i )
						{
							 if( elemList[i].value == value )
							 {
										elemList[i].checked = "true";
										break;
							 }
						}
				 }
		 }
}


////////////////////////////////////
//  Function to encode checkbox's as 1=true or 0=false.
// Mode: LDAP_Disabled(1), LDAP_MSAD(2), LDAP_Generic(3)
function encodeLDAPEnableMode( formElement )
{
		//alert(formElement.name + " checked: " + formElement.checked);
		if(formElement.name == "ADEnabled") {
			 return formElement.checked ? "2" : "1";
		} else if(formElement.name == "GLEnabled") {
			 return formElement.checked ? "3" : "1";
		}
}

///////////////////////////////////
//  Decoder for LDAP Enable Mode boolean parameters.
//   Mode: LDAP_Disabled(1), LDAP_MSAD(2), LDAP_Generic(3)
function decodeLDAPEnableMode( fieldMapping, value )
{
		//alert("Field name: " + fieldMapping.m_fieldName + " Decode LDAP mode: " + value );

		//Mode: LDAP_Disabled(1), LDAP_MSAD(2), LDAP_Generic(3)
		if(fieldMapping.m_fieldName == "ADEnabled") {
			 if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
					setTextField( fieldMapping.m_fieldName, value == "2" ? top.yesStr : top.noStr );
			 else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
					setDiv( fieldMapping.m_fieldName, value == "2" ? top.yesStr : top.noStr );
			 else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX ) {
					setCheckbox( fieldMapping.m_fieldName, value == "2" ? "1" : "0" );
			 }
		} else if(fieldMapping.m_fieldName == "GLEnabled") {
			 if( fieldMapping.m_type == FieldMapping.TYPE_TEXT )
					setTextField( fieldMapping.m_fieldName, value == "3" ? top.yesStr : top.noStr );
			 else if( fieldMapping.m_type == FieldMapping.TYPE_HTML )
					setDiv( fieldMapping.m_fieldName, value == "3" ? top.yesStr : top.noStr );
			 else if( fieldMapping.m_type == FieldMapping.TYPE_CHECKBOX ) {
					setCheckbox( fieldMapping.m_fieldName, value == "3" ? "1" : "0" );
			 }
		}
}

///////////////////////////////////
//  Decoder for BL Bind pwd.  Don't show it in summary page.
function decodeBindPwd( fieldMapping, value )
{
		//alert("Field name: " + fieldMapping.m_fieldName + " value: " + value );

		if(fieldMapping.m_fieldName == "GLBindPwd") {
			 if( fieldMapping.m_type == FieldMapping.TYPE_HTML ) {
					if(value == "" || value == null)
						 setDiv( fieldMapping.m_fieldName, "");
					else
						 setDiv( fieldMapping.m_fieldName, "********" );
			 }
	 }
}

//  This can be refactored into waitWithCallback
function setFieldListFromXML(xmlDoc)
{
		if (xmlDoc==null)
		{
				//Request failed
				//TODO: disable screen?
		}
		else
		{
				//  Set the fields.
				for( var i=0 ; i<fieldList.length ; ++i )
				{
						var dataName = fieldList[i].m_dataName;
						var paramValue = getXMLValue( xmlDoc, dataName ) ;
						//
						if( fieldList[i].m_type == FieldMapping.TYPE_CALLBACK )
								dataCallback( fieldList[i], paramValue, xmlDoc );
						else
								fieldList[i].m_decoder( fieldList[i], paramValue );
				}
		}  //end status==ok block
		//
		//hideElement( 'progressScreen' );
		progressBar.hide();
		isProgressbar = false;
		showInlineElement( 'contentArea' );
}

///////////////////////////////////////////////////////////////////
//
//  Show progress image in place of it the content panel
function showProgressPanel()
{
	hideElement( 'contentArea' );
	//showProgressBlockElement('progressScreen');
	if(!isProgressbar){
		 progressBar.show(true);
		 isProgressbar = true;
	}
}


///////////////////////////////////////////////////////////////////
//
//  Show progress image in place of it the content panel
function showContentPanel()
{
	//hideElement( 'progressScreen' );
	progressBar.hide();
	isProgressbar = false;
	showInlineElement( 'contentArea' );
}


///////////////////////////////////////////////////////////////////
//
//  Show or hide button
function showButton( buttonName, enable )
{
		if (buttonName == null) {}
		else
		{
				if (enable)
				{ // enable button
						buttonName.className = "container_button";
						buttonName.disabled = false;
				}
				else
				{ // disable button
						buttonName.className = "page_button_disabled";
						buttonName.disabled = true;
				}
		}
}



///////////////////////////////////////////////////////////////////
//
function loadData( renderPageCallback,_method )
{
		var reqUrl = 'data?get=';
		for( var i=0 ; i<fieldList.length ; ++i )
			 reqUrl += fieldList[i].m_dataName + ',';
		loadDataURL( reqUrl, renderPageCallback,_method );
 }

 //////////////////////////////////////////////////
 //
 function sendPost( reqUrl, postData, renderPageCallback )
 {
		if( renderPageCallback != null )
				document.chainedCallback = renderPageCallback;
		else
				document.chainedCallback = setFieldListFromXML
		//
		loadXMLDocument( reqUrl, waitWithCallback, postData );
 }

 //////////////////////////////////////////////////
 //
 function loadDataURL( reqUrl, renderPageCallback,_method )
 {
		if( renderPageCallback != null )
				document.chainedCallback = renderPageCallback;
		else
				document.chainedCallback = setFieldListFromXML
		//
		loadXMLDocument( reqUrl, waitWithCallback,null,_method );
 }

///////////////////////////////////////////////////////////////////
//
function formatPostRequest( formElement )
{
		var req = "";
		if( formElement.elements.length > 1 )
		{
				var elem = formElement.elements[0];
				req = elem.name + ":" + encodeSetValue( elem.value );
				//
				for( var i=1 ; i<formElement.elements.length ; ++i )
				{
						var elem = formElement.elements[i];
						req += ',' + elem.name + ":" + encodeSetValue( elem.value );
				}
		}
		return req;
}

/////////////////////////////////////////////////////////////////
//
function formatPostRequestForFields( formElement, fieldList )
{
		var req = "";
		var count = 0;
		for( var i=0 ; i<fieldList.length ; ++i )
		{
				if( fieldList[i] == null )
						continue;
				var field = fieldList[i];
				var encoder = fieldList[i].m_encoder;
				//
				var formElem = formElement[field.m_fieldName];
				//
				if( formElem != null && encoder != null )
				{
						if( count++ != 0 )
								req += ",";
						req += field.m_dataName + ":" + encoder( formElem );
				}
		}
		return req;
}

////////////////////////////////////////////////////////////////////
//
function getXMLValue( xmlDoc, elementName )
{
		//alert("getXMLValue( xmlDoc, " + elementName + ");");
		var rtn = "";
		var i;
		//
		if( xmlDoc == null || xmlDoc.childNodes.length == 0 )
		{
			//alert("Received bad XML document.");
		}
		else
		{
			 var elements = xmlDoc.getElementsByTagName( elementName );
			 //
			 if( elements != null && elements.length > 0  && elements[0].childNodes != null  )
			 {
					 if( elements[0].childNodes.length == 0 )
							 return null;
					 else if( elements[0].childNodes[0].nodeType == 3){
								var j = elements[0].childNodes.length;
								for (i = 0; i < j; i++){
										rtn = rtn + elements[0].childNodes[i].nodeValue;
								}
								//Fix for FireFox. Long returns are broken up into 4096 byte child nodes.  IE is all in one.
								//alert("rtn len=" + rtn.length + "ChildNode count=" + j + "\n" );
					 }
					 else {
							 rtn = elements[0];
					 }
			 }
		}
	 return rtn
 }
/****************************************************************
This version was changed by Adam G. and is commented out for now
because it doesn't work for a list of nodes, e.g. tempSensorList.
The version above is the old one.
////////////////////////////////////////////////////////////////////
//
//TODO:  there is something not quite right here.  If you have a node
//  with only one value then the data doesn't get returned correctly.
function getXMLValue( xmlDoc, elementName )
{
		//alert("getXMLValue( xmlDoc, " + elementName + ");");
		var rtn = null;
		//
		if( xmlDoc == null || xmlDoc.childNodes.length == 0 )
		{
			alert("Received bad XML document.");
		}
		else
		{
			 var elements = xmlDoc.getElementsByTagName( elementName );
			 //
			 if( elements != null && elements.length > 0 && elements[0].childNodes != null && elements[0].childNodes.length > 0 )
			 {
					 //if( elements[0].hasChildNodes )
					 //    alert(" Found(" + elements[0].tagName + "): " + elements[0] + ", with childCount: " + elements[0].childNodes.length + ", " + elements[0] );
					 //else
					 //    alert(" Element: " + elements[0].tagName + " does not have children.");
					 //
					 //The logic here wasn't quite right, at least not for returning XML
					 //  snippets.  Changed it so that if the requested element has a child
					 //  node that is text (e.g. <stuff>my text</stuff> would be an element
					 //  with a child that is text) return the text value, otherwise return
					 //  the element
					 if (elements[0].hasChildNodes)
					 {
								if (elements[0].childNodes[0].nodeType==3)
								{
										rtn = elements[0].childNodes[0].nodeValue;
								}
								else
								{
										rtn = elements[0]
								}
					 }
					 //Otherwise return the node itself...
					 else //if (elements[0].hasChildNodes())
					 {
							 //alert(" getXMLValue: " + elements[0].childNodes[0].childNodes.length );
							 rtn = elements[0];
					 }
					 //else
					 //{
							 //alert(" getXMLValue: " + elements[0].childNodes[0].nodeValue );
					 //    rtn = elements[0].childNodes[0].nodeValue;
					 //}
			 }
		}
		//
		return rtn;
}
***********************************************************************/

/////////////////////////////////////////////////////////////////////////
//
//  Requests the XML document.
//
//Lets load the WebPage defined by url ( output should be xml )r
//If we are using IE then we will use microsoft ActiveX Object, there are
//two microsoft objects we can try. If the first fails, move to second one.
//if not IE then we will use the defined JS object XMLHttpRequest().
//
function loadXMLDocument( url, callback, postData,_method )
{
		var xDoc;
		//
		if( window.XMLHttpRequest )
		{
				xmlRequestObject = new XMLHttpRequest();
		}
		else if( window.ActiveXObject )
		//     if( window.ActiveXObject )
		{
				try
				{
						xmlRequestObject = new ActiveXObject("Msxml2.XMLHTTP");
					 // alert("XMLHttpRequest is executed");
				}
				catch ( e )
				{
						try
						{
								xmlRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
						}
						catch ( E )
						{
						}
				}
		 }
		 //
		 if( xmlRequestObject )
		 {
				 xmlRequestObject.onreadystatechange = callback;
				xmlRequestObject.open("POST", url, true );

				 if( postData == null ) {  postData = ''; }

				 xmlRequestObject.setRequestHeader("Content-Type", "application/x-www-form-urlencoded" );
				 if (top.TOKEN_VALUE.length >= 8){ xmlRequestObject.setRequestHeader(top.TOKEN_NAME, top.TOKEN_VALUE ); }
				 xmlRequestObject.send( postData );
		 }
}


function refreshToken() {
		var element = document.getElementById("Token2Key");
		if (element != null) {
				element.name = top.TOKEN_NAME;
				element.value = top.TOKEN_VALUE;
		}
}


function refreshToken1() {
		var element = document.getElementById("Token1Key");
		if (element != null) {
				element.name = top.TOKEN_NAME1;
				element.value = top.TOKEN_VALUE1;
		}
}



function getXMLTagByName( xmlDoc, name )
{
		var tagList = xmlDoc.getElementsByTagName( name );
		var rtn = null;
		//
		if( tagList.length > 0 )
				rtn = tagList[0];
		return rtn;
}

function setTextField( fieldId, value )
{
		var elem = document.getElementById( fieldId );
		if( elem != null && elem.value != undefined )
			 {
					 if (value == null)
							 elem.value = '';
					 else
							elem.value = value;
			 }

//    else
//        showErrorMessage(" text field (" + fieldId + ") not found.");
}

function setDiv( fieldId, value )
{
		value = EntityDecode(value);

		//alert( "setDiv(" + fieldId + ", value=" + value + ")" );
		var elem = document.getElementById(fieldId);

				//this is the element in the HTML page
		if (elem != null)

		{
			 //if ("outerHTML" == elem)
			 if ("innerText" in elem && "outerHTML" in elem)
//if (elem.tagName == "PRE" && "outerHTML" in elem)
			 {
					//if (elem.parentNode.tagName == "PRE")
						//{
								//elem.outerHTML = ((value == null) ? "" : "<pre>" + value + "</pre>");
		//          elem.outerHTML = "<PRE>" + value + "</PRE>";
												elem.innerText= value;
								elem.textContent=value;
						//}
				//else
					 //{
								//elem["outerHTML"] = ((value == null) ? "" : value);

								//elem.outerHTML ="";
					 //}

				}
					//else if (elem.innerHTML != null)

					else
				{
						//elem.innerHTML = ((value == null) ? "" : value);
						elem.innerHTML = value;


				}
		}
//    if( elem != null && elem.value != undefined )
//    elem.innerHTML = value;
//    else
//        showErrorMessage(" div (" + fieldId + ") not found.");
				//return elem.value;
}

function setCheckbox( fieldId, value ) {
		var val = false;
		if( value != undefined )
			 val = trim(value) == "0" ? false : true;
		//
		var elem = document.getElementById( fieldId );
		if( elem != null && elem.checked != undefined )
			elem.checked = val == "0" ? false : true;
}

function setRadio( formElement, fieldName, value ) {
		var val = false;
		if( value != null )
		{
			for( var i=0 ; i<formElement.elements.length ; ++i )
			{
				 var elem = formElement.elements[i];
				 if( elem.name == fieldName && elem.value == value )
				 {
							elem.checked = "true";
							break;
				 }
			}
		}
}

function setSelectedOption( name, value ) {
		var selElement = document.getElementById( name );
		//
		if( selElement != null && selElement.options  ) {
				for( var i=0 ; i<selElement.options.length ; ++i ) {
						if( selElement.options[i].value == value ) {
								selElement.options[i].selected = true;
								break;
						}
				}
		}
}

function getSelectedRadio( formElement, fieldName )
{
		for( var i=0 ; i<formElement.elements.length ; ++i )
		{
			 var elem = formElement.elements[i];
			 if( elem.name == fieldName && elem.checked )
			 {
						return elem;
			 }
		}
}

function parseSegmentedIP( formElements, field, name1, name2, name3, name4 )
{
	 var elem1 = formElements[name1];
	 var elem2 = formElements[name2];
	 var elem3 = formElements[name3];
	 var elem4 = formElements[name4];
	 //
	 if( elem1 == null || elem2 == null || elem3 == null || elem4 == null )
	 {
			 alert("Missing IP segement elements, one of : " + name1 + "," + name2 + ", " + name3 + ", " + name4 );
			 return "";
	 }
	 else
	 {
			return field.m_dataName + ":" + elem1.value + "." + elem2.value + "." + elem3.value + "." + elem4.value;
	 }
}


//  Generic method to show errors on settings pages.
function showErrorMessage( msg )
{
		alert(" Error: " + msg );
}

// Convenience method for setting the innterHtml of a message
// element and displaying it.
function showBlockMessage( elementName, errorMsg ) {
		var elem = document.getElementById( elementName );
		if( elem != null ) {
				elem.innerHTML = errorMsg;
				elem.style.display = 'block';
		}
		else {
				alert('Cannot find element: ' + elementName );
		}
}

function showInlineMessage( elementName, errorMsg ) {
		var elem = document.getElementById( elementName );
		if( elem != null ) {
				elem.innerHTML = errorMsg;
				elem.style.display = 'inline';
		}
		else {
				alert('Cannot find element: ' + elementName );
		}
}

//  Convenience method for hiding elements (such as error messages).
function hideElement( elemName ) {
		var elem = document.getElementById( elemName );
		if( elem == null || elem['style'] == null ){}
				//alert('Missing element ' + elemName );
		else
				elem.style.display = 'none';
}

//  Convenience method for showing elements.
function showBlockElement( elemName ) {
		var elem = document.getElementById( elemName );
		if( elem == null || elem['style'] == null ){}
				//alert('Missing element ' + elemName );
		else
				elem.style.display = 'block';
}

//  Convenience method for showing elements.
function showInlineElement( elemName ) {
		var elem = document.getElementById( elemName );
		if( elem == null || elem['style'] == null ){}
				//alert('Missing element ' + elemName );
		else
				elem.style.display = 'inline';
}

//  Convenience method for showing Progress element even form already loaded.
function showProgressBlockElement( elemName ) {
		var elem = document.getElementById( elemName );
		if( elem == null || elem['style'] == null ){}
				//alert('Missing element ' + elemName );
		else
				//elem.innerHTML = "<br><br><table id='progressTable' style='text-align: left; width: 585px; height: 77px;' border='0' cellpadding='2' cellspacing='2'><tbody><tr align='center'><td style='vertical-align: top;'><h1>"+ top.formatProgressMsg + "</h1></td></tr><tr align='center'><td style='vertical-align: top;'><img alt='Please wait' src='images/progress.gif' style='width: 111px; height: 14px;'><br></td></tr></tbody></table>";
				elem.innerHTML = '<div id="progressPage"><div class="progressBackground"></div><div class="progressContainer"><div id="progressGraphic"></div></div></div>';
				elem.style.display = 'block';
}


function validateHostName( name ) {
		var hostPattern = /([a-zA-Z0-9][a-zA-Z0-9-]{0,64})/;
		var result = name.match( hostPattern );
		//
		if( result == null || result[1].length != name.length )
				return 1;
		else
				return 0;
}

function validateIP( address ) {
		var isValid = 0;
		//
		if( address == null | address == "0.0.0.0" || address == "255.255.255.255" ||
		address.indexOf( "127." ) == 0 )
				isValid = 1;
		else {
				var ipPattern = /(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/;
				var segArray = address.match(ipPattern);
				//
				if( segArray == null || segArray.length != 5 )
						isValid = 2;
				else {
						var length = 0;
						for( i=1; i<segArray.length ; i++ ) {
								thisSegment = segArray[i];
								length += thisSegment.length;
								if( thisSegment < 0 || thisSegment > 255 ) {
										isValid = 3;
										break;
								}
						}
						//=
						if( length + 3 != address.length )
								return 4;
				}
		}
		//
		return isValid;
}

function isValidatePort( elemId )
{
		var elem = document.getElementById( elemId );
		if( elem == null ) {
				alert('Element (' + elemId + ') not found.');
				return 1;
		}
		else
		{
				var portNum = elem.value;
				return portNum > 0 && portNum <= 65535 ? 0 : 1;
		}
}

////////////////////////////////////////////////////////////////////
//
function ipmiPrivToName( type )
{
		var name = "Unknown";
		if( type == 15 )
				name = top.noneRole;//None
		if( type == 2 )
				name = top.userRole;//User
		else if( type == 3 )
				name = top.operatorRole//"Operator";
		else if( type == 4 )
				name = top.adminRole//"Administrator"; //bug 28907  (shows "Admin". want "Administrator")
		return name;
}

function detectOS()
{
		var agt = navigator.userAgent.toLowerCase();

		bWindows = false;
		bLinux = false;
		if ((agt.indexOf("win95")!=-1) ||(agt.indexOf("windows 95")!=-1)) bWindows=true;
		if ((agt.indexOf("win98")!=-1) ||(agt.indexOf("windows 98")!=-1)) bWindows=true;
		if ((agt.indexOf("winnt")!=-1) ||(agt.indexOf("windows nt")!=-1)) bWindows=true;
		if ((agt.indexOf("linux")!=-1)) bLinux = true;

}

function showUpdateArea()
{
		hideElement( 'contentArea' );
		//hideElement('progressScreen');
		progressBar.hide();
		isProgressbar = false;
		showInlineElement('updateArea');
}

		function appendTableRow(logData)
		{
				var aTable = document.getElementById('tempTable');
				var newRowIndex = aTable.rows.length;

				//doesn't seem to be a way to set style="height: 1px;" for blank.gif rows...
				//  but it also doesn't seem to affect table layout.
				var tr = aTable.insertRow(newRowIndex);
				insertBlankCell(tr, 0);
				insertBlankCell(tr, 1);
				var cell = tr.insertCell(2);
				populateCell(cell, newRowIndex, logData.name, 'left');
				insertBlankCell(tr, 3);
				cell = tr.insertCell(4);
				populateCell(cell, newRowIndex, logData.reading, 'center');
				insertBlankCell(tr, 5);
				cell = tr.insertCell(6);
				populateCell(cell, newRowIndex, logData.minWarning, 'center');
				insertBlankCell(tr, 7);
				cell = tr.insertCell(8);
				populateCell(cell, newRowIndex, logData.maxWarning, 'center');
				insertBlankCell(tr, 9);
				cell = tr.insertCell(10);
				populateCell(cell, newRowIndex, logData.minFailure, 'center');
				insertBlankCell(tr, 11);
				cell = tr.insertCell(12);
				populateCell(cell, newRowIndex, logData.maxFailure, 'center');
		}

/**
 * Callback used with loadXMLDocument.  This function will
 * be called each time the xmlRequestObject's readyState changes.
 * When the readyState is 4, indicating that processing is
 * complete, the status is checked.  If the status is ok then
 * the method document.chainedCallback will be called.  document.chainedCallback
 * should be defined at the page level prior to calling loadXMLDocument.
 */
function waitWithCallback()
{
	//Only execute for state "loaded", all other states have
	//  no processing.
	if (xmlRequestObject.readyState == 4)
	{
		// only if "OK"
		if (xmlRequestObject.status == 200 )
		{
			var xmlDoc = xmlRequestObject.responseXML;
			var reqStatus = getXMLValue( xmlDoc, 'status' );
			if( reqStatus != 'ok' )
			{
				var message = getXMLValue( xmlDoc, 'message' );
				//alert(" Request failed: " + message );
				//If we fail perform the callback with a null doc
				//  to signal the chainedCallback that the server'
				//  did not recognize the request
				document.chainedCallback(null);
			}
			else
			{
				//It might be wise at somepoint to implement
				//  chainedCallback as a stack to avoid accidentally
				//  stepping on a callback by overwriting it with
				//  a value that hasn't been called back yet.  This
				//  would introduce substantial complexity though...
				document.chainedCallback(xmlDoc);
				if( requestCtxt.updateComplete != null)
				{
					requestCtxt.updateComplete( requestCtxt, xmlDoc );
				}
			}
		}
		else if( xmlRequestObject.status == 401 )
		{
			document.location = "/login.html";
		}
		else
		{
			//showErrorMessage(" Could not retrieve data from server ( status=" +
			//xmlRequestObject.status + ", " + xmlRequestObject.statusText + ")" );
			showContentPanel();
		}
	}
} //end of waitWithCallback

/**
 * Rows alternate styles, this method provides a mechanism
 * for changing the style based on the row index.
 */
function getStyleForRow(tableRowIndex) {
		return (tableRowIndex % 2 == 0) ? '' : 'fill';
}

function insertBlankCell(tr, cellIndex)
{
		var cell = tr.insertCell(cellIndex);
		cell.className=getStyleForRow(tr.rowIndex);
		cell.innerHTML='<img src="images/blank.gif">';
}

/********************************************************************
function populateCell(cell, tableRowIndex, innerHTML, align)
{
		cell.className=getStyleForRow(tableRowIndex);
		cell.vAlign='middle';
		//cell.align='align';
		cell.innerHTML = (innerHTML == '    ') ? '[N/A]' : innerHTML;
}
*********************************************************************/

function populateCell(cell, tableRowIndex, innerHTML, align, cellType)
{
		//cell.className=getStyleForRow(tableRowIndex);
		cell.vAlign='middle';
		if (align !=null)
		{
				cell.align=align;
		}
		if (cellType == null)
		{
				//Don't interpret no type as unknown, default to content.
				cellType = Cell.CONTENT;
		}
		switch (cellType)
		{
				case Cell.ICON:
						cell.innerHTML="<img src=" + innerHTML + ">";
						break;
				case Cell.CONTENT:
						cell.innerHTML = (innerHTML == '    ') ? '[N/A]' : innerHTML;
						break
				case Cell.BLANK :
						cell.innerHTML='<img src="images/blank.gif">';
						break;
				case Cell.HIDDEN :
						cell.innerHTML='<span style="display:none;">' + innerHTML + '</span>'
						break;
				default:
						showErrorMessage("Unknown type for cell, cell - " + celltype);
						break;
		}
}

/**
 * Submit a request for data to the server and call
 * refreshDataCallback when the response arrives.
 */
function refreshData(data)
{
		document.chainedCallback = refreshDataCallback;
		loadXMLDocument('data?get=' + data, waitWithCallback);
}

/**
 * Special case: Allo session timeout for auto refresh.
 * Sending a flag to Appweb server to not reset the idle session timeout.
 * param:  isAutoRefresh:  0-not autorefresh, 1-autorefresh
 */
function autoRefreshData(data, isAutoRefresh)
{
		var url = 'data?get=' + data;
		loadAutoRefreshData(url, waitWithCallback, isAutoRefresh);
}

function loadAutoRefreshData(url, callback, isAutoRefresh, postData)
{
		document.chainedCallback = refreshDataCallback;

		//
		if( window.XMLHttpRequest )
		{
				xmlRequestObject = new XMLHttpRequest();
		}
		else if( window.ActiveXObject )
		//     if( window.ActiveXObject )
		{
				try
				{
						xmlRequestObject = new ActiveXObject("Msxml2.XMLHTTP");
					 // alert("XMLHttpRequest is executed");
				}
				catch ( e )
				{
						try
						{
								xmlRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
						}
						catch ( E )
						{
						}
				}
		 }
		 //
		 if( xmlRequestObject )
		 {
				 xmlRequestObject.onreadystatechange = callback;
				 xmlRequestObject.open("POST", url, true );
				 if( postData == null )
						 postData = '';
				 xmlRequestObject.setRequestHeader("Content-Type", "application/x-www-form-urlencoded" );
				 xmlRequestObject.setRequestHeader("idracAutoRefresh", ""+isAutoRefresh );
				 if (top.TOKEN_VALUE.length >= 8){ xmlRequestObject.setRequestHeader(top.TOKEN_NAME, top.TOKEN_VALUE ); }
				 xmlRequestObject.send( postData );
		 }
}

/**********************************************************************************
function appendTableRow(table,row)
{
		var aTable = document.getElementById(table);
		var newRowIndex = aTable.rows.length;

		//doesn't seem to be a way to set style="height: 1px;" for blank.gif rows...
		//  but it also doesn't seem to affect table layout.
		var tr = aTable.insertRow(newRowIndex);
		for (i = 0; i < row.length; i++)
		{
				switch (row[i].m_type)
				{
						case Cell.ICON:
						cell = tr.insertCell(i);
						cell.innerHTML="<img src=" + innerHTML + ">";
						break;

						case Cell.CONTENT:appendTableRow
						cell = tr.insertCell(i);
						populateCell(cell, newRowIndex, row[i].m_value, row[i].m_align);
						break;

						case Cell.BLANK:
						insertBlankCell(tr, i);
						break;

						default:
						showErrorMessage("undefined value in row's cell " + i);
						break;
				}
		}
}
************************************************************************************/

function appendTableRow(table,row)
{
		var aTable = document.getElementById(table);
		if (null ==  aTable)
				return;

		var newRowIndex = aTable.rows.length;

		//doesn't seem to be a way to set style="height: 1px;" for blank.gif rows...
		//  but it also doesn't seem to affect table layout.
		var tr = aTable.insertRow(newRowIndex);
		tr.className=getStyleForRow(newRowIndex);
		for (i = 0; i < row.length; i++)
		{
				cell = tr.insertCell(i);

				if (i==0)
				{
						cell.className="left";
				}
				else if (i==row.length-1)
				{
						cell.className="right";
				}
				else  if (i!=row.length-2)
				{
						cell.className="contents borderbottom borderright";
				}
				else
				{
						cell.className="contents borderbottom";
				}

		populateCell(cell, newRowIndex, row[i].m_value, row[i].m_align, row[i].m_type);
		}
}

function clearTableRows(tableName, startRow, endRow)
{
		aTable = document.getElementById(tableName);
		if (aTable == null || aTable.rows.length==0)
		{
				//Nothing to do.
				return;
		}
		if (startRow == null)
		{
				startRow = 0;
		}
		if (endRow == null || endRow > aTable.rows.length)
		{
				endRow = aTable.rows.length;
		}
		//Delete at the starting point until
		//  the number of rows between start and end
		//  are gone.
		for (var x=startRow; x < endRow; x++)
		{
				aTable.deleteRow(startRow);
		}

}

function trim(str)
{
		if (str == null || str==undefined )
		{
				return str;
		}
		str = str.replace(/^\s*/gi, "");
		str = str.replace(/\s*$/gi, "");
		return str;
}

function isEmpty( str )
{
		if (str != null || str!=undefined ){
				return trim(str).length == 0;
		}
		else{
				return true;
		}
}

var IPV6_ALLOWED_COLONS =   7;
var IPV6_IPV4_ALLOWED_COLONS = 5;

/* This function will verify IPV6 address in the following format
 *  x:x:x:x:x:x:x:x or compressed format
 * x - represents valid ipv6
	*/

var ipV6Pattern  = new RegExp("^([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{1,4})$");
var ipV6Pattern2 = new RegExp("^([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{1,4})$");
function isIPV6(str)
{
		var tStr = trim(str);
		var validIPv6 = true;

		if (tStr.length > 60 || tStr.length < 2 ) { return false; }

		var bCompressedFormat = false;
		if (tStr.indexOf("::")>-1)
		{
				bCompressedFormat = true;
				if (tStr == "::")  return true;   //Valid unspecified ipv6 address
		}


		 if (validIPv6 && bCompressedFormat)
					 validIPv6 = isIPV6Format(str,IPV6_ALLOWED_COLONS);

		// IPv6 prefrerred format check x:x:x:x:x:x:x:x
		// Check this if ipv6 is not in compressed format
		if (validIPv6 && !bCompressedFormat && !ipV6Pattern.test(str))
		{
				//alert("invalid format");
				validIPv6 = false;
		}
		return validIPv6;
}

/*
 *mixed environment of IPv4 and IPv6 nodes is
			x:x:x:x:x:x:d.d.d.d, where the 'x's are the hexadecimal values of
			the six high-order 16-bit pieces of the address, and the 'd's are
			the decimal values of the four low-order 8-bit pieces of the
			address (standard IPv4 representation).  Examples:

				0:0:0:0:0:0:13.1.68.3

				0:0:0:0:0:FFFF:129.144.52.38

			or in compressed form:

				 ::13.1.68.3

				 ::FFFF:129.144.52.38
 *
 */

/* This function will verify IPV6 address in the following format
 *  x:x:x:x:x:x:y.y.y.y
 * x - represents valid ipv6
 * y - represents valid ipv4
	*/

var ipV6PatternWithIPV4  = new RegExp("^([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{0,4})\:([0-9,A-F,a-f]{1,4})$");
function isIPV6WithIPV4(str)
{
	var validIP = true;
	var tStr = str;
	//Mixed IPv6 and IPV4 str length should be less than 45 and greater than 8

	if (tStr.length > 45 || tStr.length<8)
		{
				validIP = false;
		}

	if (validIP && tStr.indexOf(".")==-1)
	 {
				validIP = false;
	 }

	 //Split ipv6 and ipv4
	 if (validIP)
		 {
				 var dotPos = tStr.indexOf(".");
				 var ipv4Str = tStr.substring(tStr.lastIndexOf(":",dotPos)+1);

				 if (isIPV4(ipv4Str))
					 {
								 var tempStr = tStr.substring(0,tStr.lastIndexOf(":",dotPos)+1);
								 var ipv6Str = "";
								 if (tempStr.lastIndexOf("::")==tempStr.length-2)
										 {
												 ipv6Str = tempStr;
										 }
									else
											{
													 ipv6Str = tempStr.substring(0,tempStr.lastIndexOf(":"));
											}
									//ipv6 validation.
								 if (ipv6Str.length > 29 || ipv6Str.length < 2)
									 {
											 validIP = false;
									 }

									var bCompressedFormat = false;
									if (tStr.indexOf("::")>-1)
									{
											bCompressedFormat = true; //Valid unspecified ipv6 address
											if (tStr == "::")
													validIP = true;
									}

								 if (validIP && bCompressedFormat)
											validIP = isIPV6Format(ipv6Str,IPV6_IPV4_ALLOWED_COLONS);

								// IPv6 prefrerred format check x:x:x:x:x:x:x:x
								// Check this if ipv6 is not in compressed format
								if (validIP && !bCompressedFormat && !ipV6PatternWithIPV4.test(ipv6Str))
								{
										//alert("invalid format");
										validIP = false;
								}
						}
		 else
				 {
							validIP = false;
				 }
		 }
		 return validIP;
}
/* This function will verify IPV6 address in the following format
 *  x:x:x:x:x:x/z
 * x - represents valid ipv6
	* z - represents prefix
 */

function isIPV6WithPrefix(str)
{
		tStr = str;
		validIP = true;

		if (tStr.indexOf("/")==-1)
		{
				validIP = false;
		}

		if (validIP)
				{
						var prefixStr = tStr.substring(tStr.indexOf("/")+1);
						if (isNumeric(prefixStr))
								{
										var ipv6Str = tStr.substring(0,tStr.indexOf("/")) ;
										 if (!isIPV6(ipv6Str))
												 validIP = false;
								}
								else
										{
												validIP = false;
										}
				}

				return validIP;
}

/* This function will verify IPV6 address in the following format
 *  x:x:x:x:x:x:y.y.y.y/z
 * x - represents valid ipv6
 * y - represents valid ipv4
 * z - represents prefix
 */

function isIPV6WithIPV4AndPrefix(str)
{
		tStr = str;
		validIP = true;
		if (tStr.indexOf("/")==-1 || tStr.indexOf(".")==-1)
		{
				validIP = false;
		}

		 if (validIP && tStr.length > 47 || tStr.length<11)
		{
				validIP = false;
		}

		if (validIP)
		{
				var ipv6AndIPV4Str = tStr.substring(0,tStr.indexOf("/"));
				validIP = isIPV6WithIPV4(ipv6AndIPV4Str);
		}

		 if (validIP)
				{
						var prefixStr = tStr.substring(tStr.indexOf("/")+1)
						validIP = isNumeric(prefixStr);
				}
			return validIP;

}



//This function should not be call from outside of function.js
 function isIPV6Format(str,allowedColons)
 {

		var tStr = str;

		var ipv6Format = true;

		var bCompressedFormat = false;

								//Double colons may be used only once in an IP address
								var dColonStr = tStr.split("::");
								if (dColonStr.length > 2 )
										{
												ipv6Format = false;
										}

								 var colonCount = countSingleColonOccurance(str);

								 if(colonCount > allowedColons-2)
								 {
												 ipv6Format = false;
									}

										if (ipv6Format)
										{
												for(var i=0;i<dColonStr.length;i++)
												{
														if (dColonStr[i].indexOf(":") > -1)
														{
																	var sColonStr = dColonStr[i].split(":");
																	for(var j=0;j<sColonStr.length;j++)
																			{
																					var l = sColonStr[j].length;  //df489729
																					if(!isvalidhex(sColonStr[j]) || (l > 4) )
																							{
																									//alert("Not a valid Hex in compressed format with :");
																									ipv6Format=false;
																									break;
																							}

																			}
														 }
														else if(dColonStr[i] != "")
														{
																var l = dColonStr[i].length;    //df489729
																if(!isvalidhex(dColonStr[i]) || (l > 4) )
																{
																		//alert("Not a valid Hex in compressed format");
																		ipv6Format= false;
																		break;
																}
														}
												}
										}
		 return ipv6Format;
 }
function countSingleColonOccurance(strVal)
{
		var count =0;
		if (strVal.indexOf(":")>-1)
			{
					if (strVal.indexOf("::")>-1)
						{
								var dColonStr = strVal.split("::");
								for(var i=0;i<dColonStr.length;i++)
									{
										var pos = dColonStr[i].indexOf(":");
										while ( pos != -1 )
										{
												count++;
												pos = dColonStr[i].indexOf(":",pos+1);
										}
									}
						}
						else
								{
								var pos = strVal.indexOf(":");
								while ( pos != -1 )
								{
										count++;
										pos = strVal.indexOf(":",pos+1);
								 }

								}
			}
		return count;
}

//This function is used to test Ipv6 address is loopback(::1) or not
//This function  should be called after validating ipv6
function isLoopBackAddr(ipv6Addr)
{
				var loopBackAddr = "::1";
				var validchars = /^[0-0]*$/;

				if (ipv6Addr == loopBackAddr)
					 return true;


				if (ipv6Addr.indexOf(".")>-1)
				{
								ipv6Addr = ipv6Addr.substring(0,ipv6Addr.indexOf(".")); //Removing ipv4 if exist
								ipv6Addr = ipv6Addr.substring(0,ipv6Addr.lastIndexOf(":"))//Removing ipv4 if exist
								if (ipv6Addr == loopBackAddr)
									 return true;
				}

				var str = ipv6Addr.substring(0,ipv6Addr.lastIndexOf(":"));
				str = str.replace(/:/g, "" );

				if (!validchars.test(str))
								return false;

				var tempStr = ipv6Addr.substring(ipv6Addr.lastIndexOf(":")+1)//Taking last position of ipv6
				if (parseInt(tempStr) == 1)
								return true;
				else
								return false;
}
//This function is used to test Ipv6 address is multicast address Starting with(FFxx::) or not
//This function  should be called after validating ipv6
function isMulticastAddr(ipv6Addr)
{
			 var multicastAddr = ipv6Addr.substring(0,ipv6Addr.indexOf(":"));
			 multicastAddr = multicastAddr.toUpperCase();
			 if (multicastAddr.indexOf("FF")==0)
					return true;
			 else
					return false;

}

function isIpv6AsDoubleColon(ip6Addr)
{
	 var notValidchars = /^[0-0]*$/;
	 var str = ip6Addr.replace(/:/g, "" );

	 if (notValidchars.test(str))
			 return true;
	 else
			 return false;

}



var ipV4Pattern = new RegExp("^([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3}).([0-9]{1,3})$");
function isIPV4(str)
{
		var match = str.match(ipV4Pattern);
		return match != null
				&& match[1] < 256
				&& match[2] < 256
				&& match[3] < 256
				&& match[4] < 256;
}

function isHexWithColonPeriod(text)
 {
		var validchars = /^[a-fA-F0-9\:\.]*$/;
		if (text == null) return false;
		if( validchars.test(text))
		{
				return true;
		}
		return false;
}

/**
 * Returns the value of the node if it exists.
 * If strict is passed and the node does not exist throws "NoSuchNode" exception,
 * otherwise returns null
 */
function getXmlNodeValue(xmlSnippet, nodeName, strict)
{
		if (xmlSnippet == null)
		{
				return null;
		}
		element = xmlSnippet.getElementsByTagName(nodeName)[0];
		if (element == null )
		{
				//if (strict==null || strict==undefined || !strict)
				//{
				//  return "";
				//}
				//else
				//{
				//  var error = new Error();
				//  throw "getXmlNodeValue error:  no node for " + nodeName;
				//}
				return null;
		}
		return element.childNodes[0].nodeValue;
}

//var Status;
//Status.OK = 0;
//Status.ALERT = 1;
//Status.FAILED = 2;

//see http://www.netlobo.com/url_query_string_javascript.html, which was the
//  basis for this script.  If server side scripting is available form values
//  are available as @@forms['param']
function getParameterFromURL(parameterName, aURL)
{
		//I'm not sure why we're replacing [ and ] with escaped versions (\[ and \]), but
		//  left this for now.  The [] probably do something bad to the regexp
		//  evaluation, although it shouldn't...
		parameterName = parameterName.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
		//regex to search for parameter name preceded by & or ? followed by
		//any character except end of line, & or #, capturing everything after the = a
		//and before the eol, & or #.
		var regexS = "[\\?&]"+parameterName+"=([^&#]*)";
		//build and execute the regex against the search term
		var regex = new RegExp( regexS );
		var results = regex.exec( aURL );
		//return null if no match, or first match.
		if( results == null )
		{
				return null;
		}
		else
		{
				return results[1];
		}
}

//Given a select control and a comma delimitted string convert the string into
//options for the select control.
function delimValueToOptions(selectControl, value, delim)
{
		//Clear any existing options
		while (selectControl.options.length > 0)
		{
				selectControl.remove(0);
		}
		if (value == null)
		{
				return;
		}
		var valueArray = value.split(delim);
		for (var optionIndex=0; optionIndex<valueArray.length; optionIndex++)
		{
				var oneOption = new Option();
				oneOption.text = valueArray[optionIndex];
				try {
						selectControl.add(oneOption, null);
				} catch (ex) {
						//IE only
						selectControl.add(oneOption);
				}
		}
}

//Given an select control, convert it's options convert to a comma delimitted string
function optionsToDelimValue(selectControl, delim)
{
		var options = selectControl.options;
		var delimString = "";
		if (options == null)
		{
				return "";
		}
		for (var optionIndex=0; optionIndex<options.length; optionIndex++)
		{
				delimString = delimString + options[optionIndex].text + delim;
		}
		//Drop the last delimitter
		delimString = delimString.substring(0, (delimString.length - 1));
		return delimString;

}


function WattsToBTU(wValue)
{
		var btuValue = 0.0;
		if (wValue != undefined && wValue != null) { btuValue = wValue * 3.413; }
		return btuValue;
}

function btuToWatts(btuValue)
{
		var wValue = 0.0;
		if (btuValue != undefined && btuValue != null ) { wValue = btuValue / 3.413; }
		return wValue;
}


function WattsToWBtext(wValue)
{
		var btuValue = 0.0;
		if (wValue != undefined && wValue != null) { btuValue = wValue * 3.413; }
		wValue = Math.round(wValue);
		btuValue = Math.round(btuValue);
		return wValue + " W | " + btuValue + " " + btuUnits; //DF524394 fix
}

//Function is used to split IP Address from host address(IP:Port)  and to findout Ipv6 or Ipv4
	function getIPAddressAndFormat(hostAddr)
	{
			var ipAddr = hostAddr;
			var ipv6Format = 0;

			var n=hostAddr.split(":");

			 if (n.length > 2) //consider as ipv6
			 {
					 ipv6Format =1;
					 if (hostAddr.indexOf("]")>0)
							ipAddr = hostAddr.substring(1,hostAddr.indexOf("]"))
					 else
							 ipAddr = hostAddr;
			 }
			 else
				 {
						if (hostAddr.indexOf(":")>0) //checking it is IPv4 ,checking contains host addr
						 {
										ipAddr = hostAddr.substring(0,hostAddr.indexOf(":"))
						 }
				 }

			ipAddr = ipAddr+"@"+ipv6Format;
			return ipAddr;
	}

function clearFileInput( id ){
		var elem = document.getElementById( id );
		elem.parentNode.innerHTML = elem.parentNode.innerHTML;
}

// constants to define the title of the alert and button text.
var ALERT_BUTTON_TEXT = "OK";

/*if(document.getElementById) {
		window.alert = function(txt,titleTxt,alertID) {
				createCustomAlert(txt,titleTxt,alertID);
		}
}*/


var OrigAlert = window.alert;
if(document.getElementById) {
		window.alert = function(txt,titleTxt,alertType,isReload) {
				createCustomAlert(txt,titleTxt,alertType,isReload);
		}
}

function createCustomAlert(txt,titleTxt,alertType,isReload) {
		// shortcut reference to the document object
		d = document;

		// if the modalContainer object already exists in the DOM, bail out.
		if(d.getElementById("modalContainer")) return;

		// create the modalContainer div as a child of the BODY element
		mObj = d.getElementsByTagName("body")[0].appendChild(d.createElement("div"));
		mObj.id = "modalDiv";

		if (alertType==null)
				alertType = Message_Caution;

		if (titleTxt==null)
				titleTxt = ALERT_TITLE;

		var alertTypeIcon;
		var alertTextClass;
		var txt2 = txt.replace(/\n/g,"<br>");
		//added to fix : CR490510  After initializing SD card, Gui displays incorrect message prompt.
		//var alertBtnText = Alert_Dismiss ;   //DF498693
		var alertBtnText = Alert_ok;

		switch(alertType)
		{
				case Message_OK:
						alertTypeIcon="ok";
						alertTextClass="ok_message";
						alertTypeClass="ok_modal";
						alertBtnText = Alert_ok ;
						break;
				case Message_Caution:
						alertTypeIcon="non-critical";
						alertTextClass="non-crital_message";
						alertTypeClass="warning_modal";
						break;
				case Message_Alert:
						alertTypeIcon="critical";
						alertTextClass="crital_message";
						alertTypeClass="error_modal";
						break;
				case Message_Info:
						alertTypeIcon="info";
						alertTextClass="info_message";
						alertTypeClass="dialog_modal";
						break;
		}

	var spanTxt;

	spanTxt = " <div class='modalBackground'>"
	spanTxt+= " </div>"
	spanTxt+= " <div class='modalContainer'>"
	spanTxt+= "   <div id='error_modal' class='"+ alertTypeClass +"'>"
	spanTxt+= "     <div class='top_right'>"
	spanTxt+= "       <div class='top_left'>"
	spanTxt+= "         <div class='top'>"
	spanTxt+= "           <div id='modal_title' class='title'>"
	spanTxt+= titleTxt;
	spanTxt+= "           </div>"
	spanTxt+= "         </div>"
	spanTxt+= "       </div>"
	spanTxt+= "     </div>"
	spanTxt+= "     <div class='right'>"
	spanTxt+= "       <div class='left'>"
	spanTxt+= "         <div class='alert_container_content'>"
	spanTxt+= "           <table>"
	spanTxt+= "             <tr>"
	spanTxt+= "               <td id='modal_icon' class='" + alertTypeIcon + "'>"
	spanTxt+= "               </td>"
	spanTxt+= "               <td class='alert_info'>"
	spanTxt+= "                 <div id='modal_txt' class='" + alertTextClass + "'>"
	spanTxt+= txt2;
	spanTxt+= "                 </div>"
	spanTxt+= "               </td>"
	spanTxt+= "             </tr>"
	spanTxt+= "           </table>"
	spanTxt+= "         </div>"
	spanTxt+= "       </div>"
	spanTxt+= "     </div>"
	spanTxt+= "     <div class='bottom_right'>"
	spanTxt+= "       <div class='bottom_left'>"
	spanTxt+= "         <div class='bottom'>"
	spanTxt+= "           <div class='button_footer'>"
	spanTxt+= "             <div class='button_clear'>"
	spanTxt+= "               <a id='modal_close' class='container_button' href='javascript:removeCustomAlert("+isReload+");'><span>"+alertBtnText+"</span></a>"
	spanTxt+= "             </div>"
	spanTxt+= "           </div>"
	spanTxt+= "         </div>"
	spanTxt+= "       </div>"
	spanTxt+= "     </div>"
	spanTxt+= "   </div>"
	spanTxt+= "  </div>"

		mObj.innerHTML = spanTxt;

		modalError.show();
}

// removes the custom alert from the DOM
function removeCustomAlert(isReload) {
		document.getElementsByTagName("body")[0].removeChild(document.getElementById("modalDiv"));

		if(isReload==true)
		{
				hideElement('contentArea');
				document.location.reload(true);
		}
}

function HTMLEncode( text )
{
		if ( typeof( text ) != "string" ) text = text.toString();
		text = text.replace(/&/g, "&amp;");
		text = text.replace( /</g, "&lt;");
		text = text.replace(/>/g, "&gt;");
		return text ;
}

// check Unique Port
var gl_portIdx = new Object();
gl_portIdx.webHTTPPort      = 0;
gl_portIdx.webHTTPSPort     = 1;
gl_portIdx.sshPort          = 2;
gl_portIdx.telnetPort       = 3;
gl_portIdx.kvmPort          = 4;
gl_portIdx.remoteSyslogPort = 5;
gl_portIdx.GLServerPort     = 6;
gl_portIdx.snmpDiscoveryPort = 7;
var gl_port_array = new Array();

function InitUniquePort(val)
{
	if(!isKeyExistInFieldList("kvmPort"))
		 fieldList[val++] = new FieldMapping( "kvmPort"         , null, FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("webHTTPPort"))
		 fieldList[val++] = new FieldMapping( "webHTTPPort"     , null, FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("webHTTPSPort"))
		 fieldList[val++] = new FieldMapping( "webHTTPSPort"    , null, FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("sshPort"))
		 fieldList[val++] = new FieldMapping( "sshPort"         , null, FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("telnetPort"))
		 fieldList[val++] = new FieldMapping( "telnetPort"      , null, FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("remoteSyslogPort"))
		 fieldList[val++] = new FieldMapping( "remoteSyslogPort", "remoteSyslogPort", FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("GLServerPort"))
		 fieldList[val++] = new FieldMapping( "GLServerPort"    , "xGLServerPort", FieldMapping.TYPE_TEXT );

	if(!isKeyExistInFieldList("snmpDiscoveryPort"))
		 fieldList[val++] = new FieldMapping( "snmpDiscoveryPort"    , "snmpDiscoveryPort", FieldMapping.TYPE_TEXT );
}

function isKeyExistInFieldList(key) {
	 for(i=0; i<fieldList.length; i++) {
			if(fieldList[i].m_fieldName == key)
				 return true;
	 }
	 return false;
}

function LoadUniquePort(xmlDoc)
{
	gl_port_array[gl_portIdx.webHTTPPort]       = getXMLValue(xmlDoc,"webHTTPPort");
	gl_port_array[gl_portIdx.webHTTPSPort]      = getXMLValue(xmlDoc,"webHTTPSPort");
	gl_port_array[gl_portIdx.sshPort]           = getXMLValue(xmlDoc,"sshPort");
	gl_port_array[gl_portIdx.telnetPort]        = getXMLValue(xmlDoc,"telnetPort");
	gl_port_array[gl_portIdx.kvmPort]           = getXMLValue(xmlDoc,"kvmPort");
	gl_port_array[gl_portIdx.remoteSyslogPort]  = getXMLValue(xmlDoc,"remoteSyslogPort");
	//gl_port_array[gl_portIdx.GLServerPort]      = getXMLValue(xmlDoc,"xGLServerPort");
	gl_port_array[gl_portIdx.snmpDiscoveryPort]  = getXMLValue(xmlDoc,"snmpDiscoveryPort");
}

function ChkUniquePort()
{
	var match = false;
	var j = 0;

	if (gl_port_array.length > 1) {
			while (j < gl_port_array.length){
					for ( var i = j + 1; i < gl_port_array.length; i++){
							if(gl_port_array[j] == "") continue;
							if (gl_port_array[j] == gl_port_array[i]) { match = true; }
					}
					j++;
			}
	}
	return match;
}
function escapeStr(str) {
		var tmp = new Array();
		var i;
		var escstr="";
		var dec;

		str = str.replace(/\\/g, "\\\\");
		tmp = str.split("");
		for(i=0; i<str.length; i++) {
				switch(tmp[i]) {
						case '@':
						case '(':
						case ')':
						case ',':
						case ':':
						case '?':
						case '=':
						case '&':
								dec = (tmp[i]+'').charCodeAt(0);
								escstr+= "@0"+ dec.toString(16);
								break;
						default:
								escstr+=tmp[i];
				}
		}

		return(escstr);
}

function is64BitBrowser()
{
		var myUserAgent = navigator.userAgent;

		var myCPUType = navigator.cpuClass;


		var myOperatingSystem = navigator.platform;

		var is64BitIEon64BitWindows = /Win64/gi; // 64-bit IE on 64-bit Windows

		var is32BitIEon64BitWindows =  /WOW64/gi; // 32-bit IE on 64-bit Windows



		if (myUserAgent.match(is64BitIEon64BitWindows))
		{
				return true;
		}
		/*
		if (myUserAgent.match(is32BitIEon64BitWindows))
		{

				alert("32 Bit IE on 64 Bit Windows");
		}
		*/

		return false;

}

function sensor_convert(str)
{
		switch (str) {
		case 'normal':
				return "ok";
		case 'warning':
				return "noncritical";
		}

		return str;
}

function EntityDecode(str) {
		if (typeof str != 'string')
				return str;

		str = str.replace(/&lt;/g, '<').replace(/&gt;/g, '>');

		var matches = str.match(/&#\d+;?/g);

		if ((matches != null)&&(matches.length != null))
		{
				for(var i = 0; i < matches.length; i++)
				{
						// line wraps here -- be careful copy/pasting
						var replacement = String.fromCharCode((matches[i]).replace(/\D/g,""));

						str = str.replace(/&#\d+;?/,replacement);
				}
		}
		return str;
}

function tconfirm(str, titleTxt, alertType, isReload, methodName)
{
		if( null == titleTxt ||
				null == alertType ||
				null == isReload ||
				null == methodName)
		{
				return confirm( EntityDecode(str) );
		}
		else
		{
				return createCustomComfirm(EntityDecode(str), titleTxt, alertType, isReload, methodName);
		}
}

function createCustomComfirm(txt,titleTxt,alertType, isReload, methodName)
{
		// shortcut reference to the document object
		d = document;

		// if the modalContainer object already exists in the DOM, bail out.
		if(d.getElementById("modalContainer")) return;

		// create the modalContainer div as a child of the BODY element
		mObj = d.getElementsByTagName("body")[0].appendChild(d.createElement("div"));
		mObj.id = "modalDiv";

		if (alertType==null)
				alertType = Message_Caution;

		if (titleTxt==null)
				titleTxt = ALERT_TITLE;

		var alertTypeIcon;
		var alertTextClass;
		var txt2 = txt.replace(/\n/g,"<br>");
		//added to fix : CR490510  After initializing SD card, Gui displays incorrect message prompt.
		//var alertBtnText = Alert_Dismiss ;   //DF498693
		var alertBtnYes = Alert_yes;
		var alertBtnNo = Alert_no;

		switch(alertType)
		{
				case Message_OK:
						alertTypeIcon="ok";
						alertTextClass="ok_message";
						alertTypeClass="ok_modal";
						alertBtnText = Alert_ok ;
						break;
				case Message_Caution:
						alertTypeIcon="non-critical";
						alertTextClass="non-crital_message";
						alertTypeClass="warning_modal";
						break;
				case Message_Alert:
						alertTypeIcon="critical";
						alertTextClass="crital_message";
						alertTypeClass="error_modal";
						break;
				case Message_Info:
						alertTypeIcon="info";
						alertTextClass="info_message";
						alertTypeClass="dialog_modal";
						break;
		}

	var spanTxt;

	spanTxt = " <div class='modalBackground'>"
	spanTxt+= " </div>"
	spanTxt+= " <div class='modalContainer'>"
	spanTxt+= "   <div id='error_modal' class='"+ alertTypeClass +"'>"
	spanTxt+= "     <div class='top_right'>"
	spanTxt+= "       <div class='top_left'>"
	spanTxt+= "         <div class='top'>"
	spanTxt+= "           <div id='modal_title' class='title'>"
	spanTxt+= titleTxt;
	spanTxt+= "           </div>"
	spanTxt+= "         </div>"
	spanTxt+= "       </div>"
	spanTxt+= "     </div>"
	spanTxt+= "     <div class='right'>"
	spanTxt+= "       <div class='left'>"
	spanTxt+= "         <div class='alert_container_content'>"
	spanTxt+= "           <table>"
	spanTxt+= "             <tr>"
	spanTxt+= "               <td id='modal_icon' class='" + alertTypeIcon + "'>"
	spanTxt+= "               </td>"
	spanTxt+= "               <td class='alert_info'>"
	spanTxt+= "                 <div id='modal_txt' class='" + alertTextClass + "'>"
	spanTxt+= txt2;
	spanTxt+= "                 </div>"
	spanTxt+= "               </td>"
	spanTxt+= "             </tr>"
	spanTxt+= "           </table>"
	spanTxt+= "         </div>"
	spanTxt+= "       </div>"
	spanTxt+= "     </div>"
	spanTxt+= "     <div class='bottom_right'>"
	spanTxt+= "       <div class='bottom_left'>"
	spanTxt+= "         <div class='bottom'>"
	spanTxt+= "           <div class='button_footer'>"
	spanTxt+= "             <div class='button_clear'>"
	spanTxt+= "               <a id='modal_close' class='container_button' href='javascript:removeCustomAlert("+isReload+");'><span>"+ alertBtnNo +"</span></a>"
	spanTxt+= "               <a id='warningYesButton' class='container_button' href='javascript: " + methodName + ";removeCustomAlert("+isReload+");'><span>" + alertBtnYes + "</span></a>"
	spanTxt+= "             </div>"
	spanTxt+= "           </div>"
	spanTxt+= "         </div>"
	spanTxt+= "       </div>"
	spanTxt+= "     </div>"
	spanTxt+= "   </div>"
	spanTxt+= "  </div>"

		mObj.innerHTML = spanTxt;

		modalError.show();
}

function getLoginUsername()
{
		var Username = jsesp_UserName;
		if(Username.indexOf("%A7") != -1)
				Username =  unescape(HTMLEncode(Username));
		else
				Username = decodeURIComponent( HTMLEncode(Username) );

		return Username;
}

//*************************************************************************
////////////////////////////START of redirection to power configuration //////////////
function redirection_PowerSupply()
{
	var PowerSupply = top.treelist.tbl_powersupplies;
	PowerSupply= PowerSupply.substring(4);
	top.parent.snb.f_getHTML(PowerSupply,top.treelist.snbindex_powersupplies,'');
}

function redirection_PowerConfig()
{
	var PowerTree = top.treelist.tbl_Powerthermal;
	PowerTree = PowerTree.substring(4);
	top.parent.snb.f_getHTML(PowerTree,top.treelist.snbindex_pwrConfig,top.treelist.lsnbindex_pwrConfig);
}
////////////////////////////////END/////////////////////////////

		function replaceTableBodyHTML(tblBodyId,el, html) {
						if( el ) {
								var oldEl = (typeof el === "string" ? document.getElementById(el) : el);
								var newNN = oldEl.nodeName;
								var newEl = document.createElement('SPAN');

								var tStr = '<table><tbody id='+tblBodyId+'>' + html + '</tbody></table>'
								newEl.innerHTML = tStr;

								// Preserve any properties we care about

								newTbody = newEl.childNodes[0].childNodes[0];
								newTbody.id = oldEl.id;
								newTbody.className = oldEl.className;

								//set the new HTML and insert back into the DOM

								if(oldEl.parentNode) { oldEl.parentNode.replaceChild(newTbody, oldEl); }
								else {oldEl.innerHTML = html; }
								//return a reference to the new element in case we need it

						return newEl;
				}
		};

function trace(str)
{
		if (this.console && typeof console.log != "undefined")
		{
				var dateObj = new Date();
				var m = dateObj.getMinutes() + 1;
				var s = dateObj.getSeconds();
				var ms = dateObj.getMilliseconds();
				console.log(m + ":" + s + "." + ms + "--->" + str);
		}
}

//  Convenience method for showing elements.
function showElement( elemName ) {
		var elem = document.getElementById( elemName );
		if( elem == null || elem['style'] == null ){}
				//alert('Missing element ' + elemName );
		else
				elem.style.display = '';
}

function trimLineBreak(str)
{
		str = str.replace(/\r\n/g, "<br />");  // Fixed bug DF460920: Added new line replacement for IE
		str = str.replace(/\n/g, "<br />");
		return str;
}

function restoreLineBreak(str)
{
		if(isEmpty(str))
		{
				return str;
		}
		str = str.replace(/<br \/>/g, "\n");
		return str;
}

function checkTextAreaCount(e, txtArea, maxVal)
{
		var evtobj = window.event ? event : e //distinguish between IE's explicit event object (window.event) and Firefox's implicit.
		var unicode = evtobj.charCode ? evtobj.charCode : evtobj.keyCode

		if (unicode >= 33 || unicode == 13) {
				if ($(txtArea).value.length >= maxVal) {
						return false;
				}
		}

		return true;
}

// prevent XSS attack.
function replaceHTMLTag(str)
{
		str = str.replace(/\(/g, '&#40;');
		str = str.replace(/\)/g, '&#41;');
		str = str.replace(/</g, '&#60;');
		str = str.replace(/>/g, '&#62;');

		return str;
}

function escapeStrWithouBackslash(str) {
		var tmp = new Array();
		var i;
		var escstr="";
		var dec;

		tmp = str.split("");
		for(i=0; i<str.length; i++) {
				switch(tmp[i]) {
						case '@':
						case '(':
						case ')':
						case ',':
						case ':':
						case '?':
						case '=':
						case '&':
								dec = (tmp[i]+'').charCodeAt(0);
								escstr+= "@0"+ dec.toString(16);
								break;
						default:
								escstr+=tmp[i];
				}
		}
		return(escstr);
}

function checkTextBoxCount(e, txtBox, maxVal)
{
		var evtobj = window.event ? event : e //distinguish between IE's explicit event object (window.event) and Firefox's implicit.
		var unicode = evtobj.charCode ? evtobj.charCode : evtobj.keyCode
		var actualkey=String.fromCharCode(unicode)
		var unicode2=e.keyCode? e.keyCode : e.charCode

		//trace(evtobj.charCode + '-' + evtobj.keyCode  + '-' + unicode + '-' + actualkey);
		//alert(evtobj.charCode);

		// Special keycode mapping
		// 35 -> End
		// 36 -> Home
		// 37 -> LeftArrow
		// 39 -> RightArrow
		// 46 -> Delete
		//
		var specialKeycodeList = [35, 36, 37, 39, 46];

		// Special Ctrl keycode mapping
		// 97 -> a
		// 99 -> c
		// 118 -> v
		// 120 -> x
		// 122 -> z
		var ctrlSpecialKeycodeList = [97, 99, 118, 120, 122]
		var bFoundSpecial = false;
		if(evtobj.ctrlKey)
		{
				for(var i = 0; i < ctrlSpecialKeycodeList.length; i++)
				{
						if(unicode == ctrlSpecialKeycodeList[i])
						{
								bFoundSpecial = true;
								break;
						}
				}
		}
		else if(!evtobj.shiftKey)
		{
				for(var i = 0; i < specialKeycodeList.length; i++)
				{
						if(unicode == specialKeycodeList[i])
						{
								bFoundSpecial = true;
								break;
						}
				}
		}
		else
		{
				for(var i = 0; i < specialKeycodeList.length; i++)
				{
						if( unicode == specialKeycodeList[i] &&
								evtobj.charCode == 0)
						{
								bFoundSpecial = true;
								break;
						}
				}
		}

		if(bFoundSpecial)
		{
				return true;
		}

		if (unicode >= 33 || unicode == 13)
		{
				if ($(txtBox).value.length >= maxVal)
				{
						return false;
				}
		}
		return true;
}

// checks the top location... if the url is not index it redirects to login.
function CheckTop()
{
		if ( top.document.location.href.search('index') < 0 )
		{
				top.document.location.href = "/start.html";

				return false;
		}

		return true;
}

/*
 * Register the specific handler function to handle events of the specific type on the specific target.
*/
function addCustomEvent(target, type, handler)
{
		if(target.addEventListener)
		{
				target.addEventListener(type, handler, false);
		}
		else
		{
				target.attachEvent  (   "on" + type,
																function(event){return handler.call(target, event);
														});
		}
}

function DecodeLCLMsg(str)
{
		if(null != str && !isEmpty(str))
		{
				// HTML doesn't support XML's &apos;
				// need to use &#39; instead
				str = str.replace(new RegExp('&apos;', 'g'), "&#39;");
				//BITS152976 Fix - Commented code as word wrap is not happening correctly by replacing space with &nbsp;
				//str = str.replace(new RegExp(' ', 'g'), "&nbsp;");
		}

		return str;
}

function DecodeLCLComment(str)
{
		if(null != str && !isEmpty(str))
		{
				str = str.replace(new RegExp('<br />', 'g'), "\n");
				// HTML doesn't support XML's &apos;
				// need to use &#39; instead
				str = str.replace(new RegExp('&apos;', 'g'), "&#39;");
		}

		return str;
}

//moved the following cookie functions from sysSummary.js to functions.js

function Set_Cookie( name, value, expires, path, domain, secure )
{
// set time, it's in milliseconds
var today = new Date();
today.setTime( today.getTime() );
/*
if the expires variable is set, make the correct
expires time, the current script below will set
it for x number of days, to make it for hours,
delete * 24, for minutes, delete * 60 * 24
*/
if ( expires )
{
expires = expires * 1000 * 60 * 60 * 24;
}
var expires_date = new Date( today.getTime() + (expires) );
document.cookie = name + "=" +escape( value ) +
( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
( ( path ) ? ";path=" + path : "" ) +
( ( domain ) ? ";domain=" + domain : "" ) +
( ( secure ) ? ";secure" : "" );
}
// this fixes an issue with the old method, ambiguous values
// with this test document.cookie.indexOf( name + "=" );
function Get_Cookie( check_name ) {
	// first we'll split this cookie up into name/value pairs
	// note: document.cookie only returns name=value, not the other components
	var a_all_cookies = document.cookie.split( ';' );
	var a_temp_cookie = '';
	var cookie_name = '';
	var cookie_value = '';
	var b_cookie_found = false; // set boolean t/f default f
	for ( i = 0; i < a_all_cookies.length; i++ )
	{
		// now we'll split apart each name=value pair
		a_temp_cookie = a_all_cookies[i].split( '=' );
		// and trim left/right whitespace while we're at it
		cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');
		// if the extracted name matches passed check_name
		if ( cookie_name == check_name )
		{
			b_cookie_found = true;
			// we need to handle case where cookie has no value but exists (no = sign, that is):
			if ( a_temp_cookie.length > 1 )
			{
				cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
			}
			// note that in cases where cookie is initialized but no value, null is returned
			return cookie_value;
			break;
		}
		a_temp_cookie = null;
		cookie_name = '';
	}
	if ( !b_cookie_found )
	{
		return null;
	}
}
// this deletes the cookie when called
function Delete_Cookie( name, path, domain ) {
if ( Get_Cookie( name ) ) document.cookie = name + "=" +
( ( path ) ? ";path=" + path : "") +
( ( domain ) ? ";domain=" + domain : "" ) +
";expires=Thu, 01-Jan-1970 00:00:01 GMT";
}

function displayFormattedADCACert( fieldId, value ) {
	 try {
			var tbl="<table><tbody>";
			var sp = value.split("\n");
			for(var i = 0; i < sp.length; i++) {
				 if(sp[i] != null && sp[i].length != 0) {
						var subsp = sp[i].split(":");
						if(subsp != null && subsp.length != 0) {
							 tbl += "<tr><td>" + subsp[0] + "</td>";
							 tbl += "<td>";
							 for(var j = 1; j < subsp.length; j++) {
									tbl += ":";
									if(subsp[j] != null)
										 tbl += subsp[j];
							 }
						tbl += "</td></tr>";
						}
				 } else {
						if(sp.length == i+1)
							 break; // skip an extra blank line.
						tbl += "<tr><td> &nbsp; </td><td> &nbsp; </td></tr>";
				 }
			}
			tbl += "</tbody></table>";

			var elem = document.getElementById(fieldId.m_fieldName);
			elem.innerHTML = tbl;
	 } catch(err) {
			setDiv(fieldId.m_fieldName, value);
	 }
}

function isHostnameOrIPAddressV4V6(text)
{
		if (!isHostnameOrIPAddress(text))
		{
				if (isIPV6(text))
				{
						return true;
				}
				else
				{
						return false;
				}
		}
		else
		{
				return true;
		}
}

// Validate the hostname or ip address
function isHostnameOrIPAddress(text)
{
		validIpAddressRegex = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/;
		validHostnameRegex  = /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9_\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9_\-]*[A-Za-z0-9])$/;
		var validIp       = validIpAddressRegex.test(text);
		var validHostname = validHostnameRegex.test(text);
		if(validIp || validHostname)
		{
				return true;
		}
		else
		{
				return false;
		}
}

//This function will validate below conditions.
//1.It should not have ::
//1.It should valid Ip address in the format of x:x:x:x:x:x:x:x or x:x:x:x:x:x:d.d.d.d
//2.It should not be loopback addr (::1)
//3.It should not be multicast addr (FFxx::) i.e should not start with FF
function isValidIpv6Addr(ipAddr,prefix)
{
		var validIp = true;

		if(ipAddr =="::")
		{
				validIp = false;
		}
		else
		{
				var ipFormat1 = isIPV6(ipAddr);
				var ipFormat2 = isIPV6WithIPV4(ipAddr);

				if (ipFormat1 || ipFormat2)
				 {
						 var ipAsColon = false;
						 if (ipFormat1)
								 ipAsColon = isIpv6AsDoubleColon(ipAddr);
						 else
								 { //Split Ipv6 address from Ipv4
											 var tStr = ipAddr;
											 var dotPos = tStr.indexOf(".");
											 var tempStr = tStr.substring(0,tStr.lastIndexOf(":",dotPos)+1);
											 var ipv6Str = "";
											 if (tempStr.lastIndexOf("::")==tempStr.length-2)
												 {
															ipv6Str = tempStr;
												 }
												else
												 {
															 ipv6Str = tempStr.substring(0,tempStr.lastIndexOf(":"));
												 }

													ipAsColon = isIpv6AsDoubleColon(ipv6Str);
								 }
								 if (ipAsColon)
								 {
											validIp = false;
								 }
								 else
								 {
										 if(!isLoopBackAddr(ipAddr))
											{
													if (isMulticastAddr(ipAddr))
																 validIp = false;
											}
											else
												validIp = false;
								 }

				 }
				 else
						validIp = false;
		}

		 return validIp;
}

var ErrorMessage = {
	on401Status: function(){
		showMessage("RAC0506");
	},
	on404Status: function(){
		showMessage("RAC0507");
	},
	on500Status: function(){
		showMessage("RAC0508");
	},
	on503Status: function(){
		showMessage("RAC0509");
	},
	on302Status: function(){
		showMessage("RAC0509");
	}
}

function showMessage(_id){
	 alert(top.localeObj["EEMI_"+_id]);
}

 function validateDuplicatePort(e) {
	if(e.status == 500) {
		var response = e.responseText.evalJSON(true);
		var msgref = response.Error.msgref;
		var msgid = msgref.substring(msgref.lastIndexOf('/')+1,msgref.length);

		if(msgid == "RAC0763") {
			showMessage(msgid);
		} else {
			showMessage("RAC0618");
		}
	} else if(e.status == 401 || e.status == 404 || e.status == 503 || e.status == 302) {
		ErrorMessage['on'+e.status+'Status']();
	}
}

function isEmptyObject(obj) {
		for(var key in obj) {
				if(obj.hasOwnProperty(key))
						return false;
		}
		return true;
}

try {
	var tmp_ajax_request = Ajax.Request;
	Ajax.Request = function(url, args) {
		if(url == undefined) {
			return new tmp_ajax_request(url,args);
		} else {
			var c = Object.clone(args);
			c.onSuccess = function(transport){
				if(transport.responseJSON && transport.request.url.indexOf(".json") == -1) {
					transport.responseText = transport.responseText.escapeHTML();
					//console.log(transport.request.url + ":"+transport.responseText);
				}
				args.onSuccess(transport);
			}
			return new tmp_ajax_request(url, c);
		}
	}

	//Ajax.Request.protoype = new tmp();
	Ajax.Request.Events = tmp_ajax_request.Events;
	delete tmp_ajax_request;
} catch (e) {
}

// Array to hold the Extended Health status
var extHlthStatusArray = [];

// Constant Object to hold the Extended Health Status
var CONST_STATUS = {
	OTHER_NOT_SUPPORTED : 0,
	UNKNOWN : 1,
	OK : 2,
	NON_CRITICAL : 3,
	CRITICAL : 4
};

// Constant Object to hold the Extended Health Status - List
var CONST_HEALTH_SUBSYSTEM = {
	GLOBAL : 0,
	MISC : 1,
	FAN : 2,
	IDSDM : 3,
	PSU : 4,
	SDCARD : 5,
	BATTERY : 6,
	INTRUSION : 7,
	CURRENT : 8,
	MEMORY : 9,
	CPU : 10,
	TEMPERATURE : 11,
	TEMPSTATISTICS : 12,
	VOLTAGE : 13,
	CMC : 14,
	SDPORT : 15,
	REM_FLASH_MEDIA : 16
};

// Constant Array to hold the string for Extended Health Status
var CONST_STATUS_ARRAY = [
	"status_not_supported",
	"status_unknown",
	"status_ok",
	"status_noncritical",
	"status_critical"
];

// API to get the Extended Health Status
function getExtHlthStatus()
{
	var URI = "/sysmgmt/2016/server/extended_health";
	var config = new Ajax.Request(URI, {
		method : "get",
		requestHeaders : ["ST2", top.TOKEN_VALUE, "idracAutoRefresh", "1"],
		onSuccess : getExtHlthStatusResponse,
		onFailure : getExtHlthStatusError
	});
}

// API to be called when the Extended Health Status URI return success
function getExtHlthStatusResponse(e) {
	var restObj = e.responseText.evalJSON(true);
	extHlthStatusArray = restObj["healthStatus"];
	frameServerHealthArray();
}

// Clearing the extended health status array with value status_unknown
function clearExtHlthStatusArray() {
	for (i = 0; i < CONST_HEALTH_SUBSYSTEM.length; i++)
		extHlthStatusArray[i] = CONST_STATUS.UNKNOWN;
}
