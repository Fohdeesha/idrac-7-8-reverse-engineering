var amberBlinkLed = "amberFlashLed"; 
var amberSolidLed = "amberLed";
var blueBlinkLed = "blueFlashLed";
var blueSolidLed = "blueLed";
var grayLed = "grayLed";


//
/*
*isCmcBlade :lcdled page name is isCmcBlade; sysSummary page name is isCmc
*ledBlink : 0 is not blink, 1 is blink
*lcdHostEventStatus : status on Blade Servers

0x0000 = 0000 0000 0000 0000: Normal
0x0001 = 0000 0000 0000 0001: Power On (if no errors)

0x07de = 0000 0111 1101 1110: [AVCT Define for fault code]
0x0002 = 0000 0000 0000 0010: Error (Mostly means system happens non-critical error)
0x0004 = 0000 0000 0000 0100: Failed (mostly means system happens critical or non-recoverable error)
0x0008 = 0000 0000 0000 1000: Power Off (Error and Failed priority higher than power Off)
0x0010 = 0000 0000 0001 0000: Throttled
0x0020 = 0000 0000 0010 0000: Failsafe
0x0040 = 0000 0000 0100 0000: Thermal trip
0x0080 = 0000 0000 1000 0000: PFault
0x0100 = 0000 0001 0000 0000: Over-current
0x0200 = 0000 0010 0000 0000: Server powering on is pending
0x0400 = 0000 0100 0000 0000: VIS MAC Ownership
*/
function getLedStatusType(ledBlink,szlcdHostEventStatus,isCmcBlade,lcdVisibleErrCount,lcdHiddenErrCount)
{
    var sysidledstyle = "";    
          
    var ledBlink = ledBlink==null?"":ledBlink;
    var lcdHostEventStatus = szlcdHostEventStatus === null || szlcdHostEventStatus === "" ? 
    							-1 : parseInt(szlcdHostEventStatus);
    var visibleErrCount = parseInt(lcdVisibleErrCount,10);
    var hiddenErrCount = parseInt(lcdHiddenErrCount,10);
          	   
    if(ledBlink==1)
    {
        //Rack Servers(Monolithic)&& Blade Servers
        sysidledstyle = blueBlinkLed;
    }
    else
    {
        //Blade Servers    
        if(isCmcBlade =="true") 
        {           	        	
            if (lcdHostEventStatus != -1)
            {         
                if(lcdHostEventStatus & 0x07de)
                {                	
                    if ((lcdHostEventStatus & 0x0008) && (visibleErrCount==0) && (hiddenErrCount==0))
                    {
                         //BITS087583 (blade): System ID LED on Home page is not working in Modular server
                         sysidledstyle = grayLed;
                    }
                    else
                    {
                	    sysidledstyle = amberBlinkLed;
                    }
                }      
                else if(lcdHostEventStatus & 0x0020)
                {
                    //0x0020  failsafe display solid amber
                    sysidledstyle = amberSolidLed;
                }                                         
                else
                {
                    sysidledstyle = blueSolidLed;
                }
            }     
            else 
            {   
                //lcdHostEventStatus is empty, ledBlink is empty or 0
                sysidledstyle = grayLed;       
            }            
        }
        else
        {
            //Rack Servers(Monolithic)
            //isCmcBlade =="false" and ledBlink==0
            sysidledstyle = grayLed;    	        
        } 
    }    
    return sysidledstyle;
}


/*
   2013-05-31
   BITS081805 Expanded System ID LED Settings combo box on FP page collapses itself without user's actions in IE
*/
function setLEDOptions()
{
        var ledOptions = $('cbBlinkLed');
        ledOptions.options.length = 0;       
        
        var msgSelected = 0;
        for( i = 0; i < ledOptionsArr.length; i++)
        {
            ledOptions.options[i] = new Option(ledOptionsArr[i], i);
        }
}          


/*
   System ID LED Setting
   //2011-06-14 CR481230 change to be pulldown style, so no use this function
     
   IdentifyEnable=0 or 0x0 + IdentifyTimeout !=null ,will enable the timeout function
   TimeOut = {DAY1 : "8640000", WEEK1 : "60480000",MONTH1:"1814400000"};
*/
function led_submit()   
{     
   var req = ""; 
   var day1 = 8640000 ;
   var week1 = day1*7;
   var month1 = week1 *30;
   var timeoutArray =  $('cbBlinkLed') ;
  
   
   if(timeoutArray.length >0)
   { 
    	switch (timeoutArray.selectedIndex) 
        {
            case 1:
                 req +="IdentifyEnable:0";
                 break;
            case 2:
                 req +="IdentifyEnable:1";
                 break;
            case 3:
                 req +="IdentifyEnable:1";
                 req +=",IdentifyTimeout:"+ day1 ;
                 break;
            case 4:
                 req +="IdentifyEnable:1";
                 req +=",IdentifyTimeout:"+ week1 ; 
                 break;
            case 5:
                 req +="IdentifyEnable:1";
                 req +=",IdentifyTimeout:"+ month1 ;
                 break;                 
        }          
  }
  document.chainedCallback = loadLcdDataCallback;
  loadXMLDocument('data?set=' + req, waitWithCallback);
  $('cbBlinkLed').options[0].selected = true;
}


function led_cancel()   
{      	     
     $('cbBlinkLed').options[0].selected = true; 	
}
