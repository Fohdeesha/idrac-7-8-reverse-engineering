
// ********************************************************************
// Read the checked/unchecked state of the Extended Schema radio button on Step 3 of 4 and :
//    Return 1 for Extended checked 
//    Return 2 for Standard checked (convert 0 to 2)
function encodeSchema( formElement ) {
    var result = 1;    
    var selectedSchema = encodeRadio( formElement );
    result = selectedSchema == 0 ? "2" : "1";
    return result;
}
// ********************************************************************
// Based upon the value for ADExtendedSchemaEnabled returned from the server,
// set the checked/unchecked state of the Extended Schema radio button on Step 3 of 4 as :
//    Check the Extended radio btn for ADExtendedSchemaEnabled = 1 by leaving the value as 1
//    Check the Standard radio btn for ADExtendedSchemaEnabled = 2 by convertinging 2 to 0
function decodeSchema( fieldMapping, value ) {
    var newValue = 1;
    newValue = value == 2 ? 0 : 1;
    decodeRadio( fieldMapping, newValue );
}
// ********************************************************************
		function groupFromName(fieldName) 
		{
			return fieldName.charAt(7);
		}

		//Convert privilege checkboxes to single string for server
		function encodePrivs(formElement)
		{
			//update the form locally to reflect the new value (just in case)...
			var groupNum = groupFromName(formElement.id);
			var privBits = getPrivBits(groupNum);
			//parse the string as a base 2 (binary) number into an int...
			var privShort = parseInt(privBits, 2);
			formElement.value = privShort;
			//expected behavior of encoders is to return the encoded value so...
			return formElement.value;
		}

		//Convert single string from server into privilege checkbox values
		function decodePrivs(fieldMapping, value)
		{
			var groupNum   = groupFromName(fieldMapping.m_fieldName);
			var checkBoxes = getCheckBoxes(groupNum);
			var privBits   = privBitsFromShort(value);
			setCheckBoxesFromPrivBits(privBits, checkBoxes);
		}

	    //...other data elements...
	    var snapRoleState = null; //Saves state of Configure Role page
	    function RoleState(subTarget) 
	  	{
	  		//Group numbers are 1 indexed.
	  		this.groupNum = subTarget + 1;
	  		this.groupName = document.getElementById("ADGroup" + this.groupNum + "Name").value;
	  		this.groupDomain = document.getElementById("ADGroup" + this.groupNum + "Domain").value;
	  		this.privBits = getPrivBits(this.groupNum);
	  		this.privSelectIndex = document.getElementById("ADGroup" + this.groupNum + "PrivSelect").selectedIndex;
	  	}

// This function depends upon ADUserDomain_Value containing the full or partial list of UserDomainNames separated by "*"'s
// so, options2UserDomains() must have been called just before this function is called.
// The two parameters passed in (formElement, fieldList) are not used. 
// This function depends upon ADUserDomain_Value having the next value when it is needed.
    function encodeUserDomains()
  	{
        if (ADUserDomain_Value == "") 
            { 
               return "";
            }
        var locSplat   = 0;
        var UserDomain = "";

        ADUserDomain_Value = trim(ADUserDomain_Value);
        locSplat = ADUserDomain_Value.indexOf("*");                 // find the first Splat, if it exists
        if (locSplat < 0) { return ADUserDomain_Value; }            // This is the last UserDomainName 
        UserDomain = ADUserDomain_Value.substr(0, locSplat);        // Get the current UserDomainName without the "*"
        ADUserDomain_Value = ADUserDomain_Value.slice(locSplat + 1);// Get str with this UserDomain & "*" removed
        return UserDomain;
  	}

          function handleDcSRVLookupEnable1() {
              document.getElementById("cfgADDcSRVLookupEnable2").checked = false;
			  document.getElementById("ADDomainServer").disabled = true;
			  document.getElementById("ADDomainServer2").disabled = true;
			  document.getElementById("ADDomainServer3").disabled = true;
			  
			  document.getElementById("cfgADDcSRVLookupbyUserdomain1").disabled = false;
			  document.getElementById("cfgADDcSRVLookupbyUserdomain2").disabled = false;
			  document.getElementById("cfgADDcSRVLookupDomainName").disabled = false;
			  
			  if(document.getElementById("cfgADDcSRVLookupbyUserdomain1").checked)
			     handleDcSRVLookupbyUserdomain1();
		  }
		  
          function handleDcSRVLookupEnable2() {
              document.getElementById("cfgADDcSRVLookupEnable1").checked = false;
			  document.getElementById("ADDomainServer").disabled = false;
			  document.getElementById("ADDomainServer2").disabled = false;
			  document.getElementById("ADDomainServer3").disabled = false;
			  
			  document.getElementById("cfgADDcSRVLookupbyUserdomain1").disabled = true;
			  document.getElementById("cfgADDcSRVLookupbyUserdomain2").disabled = true;
			  document.getElementById("cfgADDcSRVLookupDomainName").disabled = true;
		  }
		  
		  function handleDcSRVLookupbyUserdomain1() {
              document.getElementById("cfgADDcSRVLookupbyUserdomain2").checked = false;
			  document.getElementById("cfgADDcSRVLookupDomainName").disabled = true;
          }
		  
		  function handleDcSRVLookupbyUserdomain2() {	        
              document.getElementById("cfgADDcSRVLookupbyUserdomain1").checked = false;
              //Added to fix :DF489941: BDC_ES:"Look Up Domain Controllers with DNS" values are wrongly enumerated
              //document.getElementById("cfgADDcSRVLookupDomainName").disabled = false;
              var bCheck = document.getElementById("cfgADDcSRVLookupEnable1").checked ;
			  document.getElementById("cfgADDcSRVLookupDomainName").disabled = !bCheck;
          }
		  /////////////////////////////////////
          function handleGcSRVLookupEnable1() {
              document.getElementById("cfgADGcSRVLookupEnable2").checked = false;
			  document.getElementById("ADGlobalCatalogDomain").disabled = true;
			  document.getElementById("ADGlobalCatalogDomain2").disabled = true;
			  document.getElementById("ADGlobalCatalogDomain3").disabled = true;
			  
			  document.getElementById("cfgADRootDomain").disabled = false;
		  }
		  
          function handleGcSRVLookupEnable2() {
              document.getElementById("cfgADGcSRVLookupEnable1").checked = false;
			  document.getElementById("ADGlobalCatalogDomain").disabled = false;
			  document.getElementById("ADGlobalCatalogDomain2").disabled = false;
			  document.getElementById("ADGlobalCatalogDomain3").disabled = false;
			  
			  document.getElementById("cfgADRootDomain").disabled = true;
              
			  //this line shoud not be here need to confirm with Steven Lau :  DF467774
			  //document.getElementById("cfgADDcSRVLookupDomainName").disabled = true;
		  }

function decodeDcSRVLookupEnable( fieldMapping, value ) {
    //alert("decodeDcSRVLookupEnable: " + value);
    if(value == 1) {
        // Look Up Domain Controllers with DNS
        document.getElementById("cfgADDcSRVLookupEnable1").checked = true;
        handleDcSRVLookupEnable1();
    } else {
        // Specify Domain Controller Addresses
        document.getElementById("cfgADDcSRVLookupEnable2").checked = true;
        handleDcSRVLookupEnable2();
    }
}

function decodeDcSRVLookupbyUserdomain( fieldMapping, value ) {
    //alert("decodeDcSRVLookupbyUserdomain: " + value);
    if(value == 1) {
        // Specify a Domain to Look Up
        document.getElementById("cfgADDcSRVLookupbyUserdomain1").checked = true;
        handleDcSRVLookupbyUserdomain1();
    } else {
        // User Domain from Login
        document.getElementById("cfgADDcSRVLookupbyUserdomain2").checked = true;
        handleDcSRVLookupbyUserdomain2();
    }
}

function decodeDcSRVLookupDomainName( fieldMapping, value ) {
    //alert("decodeDcSRVLookupDomainName: " + value);
    if(value == null)
        value = "";
		
    document.getElementById("cfgADDcSRVLookupDomainName").value = value;
}

function decodeGcSRVLookupEnable( fieldMapping, value ) {
    //alert("decodeGcSRVLookupEnable: " + value);
	
	if(value == 1) {
	    // Look Up Global Catalog Servers with DNS
            document.getElementById("cfgADGcSRVLookupEnable1").checked = true;
            handleGcSRVLookupEnable1();
	} else {
	    // Specify Global Catalog Server Addresses
            document.getElementById("cfgADGcSRVLookupEnable2").checked = true;
            handleGcSRVLookupEnable2();
	}
}

function decodeADRootDomain( fieldMapping, value ) {
    //alert("decodeADRootDomain: " + value);
    if(value == null)
        value = "";
		
    document.getElementById("cfgADRootDomain").value = value;
}
