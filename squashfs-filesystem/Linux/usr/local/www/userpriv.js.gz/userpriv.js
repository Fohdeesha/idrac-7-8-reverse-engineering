// *************************************************************************
// 
/* Moved here from functions.js:
	setCheckBoxesFromPrivBits()
	setCheckBoxesFromPrivSelect()
	setPrivSelectFromPrivBits()
	bitsFromPriv()
	privFromBits()
	privBitsFromShort()
  Removed from functions.js:
    racUserTypeToName()
*/
// *************************************************************************
//
// Used by adsummary.html, admgmt.html & userlist.html & useredit.html & index.html
//
// NOTE: There are probably functions in admgmt.html & userlist.html & useredit.html
//       that can be consolidated into this file or that can be replaced by functions
//       in this file. RBJ 06/05/07.
//
// These are the predefined roles that apply to the iDRAC user and the AD user.
// Providing these in so many forms is just for programmer convienence. 
var INT_ADMIN_ROLE      = 511;
var INT_OPERATOR_ROLE   = 499; 
var INT_READONLY_ROLE   = 1;
var INT_NONE_ROLE       = 0; 
var INT_DEFAULT_ROLE    = INT_OPERATOR_ROLE; 

var BITS_ADMIN_ROLE     = "111111111"; // 0x1ff <<<< Note that the role is represented by a STRING 
var BITS_OPERATOR_ROLE  = "111110011"; // 0x1f3
var BITS_READONLY_ROLE  = "000000001"; // 0x001
var BITS_NONE_ROLE      = "000000000"; // 0x000
var BITS_DEFAULT_ROLE   = BITS_OPERATOR_ROLE;

var HEX_GENERIC_OPERATOR ="0x1fe";//"111111110" anything except login

var HEX_ADMIN_ROLE      = 0x1ff;
var HEX_OPERATOR_ROLE   = 0x1f3;
var HEX_READONLY_ROLE   = 0x001; 
var HEX_NONE_ROLE       = 0x000; 
var HEX_DEFAULT_ROLE    = HEX_OPERATOR_ROLE;


var NAME_ADMIN_ROLE_ABB = top.adminRollAbb//"Admin";         // userlist.html uses Admin instead of Administrator
var NAME_ADMIN_ROLE     = top.adminRole//"Administrator";
var NAME_OPERATOR_ROLE  = top.operatorRole//"Operator";
var NAME_READONLY_ROLE  = top.readOnlyRole//"Read Only";
var NAME_NONE_ROLE      = top.noneRole//"None"; 

var NAME_DEFAULT_ROLE   = NAME_OPERATOR_ROLE;

// ****************************************************************************************
// 06/13/08 rbj:
// This section MUST exist in an HTML file bcz the server doesn't execute server side Javascript in a .js file
// It is in index.html
// var CAN_LOGIN       = false;
// var CAN_CFG_IDRAC   = false;
// var CAN_CFG_USER    = false;
// var CAN_CLEAR_LOGS  = false;
// var CAN_EXE_CMDS    = false;
// var CAN_VKVM        = false;
// var CAN_VMEDIA      = false;
// var CAN_TEST_ALERT  = false;
// var CAN_EXE_DIAGS   = false;
// 
// <% if( session["loginToDRAC"]                  == 1 ) { %> CAN_LOGIN      = true; <% } %>
// <% if( session["configureDRAC"]                == 1 ) { %> CAN_CFG_IDRAC  = true; <% } %>
// <% if( session["configureUsers"]               == 1 ) { %> CAN_CFG_USER   = true; <% } %>
// <% if( session["clearLogs"]                    == 1 ) { %> CAN_CLEAR_LOGS = true; <% } %>
// <% if( session["executeServerControlCommands"] == 1 ) { %> CAN_EXE_CMDS   = true; <% } %>
// <% if( session["accessConsoleRedirection"]     == 1 ) { %> CAN_VKVM       = true; <% } %>
// <% if( session["accessVirtualMedia"]           == 1 ) { %> CAN_VMEDIA     = true; <% } %>
// <% if( session["testAlerts"]                   == 1 ) { %> CAN_TEST_ALERT = true; <% } %>
// <% if( session["executeDiagnosticCommands"]    == 1 ) { %> CAN_EXE_DIAGS  = true; <% } %>
// 
// var userRights = cans2StrPriv();                    // used by index.html & other pages
// var privilege  = privFromBits(userRights);          // used by index.html

//  This function creates a String of 1's & 0's that represent the user privileges
// NOTE!!! The "CAN_" vars only exist if index.html is loaded and has gotten past the
//         point where they are defined & initilized.
function concatPrivStr(){
	var strPriv = "";
	var test  = top.CAN_EXE_DIAGS;
	if (CAN_EXE_DIAGS   == true) {strPriv =  "1"} else {strPriv  = "0"}
	if (CAN_TEST_ALERT  == true) {strPriv += "1"} else {strPriv += "0"}
	if (CAN_VMEDIA      == true) {strPriv += "1"} else {strPriv += "0"}
	if (CAN_VKVM        == true) {strPriv += "1"} else {strPriv += "0"}
	if (CAN_EXE_CMDS    == true) {strPriv += "1"} else {strPriv += "0"}
	if (CAN_CLEAR_LOGS  == true) {strPriv += "1"} else {strPriv += "0"}
	if (CAN_CFG_USER    == true) {strPriv += "1"} else {strPriv += "0"}
	if (CAN_CFG_IDRAC   == true) {strPriv += "1"} else {strPriv += "0"}
    if (CAN_LOGIN       == true) {strPriv += "1"} else {strPriv += "0"}
    return strPriv;
}
//  This function creates an integer value that represent the user privileges.
// NOTE!!! The "CAN_" vars only exist if index.html is loaded and has gotten past the
//         point where they are defined & initilized.
function concatPrivInt(){
	var intPriv = 0;
	if (CAN_EXE_DIAGS   == true) {intPriv += P_DEBUG }
	if (CAN_TEST_ALERT  == true) {intPriv += P_TEST_ALERT}
	if (CAN_VMEDIA      == true) {intPriv += P_VMEDIA}
	if (CAN_VKVM        == true) {intPriv += P_VKVM}
	if (CAN_EXE_CMDS    == true) {intPriv += P_RESET}
	if (CAN_CLEAR_LOGS  == true) {intPriv += P_LOG_CLEAR}
	if (CAN_CFG_USER    == true) {intPriv += P_USER_CFG}
	if (CAN_CFG_IDRAC   == true) {intPriv += P_CARD_CFG}
    if (CAN_LOGIN       == true) {intPriv += P_LOGIN}
    return intPriv;
}
// ****************************************************************************************
// These are the privilege bit definitions. Think of them as mask definitions.
// When the corresponding bit is set to 1 the user can perform the operation
var P_LOGIN		  = 1;   //Can Log into iDRAC
var P_CARD_CFG	  = 2;   //Can Configure iDRAC
var P_USER_CFG	  = 4;   //Can Configure Users
var P_LOG_CLEAR   = 8;   //Can Clear Logs
var P_RESET	      = 16;  //Can Execute Server Control Commands
var P_VKVM		  = 32;  //Can Access Console Redirection
var P_VMEDIA   	  = 64;  //Can Access Virtual Media
var P_TEST_ALERT  = 128; //Can Test Alerts
var P_DEBUG		  = 256; //Can Execute Diagnostic Commands

// ************************************************************************
// Map a set of privilege bits (as an integer) to a user role Name
// Return a string representation of the user's role
function racUserRoleToName( bitsRole ) {
	var strRole = NAME_DEFAULT_ROLE;
	intRole     = parseInt(bitsRole);
	
	//Fix for: DF489520: user created using the local racadm command is showing as operator/admin in GUI
	if( (intRole & HEX_ADMIN_ROLE) == HEX_ADMIN_ROLE)
		strRole = NAME_ADMIN_ROLE;
	else if( intRole & HEX_GENERIC_OPERATOR )
		strRole = NAME_OPERATOR_ROLE;
	else if( (intRole & HEX_READONLY_ROLE) == HEX_READONLY_ROLE)
		strRole = NAME_READONLY_ROLE;
	else if( (intRole & HEX_NONE_ROLE) == HEX_NONE_ROLE)
		strRole = NAME_NONE_ROLE;
	else  // default for no match
		strRole = NAME_DEFAULT_ROLE;

	return strRole;
}
// ************************************************************************
//Given a STRING bitmask where the bits are as defined above,
//...return a string representation of the name of the corresponding privilege group.
function privFromBits(bitsRole) 
{
	if      (bitsRole == BITS_ADMIN_ROLE)    { return NAME_ADMIN_ROLE;    }
	else if (bitsRole == BITS_OPERATOR_ROLE) { return NAME_OPERATOR_ROLE; }
	else if (bitsRole == BITS_READONLY_ROLE) { return NAME_READONLY_ROLE; }
	else if (bitsRole == BITS_NONE_ROLE)	 { return NAME_NONE_ROLE;     }
	return NAME_DEFAULT_ROLE;
}
// ************************************************************************
// Give the privilege name, return the STRING bitmask that represents it.
function bitsFromPriv(strRole) {
	if      (strRole == NAME_ADMIN_ROLE)    { return BITS_ADMIN_ROLE;    }
	else if (strRole == NAME_OPERATOR_ROLE) { return BITS_OPERATOR_ROLE; }
	else if (strRole == NAME_READONLY_ROLE) { return BITS_READONLY_ROLE; }
	else if (strRole == NAME_NONE_ROLE)     { return BITS_NONE_ROLE; }
	return BITS_DEFAULT_ROLE;
}
// ************************************************************************
// Give the privilege name, return the HEX bitmask that represents it.
function hexFromPriv(strRole) {
	if      (strRole == NAME_ADMIN_ROLE)    { return HEX_ADMIN_ROLE;    }
	else if (strRole == NAME_OPERATOR_ROLE) { return HEX_OPERATOR_ROLE; }
	else if (strRole == NAME_READONLY_ROLE) { return HEX_READONLY_ROLE; }
	else if (strRole == NAME_NONE_ROLE)     { return HEX_NONE_ROLE; }
	return HEX_DEFAULT_ROLE;
}
// ************************************************************************
//Given a select control with options...
//<option value="Administrator">Administrator</option>
//<option value="Operator">Operator</option>
//<option value="Read Only">Read Only</option>
//<option value="None">None</option>
//...and a bitmask corresponding to the mask described in the privFromBits function,
//assign the select control the value corresponding to the given bitmask.
function setPrivSelectFromPrivBits(selectControl, bitsRole) {
	var strRole     = privFromBits(bitsRole);
	var privOptions = selectControl.options;
	for (var currentOption = 0; currentOption < privOptions.length; currentOption++) {
		if (privOptions[currentOption].value == strRole) {
			selectControl.selectedIndex = currentOption;
			break;
		}
	}
}
// ************************************************************************
//Given a select control with options as outlined in setPrivSelectFromPrivBits,
//and an array of check box controls corresponding to the privileges outlined in 
//privFromBits, populate the checkboxes according to the privs for the Role.
function setCheckBoxesFromPrivSelect(privSelect, checkBoxes) {
	var selectedIndex = privSelect.selectedIndex;
	var strRole       = privSelect.options[selectedIndex].value;
	var strBits       = bitsFromPriv(strRole);
	setCheckBoxesFromPrivBits(strBits, checkBoxes);
}
// ************************************************************************
//Given a set of priv bits and an array of checkboxes set the checkboxes
//from the priv bits...
function setCheckBoxesFromPrivBits(strBits, checkBoxes)
{
	var bitsArray = strBits.split("");
	for (var privIndex = 0; privIndex < strBits.length; privIndex++) {
		checkBoxes[privIndex].checked = bitsArray[privIndex] == "1" ? true:false;
	}
}
// ************************************************************************
// Given a decimal number representing a bitmask for privilages,
// convert to the corresponding bitmask.
function privBitsFromShort(privShort) {
	var privBits = Number(privShort).toString(2);  	// Convert from decimal to binary
	while (privBits.length < 9) {                   // Get the appropriate length string ignoring high order bits if present.
		privBits = "" + "0" + privBits;		        // build short strings out to 9 characters by adding leading 0s 
	}
	if (privBits.length > 9) {                      // trim long strings from the left so we have only 9 bits...
		privBits = privBits.substring(privBits.length - 9);
	}
	return privBits;
}
//The end of userpriv.js


