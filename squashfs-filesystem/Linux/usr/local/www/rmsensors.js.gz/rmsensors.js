/**
 * Submit a request for data to the server and call
 * refreshDiscreteDataCallback when the response arrives.
 */
function refreshDiscreteData(data) 
{
    document.chainedCallback = refreshDiscreteDataCallback;
    loadXMLDocument(data, waitWithCallback);
}

function refreshRmvsData(data) 
{
    document.chainedCallback = refreshRmvsDataCallback;
    loadXMLDocument(data, waitWithCallback);
}

function insertStatusIcon(row, cell, status)
{
    var x = document.getElementById(row);
    if (null == x)
        return;
    x = x.insertCell(cell);
    x.innerHTML = "<align='center' valign='middle'> <img src=" + status + " align='absmiddle' border='0'>";
}

var Status = {OK : 0, ALERT : 1, FAILED : 2};

statusImg = new Array();
/*statusImg[Status.ALERT]		= "images/non-critical.gif";
statusImg[Status.FAILED]	= "images/critical.gif";
statusImg[Status.OK]		= "images/ok.gif";*/

statusImg[Status.ALERT]		= "noncritical";
statusImg[Status.FAILED]	= "critical";
statusImg[Status.OK]		= "ok";
    
function stringToIcon(str) {
    switch (str) {
	case 'Normal':
            return "images/ok.gif";
	case 'Warning':
            return "images/non-critical.gif";
	case 'Critical':
            return "images/critical.gif";
    }
}


function convert(str)
{
	switch (str) {
	case 'normal':
		return "ok";
	case 'warning':
		return "noncritical";
	}
	
	return str;
}

var	powerOn = 'powerOn';
var xmlItem = 'sensor';
//xmlRedundancy = 'discreteSensorList';
// 06/10/08 rbj: Added to resolve PR27820: Fan Redundancy is not displayed.
//               This function is only called by refreshThresholdDataCallback(xmlDoc) below,
//               which is only called by listfan.html onLoad & Refresh button.
//               The sensorStatus & name tags are available but not needed.
function refreshRedundancy(xmlDoc){
    var reading = "";

    var list = getXMLValue(xmlDoc, xmlDiscreteList) ;
    if( list != null  && typeof list == "object" ) {
        var item = list.getElementsByTagName(xmlItem);
        if( item != null ) {
            for (var i = 0; i < item.length; i++) {
                var entry = item[i];
                reading = entry.getElementsByTagName("reading")[0].childNodes[0].nodeValue;
	    }
	}
    }

    var value = 1; // reading == "Disabled"

    if ((reading == "full") ||  (reading == "Full"))
    {
        reading = "Full";
        value = 0;
    }
    else if ((reading == "lost") || (reading == "Lost"))
    {
        reading = "Lost";
        value = 2;
    }
	else if ((reading == "degraded") || (reading == "Degraded"))
	{
		reading = "Degraded";
		value = 1;
	}
	else // reading == "Disabled"
	{
        value = 3;
		hideElement('RedundancyJumpBar');
		hideElement('RedundancyTableSection');
		hideElement('RedundancyTableBackBar');
	}

    setDiv("redundancyStatus", reading);
    //insertStatusIcon('redundancyInfo', 1, statusImg[value]);
	  if (value == 3)
	  {
				document.getElementById('redundancyInfoIcon').className = 'status_' + (trim(statusImg[value-2])).toLowerCase();
	      return value;  
		}
	  else
	  {
				document.getElementById('redundancyInfoIcon').className = 'status_' + (trim(statusImg[value])).toLowerCase();
	      return value;        
	  }
}

function fixProgressBar()
{   // hack to fix IE8 progress
    //top.hidden_frame.document.write('');
    //top.hidden_frame.document.close();
    setTimeout("document.getElementById('ifrdummy').src = 'blank_005.html'", 1000);
}

xmlDiscreteList = 'discreteSensorList';

// Does this function ever gets call?  Can we safely remove it?
//
function refreshDiscreteDataCallback(xmlDoc) 
{
    if (xmlDoc!=null) {
        //Extract data from the returned XML...
        var pwOn = getXMLValue(xmlDoc, powerOn);
        if (pwOn == "") {
            showPowerOffPanel();
        }
        else 
        {
	    var globalStatus = "Normal";
            var list = getXMLValue(xmlDoc, xmlDiscreteList) ;
	
            if( list != null && typeof list == "object" ) {
                var item = list.getElementsByTagName(xmlItem);
                if( item != null) {
                    // Process the XML Snippet row by row
                    for (var i = 0; i < item.length; i++) {
                        // Populate the cells
                        var entry = item[i];
                        var row = new Array();
                        row[0] = new Cell(Cell.BLANK);
                        row[1] = new Cell(Cell.BLANK);
                        var name = entry.getElementsByTagName("name")[0].childNodes[0].nodeValue;
                        row[2] = new Cell(Cell.CONTENT, name, 'left');
                        row[3] = new Cell(Cell.BLANK);

                        var reading = entry.getElementsByTagName("reading")[0].childNodes[0].nodeValue;
                        row[4] = new Cell(Cell.CONTENT, reading, 'center');

                        var sensorStatus = entry.getElementsByTagName("sensorStatus")[0].childNodes[0].nodeValue;
                        row[0] = new Cell(Cell.ICON, stringToIcon(sensorStatus), 'center');

                        appendTableRow("probes_table", row);
                        switch (globalStatus) {
                            case "Normal":
                                globalStatus = sensorStatus; 
                                break;
                            case "Warning":
                                if ("Critical" == sensorStatus) {
                                    globalStatus = "Critical";
                                }
                                break;
                            case "Critical":
                                break;
                        }
                    }
                }
            }
                        
            //insertStatusIcon('probesInfo', 1, stringToIcon(globalStatus));
						document.getElementById('probesInfo').className = 'status_' + convert((trim(globalStatus)).toLowerCase());
            showContentPanel();
        }
    }
    else 
    {
        showContentPanel();
    }
    
    fixProgressBar();
}

xmlRmvsList = 'remsSensorList';

function refreshRmvsDataCallback(xmlDoc) 
{
    if (xmlDoc!=null) {
        //var pwOn = getXMLValue(xmlDoc, powerOn);
        var redundancyStatus = refreshRedundancy(xmlDoc);		

        var globalStatus = "Normal";
        var sensorlist = xmlDoc.getElementsByTagName(xmlRmvsList);
        for (var j = 0; j < sensorlist.length; j++) {
            var sensor = sensorlist[j].getElementsByTagName("sensor");
            for (var i = 0; i < sensor.length; i++) {
                var entry = sensor[i];

		    var row = new Array();
		    row[0] = new Cell(Cell.BLANK);

		    loc = entry.getElementsByTagName("location");
                if (loc.length > 0 && loc[0].childNodes.length > 0) {
		        loc = loc[0].childNodes[0].nodeValue;
                    row[2] = new Cell(Cell.CONTENT, loc, 'left');
                } else {
                    row[2] = new Cell(Cell.BLANK);
		    }

                online = entry.getElementsByTagName("onlineStatus");
                if (online.length > 0 && online[0].childNodes.length > 0) {
		        online = online[0].childNodes[0].nodeValue;
		        row[3] = new Cell(Cell.CONTENT, online, 'left');
                } else {
                    row[3] = new Cell(Cell.BLANK);
		    }

		    row[4] = new Cell(Cell.BLANK);

                sensorstatus = entry.getElementsByTagName("sensorStatus");
                if (sensorstatus.length > 0 && sensorstatus[0].childNodes.length > 0) {
		        sensorstatus = sensorstatus[0].childNodes[0].nodeValue;

		        row[1] = new Cell(Cell.CONTENT, '<span class="status_' + convert((trim(sensorstatus)).toLowerCase()) + '">&nbsp;</span>', 'center');
		        appendTableRow("probes_table", row);
		        switch (globalStatus) {
		           case "Normal":
		              globalStatus = sensorstatus;
		              break;
		           case "Warning":
		              if ("Critical" == sensorstatus) {
		                 globalStatus = "Critical";
		              }
		              break;
		           case "Critical":
		              break;
		        } // end switch
                } // end if
            } // end for loop
        } // end for loop

        if (redundancyStatus == Status.FAILED)
            globalStatus = "Critical";

        showContentPanel();
    } else {
        showContentPanel();
    }
    
    fixProgressBar();
}

function refreshDiscrete(data) 
{
    showProgressPanel();
    refreshDiscreteData(data);
}

function refreshRmvs(data) 
{
    showProgressPanel();
    refreshRmvsData(data);
}

function showPowerOffPanel()
{
    hideElement( 'progressScreen' );
    showInlineElement( 'powerOffScreen' );
}


