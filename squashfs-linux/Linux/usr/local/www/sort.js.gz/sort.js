/**
 * Concatenates 2 arrays preserving the sort order of each,
 * placing the second array following the first.  Intended
 * as a helper for sorting.
 */
function concatenateArrays(lessOrEqual, greater) 
{
    var concat = new Array(lessOrEqual.length + greater.length);
    var x=0;
    //Start with the elements of the lessOrEqual array...
    for (x=x; x<lessOrEqual.length; x++) 
    {
        concat[x] = lessOrEqual[x];
    }
    for (x=x; x<(lessOrEqual.length + greater.length); x++) 
    {
        concat[x] = greater[x-lessOrEqual.length];
    }
    return concat;
}


 /**
  * Note:  Javascript arrays have a built in sort method which is very 
  * capable.  This method serves as an example of a quick sort implementation
  * in javascript.
  * Performs a case insensitive, alpha sort of an array 
  * using quick sort algorithm (divide and conquer):
  *
  *     If array size is 0 or 1 return the passed array.
  *     
  *     Array lessOrEqual
  *     Array greater
  *     pivotIndex = (array.length/2 rounded up) - 1
  *     Element pivot = array[pivotIndex]
  *     For each element in array with index < pivotIndex:
  *         if element <= pivot add to lessOrEqual
  *         if element > pivot add to greater
  *     For each element in array with index > pivot index:
  *         if element <= pivot add to lessOrEqual
  *         if element > pivot add to greater
  *     Element pivot is placed at the end of lessOrEqual
  *     return concatenate(quickSort(lessOrEqual), quickSort(greater))
  *
  * Where concatenate combines all the elements in the two arrays using
  * their current sort order.     
  *        
  *  
  */
 function quickSort(array)
 {
    //If the array is invalid or contains less than 2 elements then
    //  the array is sorted.  If this is a recursive call it means 
    //  we've finished sorting.
    if (array==null || array.length==undefined || array.length < 2)
    {
        return array;
    }
    //The current element and all elements less than current element
    var lessOrEqual = new Array(array.length);
    //All elements larger than current element
    var greater = new Array(array.length);
    //Pivot will be midpoint of array using round half up rounding
    //minus one to give us a midpoint below the middle, critical
    //for the last elements of the sort.
    //  3 :  3/2=2, 2-1 = 1
    //  2 :  2/2=1, 1-1 = 0
    var pivotIndex = (Math.round(array.length/2) - 1);
    var pivot = array[pivotIndex];
    var lessIndex=0;
    var greaterIndex=0;
    //Sort lower end of array
    for (x=0; x<pivotIndex; x++)
    {
        if (array[x].toLowerCase() > pivot) 
        {
            greater[greaterIndex] = array[x];
            greaterIndex++;
        }
        else 
        {
            lessOrEqual[lessIndex] = array[x];
            lessIndex++;
        }
    }
    //Skip the pivot point
    x++;
    //Sort higher end of array
    for (x=x; x<array.length; x++)
    {
        if (array[x].toLowerCase() > pivot) 
        {
            greater[greaterIndex] = array[x];
            greaterIndex++;
        }
        else 
        {
            lessOrEqual[lessIndex] = array[x];
            lessIndex++;
        }
    }
    //Put pivot at end of lower array
    lessOrEqual[lessIndex] = pivot;
    lessIndex++;
    //Resize the arrays to include only populated elements...
    lessOrEqual.length = lessIndex;
    greater.length = greaterIndex;
    
    //Broken out for the sake of clarity - keep dividing the results 
    //and recursing until there is only 1 element in both the upper and lower parts...
//    var lowerSplit = quickSort(lessOrEqual);
//    var upperSplit = quickSort(greater);
    //...having recursively divided all the parts, reassemble them using the implied tree
    //created through the recursive calls...
    return concatenateArrays(quickSort(lessOrEqual), quickSort(greater));
 }

/**
 * a member object for SortableTable used to identify the current sort state
 * orderBy is the index of the cell currently being used to sort the table
 * ascending is a flag, if true the current sort order is ascending
 */ 
function SortStatus() {
	this.orderBy = 0;
	this.ascending = true; 
}



/**
 * member function for SortableTable, requires sortStatus member variable be defined.
 *
 *The getMagnitude method will be passed two array elements
 *  from the events table and will get the index of the column to 
 *  sort on from the sortStatus document level variable.
 *  In order to use this function with Array.sort()
 *  the function must return...
 *  a[colIndex] > b[colIndex] ? 1
 *  a[colIndex] == b[colIndex] ? 0
 *  a[colIndex] < b[colIndex] ? -1
 */  
function SortableTable_getMagnitude(a, b) {
	//You will probably never need to have 2 rows in the same table that
	//  sort on different columns, but for the sake of consistency the 
	//  method uses the sort index for each row independently.
	colIndexA = a.orderBy;
	colIndexB = b.orderBy
	var magnitude = 0;
	//Note that if you pass rows a and b and one or the other fails to 
	//  contain the expected cell index you will generate a script error.
	if (a.cells[colIndexA].innerHTML > b.cells[colIndexB].innerHTML) {
		magnitude = 1;
	} else if  (a.cells[colIndexA].innerHTML < b.cells[colIndexB].innerHTML) {
		magnitude = -1;
	} 
	return magnitude;
}

// Comparing 2 strings indifferent of lower/upper case.   
function compareString(a, b) {
	//You will probably never need to have 2 rows in the same table that
	//  sort on different columns, but for the sake of consistency the 
	//  method uses the sort index for each row independently.
	colIndexA = a.orderBy;
	colIndexB = b.orderBy
	var magnitude = 0;
	//Note that if you pass rows a and b and one or the other fails to 
	//  contain the expected cell index you will generate a script error.
	var val1 = a.cells[colIndexA].innerHTML.toLowerCase();
	var val2 = b.cells[colIndexB].innerHTML.toLowerCase();
	if (val1 > val2) {
		magnitude = 1;
	} else if  (val1 < val2) {
		magnitude = -1;
	} 
	return magnitude;
}

// Comparing 2 numbers
function compareNumber(a, b) {
	//You will probably never need to have 2 rows in the same table that
	//  sort on different columns, but for the sake of consistency the 
	//  method uses the sort index for each row independently.
	colIndexA = a.orderBy;
	colIndexB = b.orderBy
	//Note that if you pass rows a and b and one or the other fails to 
	//  contain the expected cell index you will generate a script error.
	
	var val1 = a.cells[colIndexA].childNodes[0].childNodes[0];
	var val2 = b.cells[colIndexB].childNodes[0].childNodes[0];
	
	return val1 - val2;
}
   
    

/**
 * SortableTable takes an HTML DOM Table object as an optional constructor.
 * The SortableTable object wraps the Table object and adds sort functionality
 * to it, providing the sortTable method.  Note that you cannot pass a table 
 * as a constructor when declaring a new SortableTable due to the fact that 
 * the table will not yet be defined in the document (e.g. if you are in the
 * header of the doc and call...
 
 * 		new SortableTable(document.getElementById('logTable'));
 * 
 * ...you are, in fact, passing in a null and won't get the desired outcome.
 * 
 * To use this function instantiate a new SortableTable, insure that a table 
 * object has been passed in the constructor or otherwise assigned to the 
 * table field and then call the sortTable method passing the index of the 
 * cell to sort on.  If the table is declared as a document level variable 
 * (at the page level rather than at a function level) then each subsequent 
 * call to sort will reverse the current sort order.  If you did not declare
 * the table at the page level and wish to sort in descending order rather than
 * ascending order then set sortStatus.ascending = false and call sortTable.
 */
function SortableTable(aTable) {
	this.sortStatus = new SortStatus();
	this.headerRows = 0;
	this.useStyle = true;
	this.maxrec = false;
	this.getMagnitude = SortableTable_getMagnitude;
	this.table = aTable;
	this.sortTable = SortableTable_sortTable;
}
 
/**
 * member function for SortableTable
 * Sorts a table in order of the index passed in orderBy.  If 
 * state is preserved between calls (i.e. if SortableTable is declared
 * in the document header) then each subsequent call will reverse the 
 * sort order.  By default tables are sorted in ascending order.
 */ 
 //Note that this could easily be extended to provide for extended sorts (multiple columns)
 //  using an array for the passed arg and a recursive call in the getMagnitude method
 //  when two fields are equal.
function SortableTable_sortTable(orderBy) {
   	var aTable = this.table
   	//Get the table rows
   	var rows = aTable.rows;
   	 
   	
   	//var headingRows = new Array();
   	var dataRows = new Array();
   	var allRows = new Array();
   	//JS interpreter doesn't seem to want to slice rows,
   	//  concat to a new array and slice that.
   	for (var x=0; x<rows.length; x++) {
   		allRows[x] = rows[x];
   		//this is critical - attach an orderBy to each row indicating
   		//  the index for the cell used to sort the row.
   		allRows[x].orderBy = orderBy
   	}
   	//allRows.concat(rows);
   	//Get just the heading...
   	//headingRows = allRows.slice(0,2);
   	//Get just the data...
   	dataRows = allRows.slice(this.headerRows);
   	
   	if (this.sortStatus.orderBy == orderBy) {
   		//Reverse the current sort order to get the new sort order
   		//  if the user selected the same sort order.
   		this.sortStatus.ascending = (!this.sortStatus.ascending);
   	}
   	this.sortStatus.orderBy = orderBy;
   	this.getMagnitude.colIndex = orderBy;
   	dataRows.sort(this.getMagnitude)
   	if (this.sortStatus.ascending) {
   		//render data in ascending order
   	} else {
   		dataRows.reverse();
   	}
   	//It seems we must copy all the data before we modify the array,
   	//  otherwise we corrupt the sorted array.
   	//var innerHTML = new Array();
   	//for (var x=0; x< dataRows.length; x++) {
   	//	innerHTML[x] = dataRows[x].innerHTML.valueOf();
   	//}
   	//this performs adjustment of the colors
   	for (var x=this.headerRows; x < allRows.length ; x++) 
   	{
   	//	aTable.rows[x].innerHTML = innerHTML[x - this.headerRows];
   		//if (aTable.tBodies!=null)
	   		aTable.insertBefore(dataRows[x-this.headerRows],aTable.rows[x]);
   		//Adjust cell color...
   		if (this.useStyle)
   		{
	   		for (var cellIndex=0; cellIndex < aTable.rows[x].cells.length; cellIndex++) 
	   		{
	   			aTable.rows[x].className=getStyleForRow(x);
	   		}
 			}
 			else
 			{
	   		for (var cellIndex=0; cellIndex < aTable.rows[x].cells.length; cellIndex++) 
	   		{
	   			aTable.rows[x].className="data-araa-box-infodata";
	   		}
 			}
   	}
   	 
}


 
 
 
 
 	