var pwOn = "";
var pwState = "";
//var COL_SORTDATE = 0;
var COL_SEVERITY = 1;
var COL_DATE = 2;
var COL_DESC = 3;

var sortableTable = new SortableTable();
sortableTable.sortStatus.orderBy = COL_DATE;
sortableTable.sortStatus.ascending = false;
sortableTable.headerRows = 0;
sortableTable.useStyle = true;
sortableTable.maxrec = true;

var	powerOn = 'powerOn';
var xmlThresholdList = 'thresholdSensorList';
var xmlDiscreteList = 'discreteSensorList';
var xmlItem = 'sensor';

var State  = {OFF : 0, ON : 1, POWERCYCLE : 2, REBOOT : 3, NMI : 4, SHUTDOWN : 5};
var pollCount = 24;
var oldState = null;

var siFuncID;

var launchType = 0;
var isKVMEnabled = false;
var bInitialLoaded = false;
var bLogLoaded = false;
var bPreviewLoaded = false;

//append to Recent Logged Events
function appendSELTableRow(table,row)
{
	var aTable = document.getElementById(table);
	if (null ==  aTable)
		return;

	var newRowIndex = aTable.rows.length;
	var tr = aTable.insertRow(newRowIndex);

	for (i = 0; i < row.length; i++) {
		cell = tr.insertCell(i);
		switch (i) {
			case 0:
			  cell.className="left";
			  break;
			case 1:
			  cell.className="contents borderbottom borderright center";
			  //cell.width = "12px";
			  break;
			case 2:
				cell.className="contents borderbottom borderright";
			  //cell.width = "70px";
				break;
			case 3:
				cell.className="contents borderbottom";
			  //cell.width = "265px";
				break;
			case 4:
			  cell.className="right";
			  break;
		}
		SELCell(cell, newRowIndex, row[i].m_value, row[i].m_align, row[i].m_type);
	}
}

function SELCell(cell, tableRowIndex, innerHTML, align, cellType)
{
	cell.vAlign='top';
		cell.NoWrap=true;

	if (align !=null) {
		cell.align=align;
	}

	if (cellType == null) {
		cellType = Cell.CONTENT;
	}

	switch (cellType) {
		case Cell.ICON:
			cell.innerHTML="<img src=" + innerHTML + ">";
			break;
		case Cell.CONTENT:
			cell.innerHTML = (innerHTML == '    ') ? '[N/A]' : innerHTML;
			break
		case Cell.BLANK :
			cell.innerHTML='<img src="images/blank.gif">';
			break;
		case Cell.HIDDEN :
			cell.innerHTML='<span style="display:none;">' + innerHTML + '</span>'
			break;
		default:
			showErrorMessage("Unknown type for cell, cell - " + celltype);
			break;
	}
}

//sort Recent Logged Events
function sortTable(orderBy) {
	sortableTable.table = document.getElementById('logTable');
	sortableTable.sortTable(orderBy);
}

function dataCallback( fieldMapping, value )
{
	if( fieldMapping.m_dataName == "pwState") {
		var unknowMsg   = jsesp_unknowMsg; //UNKNOWN
		var onMsg       = jsesp_onMsg; //ON
		var offMsg      = jsesp_offMsg; //OFF

		var display = unknowMsg;
		if( value != null) {
			//alert("value="+value);
			//alert("oldState="+oldState);
			if (value != oldState) {
				/*var obj;
				obj = document.getElementById("pwrtarget");
				obj.disabled=false;
				obj.onclick=new Function("QuickLaunch('pwrtarget');");

				obj = document.getElementById("pwrcycle");
				obj.disabled=false;
				obj.onclick=new Function("QuickLaunch('pwrcycle');");*/

				display = (State.ON == value) ? onMsg :offMsg;
				setDiv(fieldMapping.m_fieldName, display);
				oldState = value;
			}
		} else {
			setDiv(fieldMapping.m_fieldName, display);
		}

		if( pollCount-- > 0 ) {
			if (bInitialLoaded == false && bLogLoaded == false)
				showProgressPanel();
		}
	}
}

function setupLaunchTask()
{
	var quicklaunch_height=193;
	var rowheight=20;
	//display Power ON/OFF and Power cycle link
	if (top.CAN_EXE_CMDS)
	{
		//document.getElementById( "pwrtargetTR" ).style.display = '';
		//document.getElementById( "pwrcycleTR" ).style.display = '';
		//quicklaunch_height = quicklaunch_height - rowheight*2;
	}
	//else
	//	quicklaunch_height += rowheight*2;

	//display Firmware Update link
	if (top.CAN_CFG_IDRAC)
	{
		document.getElementById( "firmupdateTR" ).style.display = '';
		quicklaunch_height = quicklaunch_height - rowheight;
	}

	//display iDrac Reset Link
	if (top.CAN_CFG_IDRAC)
	{
		document.getElementById( "idracresetTR" ).style.display = '';
	}
	//else
	//	quicklaunch_height += rowheight;
	loadVmediaEnabled();
}

function convert(str)
{
	switch (str) {
	case 'normal':
		return "ok";
	case 'warning':
		return "noncritical";
	case 'critical':
		return "critical";
	default:
		return 'unknown';
	}

	return str;
}

//get Recent Logged Events
function RecentEventLog(xmlDoc)
{
	//Clear the current table...
	clearTableRows('logTable', sortableTable.headerRows);
	//Extract data from the returned XML...
	var list = getXMLValue(xmlDoc, 'RecentEventLogEntries') ;
	var SELTable = document.getElementById('logTable');

	if( list != null  && typeof list == "object" )
	{
		var item = list.getElementsByTagName('RecentEventLogEntry');
		//Process the XML Snippet row by row
		for (var i = 0; i < item.length ; i++)
		{
			// Populate the cells
			var entry = item[i];
			var row = new Array();
			var good = false;

			var num = new Number((i+1) / 1000000.);
			var numText = "" + (num.toFixed(6));    //force into a sortable text format
			//row[COL_SORTDATE] = new Cell(Cell.HIDDEN, '' , 'left');

			row[0] = new Cell(Cell.CONTENT, '' , 'left');
			//The severity numbers map to images.
			var value = getXMLValue( entry, "severity" );
			if( value == null ) { value = "Unknown"; }    //unknown
			else { good = true;}
			//value = '<img src="images/sev' + trim(value) + '.gif">';
			value = '<span class="status_' + convert((trim(value)).toLowerCase()) + '">&nbsp;</span>' + '<span class="hidden">' + trim(value) + '</span>';

			row[COL_SEVERITY] = new Cell(Cell.CONTENT, value, 'center');

			//Date/Time MMM DD HH:MM
			var value = getXMLValue( entry, "dateTime" );
			if( value == null ) { value = "  "; }  //unknown
			else { good = true;}
			if ( value == "<System Boot>") { value = "System Boot"; }

			//if ((value != "") && (value != "System Boot"))
			//	row[COL_DATE] = new Cell(Cell.CONTENT, '<span class="hidden">' + numText + '</span>' + value.substring(4,16), 'left');
			//else
				row[COL_DATE] = new Cell(Cell.CONTENT, '<span class="hidden">' + numText + '</span>' + value, 'left');

			//Description
			//var value = getXMLValue( entry, "BriefDescription" );
			var value = getXMLValue( entry, "description" );
			if( value == null ) { value = "    "; }     //unknown
			else { good = true;}

			var trim_len = log_desc_size;
			//value = value.substr(0, trim_len) + "...";
			row[COL_DESC] = new Cell(Cell.CONTENT, trim(value), 'left');

			row[4] = new Cell(Cell.CONTENT, '' , 'left');

			if (good) appendSELTableRow('logTable', row);
			//iterate...
		}
	}

	//Invert the ascending flag on refresh requests so that we preserve the
	//  current sort order.
	sortableTable.sortStatus.ascending = !sortableTable.sortStatus.ascending;
	sortTable(sortableTable.sortStatus.orderBy);

//DF370594 	iDRAC6: Recent Logged Events shows empty rows when 9 events or less displayed.
/*
		if (SELTable.rows.length < 10)
		{
			var rec = 10 - SELTable.rows.length
			for (var i=0; i < rec  ; i++)
			{
		  var row = new Array();
		  var value = '&nbsp;';
		  //row[COL_SORTDATE] = new Cell(Cell.HIDDEN, '' , 'left');
		  row[0] = new Cell(Cell.CONTENT, value , 'left');
		  row[COL_SEVERITY] = new Cell(Cell.CONTENT, value, 'center');
		  row[COL_DATE] = new Cell(Cell.CONTENT, value, 'left');
		  row[COL_DESC] = new Cell(Cell.CONTENT, value, 'left');
		  row[4] = new Cell(Cell.CONTENT, value , 'left');
					appendSELTableRow('logTable', row);
			}
		}
*/
}

function RecentWorkNotes(xmlDoc)
{
	if (xmlDoc==null)
	{
	}
	else
	{
		// assign system current time
		if(top.CAN_CLEAR_LOGS)
		{
			$('sys_current_time').innerHTML = getXMLValue(xmlDoc, 'sys_current_time') ;
		}

		var noteTable = $('noteTable');

		var bSuccess = false;
		var clearTableFromIndex = 0;
		if(top.CAN_CLEAR_LOGS)
		{
			bSuccess = noteTable.rows.length > 0;
			clearTableFromIndex = 1;
		}
		else
		{
			bSuccess = noteTable.rows.length >= 0;
			clearTableFromIndex = 0;
		}

		if(bSuccess)
		{
			clearTableRows('noteTable', clearTableFromIndex);
			//Extract data from the returned XML...
			var list = getXMLValue(xmlDoc, 'RecentWorknoteEntries') ;

			// predefine vars so they don't get recreated in a for loop... speed optimize
			var entry;
			var row;
			var good;
			var num;
			var numText;
			var value;

			if( list != null  && typeof list == "object" )
			{
				var item = list.getElementsByTagName('worknoteEntry');
				//Process the XML Snippet row by row
				for (var i = 0; i < item.length ; i++)
				{
					// Populate the cells
					entry = item[i];
					row = new Array();
					good = false;

					row[0] = new Cell(Cell.BLANK);

					value = getXMLValue( entry, "timestamp" );
					if( value == null ) { value = "  "; }  //unknown
					else { good = true;}
					row[1] = new Cell(Cell.CONTENT, trim(value), 'left');

					value = getXMLValue( entry, "Message" );
					if( value == null ) { value = "    "; }     //unknown
					else { good = true;}

					var msg = DecodeLCLMsg(value);
					var cell_summary = '<div style="word-wrap:break-word;width:260px;overflow:hidden">' + msg + '</div>';
					row[2] = new Cell(Cell.CONTENT, cell_summary, 'left');

					row[3] = new Cell(Cell.BLANK);

					if (good) appendTableRow('noteTable', row);
					//iterate...
				}
			}
		}
	}
}

function LaunchTasks(xmlDoc)
{
	var quicklaunch_height=193;
	var rowheight=20;

	//display SystemIDLed (US2600)
	var ledBlink    = getXMLValue(xmlDoc, 'lcdBlink');
	var lcdHostEventStatus = getXMLValue( xmlDoc, 'hostEventStatus');
	var lcdVisibleErrCount = getXMLValue( xmlDoc, 'lcdVisibleErrCount');
	var lcdHiddenErrCount = getXMLValue( xmlDoc, 'lcdHiddenErrCount');

	var isCmcBlade = top.aimGetBoolPropObj['platform_bool_is_blade'];
	var isCtrlVConsole = top.aimGetIntPropObj['gui_int_control_virtualConsole'];  // 0:licensed(default)

	//display Power ON/OFF and Power cycle link
	if (top.CAN_EXE_CMDS)
	{
		document.getElementById( "pwrtargetTR" ).style.display = '';
		document.getElementById( "pwrcycleTR" ).style.display = '';
		if (top.isPlasma == 1) {
			document.getElementById("pwrgraceshutTR").style.display = '';
			quicklaunch_height = quicklaunch_height - rowheight * 3;
		}
		else {
			document.getElementById("pwrgraceshutTR" ).style.display = 'none';
			quicklaunch_height = quicklaunch_height - rowheight * 2;
		}
	}
	//else
	//	quicklaunch_height += rowheight*2;

	//display Launch Viewer link

	if (getXMLValue( xmlDoc, "kvmEnabled" ) > 0)
		isKVMEnabled = true;

	if ( (top.CAN_VKVM == false && top.CAN_VMEDIA == false) ) {
		launchType = 0;
		//quicklaunch_height += rowheight;
	}

	if ((top.CAN_VKVM == false && top.CAN_VMEDIA == true)) {
		launchType = 1;
	}
	if (top.CAN_VKVM == true && isKVMEnabled) {
		launchType = 2;
	}
	else if(top.CAN_VKVM == true && top.CAN_VMEDIA == true && !isKVMEnabled) {
		launchType = 1;
	}
	if (!isKVMEnabled && top.CAN_VMEDIA == false)
	{
			//if (launchType!=0)
			//	quicklaunch_height += rowheight;
	}

		 if((isCtrlVConsole == 0) ||(isCmcBlade == "true")){ //Fix for BITS088327

		if($('consoleCfg_link').style.display == "none")
		{
			$('consoleCfg_link').style.display = "inline";
		}

		if($('refreshPrv_link').style.display == "none")
		{
			$('refreshPrv_link').style.display = "inline";
		}

		if($('remoteConLaunch_link').style.display == "none")
		{
			$('remoteConLaunch_link').style.display = "inline";
		}
		}

	//display View Life Cycle Log link
	document.getElementById( "viewlogTR" ).style.display = '';

	//US2600-Identify_On_Homepage
	//display View System ID LED link
	CreateSystemIDLED(ledBlink,lcdHostEventStatus,lcdVisibleErrCount,lcdHiddenErrCount);


	//display Firmware Update link
	if (top.CAN_CFG_IDRAC)
	{
		document.getElementById( "firmupdateTR" ).style.display = '';
		quicklaunch_height = quicklaunch_height - rowheight;
	}

	//display iDrac Reset Link
	if (top.CAN_CFG_IDRAC)
	{
		document.getElementById( "idracresetTR" ).style.display = '';
	}
	//else
	//	quicklaunch_height += rowheight;

	//Quick Launch Box height setting
	//document.getElementById( "quicklaunch" ).style.height = quicklaunch_height;
}

function leaveWorknoteTextArea(txtArea)
{
	if($(txtArea).value.length == 0)
	{
		$(txtArea).className = "empty";
		$(txtArea).value = jsesp_worknotes_desc;
		$('addNotes').focus();
	}
}

function toggleEmptyTextArea(txtArea)
{
	if ($(txtArea).hasClassName("empty"))
	{
		$(txtArea).removeClassName("empty");
		$(txtArea).value = "";
	}
}

function toggleAddNotesBtn()
{
	if($F('notes').length > 0)
	{
		if($('addNotes').hasClassName("container_button_disabled"))
		{
			$('addNotes').removeClassName("container_button_disabled");
			$('addNotes').addClassName("container_button");
		}
	}
	else
	{
		if($('addNotes').hasClassName("container_button"))
		{
			$('addNotes').removeClassName("container_button");
			$('addNotes').addClassName("container_button_disabled");
		}
	}
}

function AddWorkNotesInputRow()
{
	var noteTable = $('noteTable');

	if(noteTable.rows.length == 0)
	{
		var content = '<table><tr><td><input type="text" maxlength="255" size="80" value="' + jsesp_worknotes_desc + '" id="notes" name="notes" class="empty" onkeypress="return checkTextBoxCount(event, this,255);" onkeyup="toggleAddNotesBtn();"  onclick="toggleEmptyTextArea(this)" onblur="leaveWorknoteTextArea(this)" /></td>';
		content += '<td nowrap><a id="addNotes" class="container_button_disabled" href="javascript:AddWorknote();"><span>' + jsesp_addbutton + '</span></a></td></tr></table>';
		row = new Array();
		row[0] = new Cell(Cell.BLANK);
		row[1] = new Cell(Cell.CONTENT, '<span id="sys_current_time">', 'left');
		row[2] = new Cell(Cell.CONTENT, content, 'left');
		row[3] = new Cell(Cell.BLANK);
		appendTableRow('noteTable', row);
	}
}

function AddWorknote()
{
	if(!$('notes').hasClassName("empty"))
	{
		var notes = $F('notes');

		// prevent XSS attack.
		//notes = replaceHTMLTag(notes);
		var req = 'AddWorknote:' + encodeURIComponent(escapeStr(notes));
		document.chainedCallback = AddWorknoteCallback;
		loadXMLDocument('data?set=' + req, waitWithCallback);
	}
}

function AddWorknoteCallback(xmlDoc)
{
	$('notes').value = "";
	$('notes').className = "empty";
	$('notes').value = jsesp_worknotes_desc;

	if($('addNotes').hasClassName("container_button"))
	{
		$('addNotes').removeClassName("container_button");
		$('addNotes').addClassName("container_button_disabled");
	}

	document.chainedCallback = RecentWorkNotes;
	loadXMLDocument('data?get=GetRecentWorknotes', waitWithCallback);
}

function ServerInfo(xmlDoc)
{
	var IpAddresses = "";
	var Ipv4Enabled = false;

	var truncateNum = 230; // hard truncation value

	for( var i=0 ; i<fieldList.length ; ++i )
	{
		var dataName = fieldList[i].m_dataName;
		var paramValue = getXMLValue( xmlDoc, dataName ) ;
		var tmpIpAddr;
		//

		if( fieldList[i].m_type == FieldMapping.TYPE_CALLBACK )
			dataCallback( fieldList[i], paramValue, xmlDoc );
		else
		{
			fieldList[i].m_decoder( fieldList[i], paramValue );

			//Show IPv4 or IPv6 Address
			if (dataName == "v4Enabled")
			{
				if (paramValue != 0)
				{
					tmpIpAddr = getXMLValue( xmlDoc, "v4IPAddr" );
					IpAddresses = tmpIpAddr;
					Ipv4Enabled = true;
				}
			}

			if (dataName == "v6Enabled")
			{
				if (paramValue != 0)
				{
					//IPv6 Address1
					tmpIpAddr = getXMLValue( xmlDoc, "v6Addr" );
					if (tmpIpAddr != null && !isEmpty(tmpIpAddr) && tmpIpAddr != "::" )
					{
						if (!isEmpty(IpAddresses) && IpAddresses != "::" )
							   IpAddresses += "," ;
						IpAddresses +=  tmpIpAddr;
					}

					//Link Local Address
					tmpIpAddr = getXMLValue( xmlDoc, "v6LinkLocal" );
					if (tmpIpAddr != null && !isEmpty(tmpIpAddr) && tmpIpAddr != "::" )
					{
						if (!isEmpty(IpAddresses) && IpAddresses != "::" )
							   IpAddresses += "," ;
						IpAddresses +=  tmpIpAddr;
					}

					//IPv6 Address2
					tmpIpAddr = getXMLValue( xmlDoc, "v6SiteLocal" );
					if( tmpIpAddr != null && !isEmpty(tmpIpAddr) &&
						tmpIpAddr != "::" )
					   IpAddresses += "," + tmpIpAddr;
				}
			}

			if (IpAddresses != null)
			{
				if (!(IpAddresses.match(",::,")))
				{
					document.getElementById("IPAddr").innerHTML = IpAddresses;
				}
			}
		}
	}
	if (xmlDoc != null  && typeof xmlDoc == "object")
	{
		var DisplayValue = "";

		var xmlVal = getXMLValue( xmlDoc, "devDataCenter" );
		if (xmlVal != null)
		{
			//Datacenter: XX
			DisplayValue +=  "<span style='margin-right: 5px;'>"+jsesp_loc_Datacenter;
			DisplayValue += xmlVal.escapeHTML();
			DisplayValue += "</span>";
		}

		xmlVal = getXMLValue( xmlDoc, "devAisle" );
		if (xmlVal != null)
		{
			//Row: XX
			DisplayValue += "<span style='margin-right: 5px;'>"+jsesp_loc_Row;
			DisplayValue += xmlVal.escapeHTML();
			DisplayValue += "</span>";
		}

		xmlVal = getXMLValue( xmlDoc, "devRack" );
		if (xmlVal != null)
		{
			//Rack: XX
			DisplayValue += "<span>"+jsesp_loc_Rack;
			DisplayValue += xmlVal.escapeHTML();
			DisplayValue += "</span>";
		}

		//DisplayValue=DisplayValue.replace(/ /g,'&nbsp;');
		document.getElementById("serverLocation").innerHTML = DisplayValue;
	}
}

var bInitialPreviewCalled = false;

function refreshDataCallback(xmlDoc)
{
	var sessionArray = new Object();
	// showContentPanel();

	if (xmlDoc==null) {
		setTimeout("refreshbox(1);", 30000);// Poll every 30 seconds.
		//showErrorMessage("refreshDataCallback - No XML document.");
		//return;
	} else {
		if(top.CAN_CLEAR_LOGS) {
			var addWorknoteFunc = function() { AddWorkNotesInputRow() };
			setTimeout(addWorknoteFunc, 1);
		}

		//US2600-Identify_On_Homepage 2013/02
		var ledBlink    = getXMLValue(xmlDoc, 'lcdBlink');
		if(ledBlink != null ||  ledBlink != "") {
			//for After Firefox version
			if(browser=="Netscape") {
				//get Firefox version
				var uMatch = navigator.userAgent.match(/Firefox\/(.*)$/),
					ffVersion;
				if (uMatch && uMatch.length > 1) {
					ffVersion = uMatch[1];
				}

				if(ffVersion >=18)
					$('refresh').href="javascript:document.location.reload()";
			}
		}

		var list        = getXMLValue(xmlDoc, 'RecentEventLogEntries') ;
		var sensor      = getXMLValue(xmlDoc, 'discreteSensorList');
		var notes       = getXMLValue(xmlDoc, 'RecentWorknoteEntries') ;

		if( sensor != null && typeof sensor == "object" ) {
			pwOn = getXMLValue(xmlDoc, powerOn);

			if (pwOn == "")
				var globalStatus = "Unknown";
			else
				var globalStatus = "Normal";
		}

		pwState = getXMLValue(xmlDoc, "pwState");

		if (pwState != null && pwState != State.ON) {
			//BITS080767 Enhance
			if (Get_Cookie( 'sysidledicon' )) {
				Delete_Cookie('sysidledicon', '/', '');
				if ($("sysidledicon") != null)
					$('sysidledicon').className = "ledIcon action_help_disabled_16";
			}
		}

		//Assign the slot Number with value(devBladeSlot). slotNum is defined in launchConsole.jsesp(BITS109000)
		setBladeSlotNumber(xmlDoc);

		//Show Remote Console Preview
		if ((bInitialPreviewCalled == false)||(bPreviewLoaded)) {
			bInitialPreviewCalled = true;
			var prvFunc = function() {
				xmlDoc = xmlDoc;
				// jsesp_RemoteConsolePreview(xmlDoc);
				getExtHlthStatus();
			};
			setTimeout(prvFunc, 500);
		}

		//Show Quick Launch Tasks by user's privileges
		var ltFunc = function() { LaunchTasks(xmlDoc); };
		setTimeout(ltFunc, 500);

		//Show Server Information
		var siFunc = function() { ServerInfo(xmlDoc); };
		siFuncID = setTimeout(siFunc, 200);

		if( list != null && typeof list == "object" ) {
		   var evtFunc = function() { RecentEventLog(xmlDoc); };
		   setTimeout(evtFunc, 1);
		}

		//Show Recent Work notes
		if( notes != null && typeof notes == "object" ) {
			var noteFunc = function() { RecentWorkNotes(xmlDoc); };
			setTimeout(noteFunc, 1);
		}

		//Show Recent Event Log
		RecentEventLog(xmlDoc);

		if( pollCount-- > 0 ) {
			if (bInitialLoaded == false || bLogLoaded == false)
				setTimeout("refreshbox(1);", 200);// load immediately
			else {
				//alert('refreshDataCallback call refreshbox: ' + pollCount);
				setTimeout("refreshbox(1);", 30000);// Poll every 30 seconds.
			}
		}
	}
}

function setBladeSlotNumber(xmlDoc) {
	var xmlNode = getXMLValue(xmlDoc, "deviceLocInfo");
	if (xmlNode != null  && typeof xmlNode == "object")  {
		xmlVal = getXMLValue( xmlNode, "devBladeSlot" );
		if (xmlVal == null) xmlVal = "";
		slotNum = xmlVal;
	}
}

function loadVmediaEnabled() {
		var URI = "sysmgmt/2012/server/configgroup/iDRAC.VirtualMedia.Enable";
		var config = new Ajax.Request(URI, { method: 'get',requestHeaders: ["ST2",top.TOKEN_VALUE], onSuccess: loadVmediaEnabledResponse});
}

function loadVmediaEnabledResponse(e){
    var restObj = e.responseText.evalJSON(true);

    if ((restObj['iDRAC.VirtualMedia'].Enable != null) && (restObj['iDRAC.VirtualMedia'].Enable != undefined) && restObj['iDRAC.VirtualMedia'].Enable == 'Enabled') {
	top.vMediaEnabled = true;
    } else {
	top.vMediaEnabled = false;
    }
}


function loadHostOsName(){
	var URI = '/sysmgmt/2012/server/configgroup/system.serveros'
	var config = new Ajax.Request(URI, { method: 'get',requestHeaders: ["ST2",top.TOKEN_VALUE], onSuccess: gethostosNameResponse});
}

//BITS104251: Fix to get the copyright and registered characters in os name
//String is converted to hex in backend and converted back here
function hex2a(hexx) {
    var hex = hexx.toString(); //force conversion
    var str = '';
    for (var i = 0; i < hex.length; i += 2)
        str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
    return str;
}
function gethostosNameResponse(e){
    var restObj = e.responseText.evalJSON(true);
    if ((restObj['system.ServerOS'].OSName == null) || (restObj['system.ServerOS'].OSName == undefined))
        $('osName').innerHTML = "";
    else {
        var asciiOSname = hex2a(restObj['system.ServerOS'].OSName);
		try{
			var escapOsName = escape(asciiOSname);
			var osname = decodeURIComponent(escapOsName);
		}catch(e){
			var osname = asciiOSname;
		}
        $('osName').innerHTML = osname.escapeHTML();
    }

    if ((restObj['system.ServerOS'].HostName == null) || (restObj['system.ServerOS'].HostName == undefined))
        $('hostName').innerHTML = "";
    else
        $('hostName').innerHTML = restObj['system.ServerOS'].HostName;
}

function loadSoftwareInventory(){
	var URI = "/sysmgmt/2012/server/inventory/software";
	var config = new Ajax.Request(URI, {
		method: 'get',
		requestHeaders: ["ST2", top.TOKEN_VALUE],
		onSuccess: getSoftwareInventoryResponse,
		onFailure: loadSoftwareInventoryError
	});
}

function getSoftwareInventoryResponse(e){
	var xmlDoc = e.responseXML;
	var deviceList = xmlDoc.getElementsByTagName("Device");
	var componentID, componentIDValue, versionNodeValue;

	for (var i = 0; i < deviceList.length; i++) {
		componentID = deviceList[i].attributes.getNamedItem("componentID");
		if (componentID != undefined || componentID != null) {
			componentIDValue = componentID.nodeValue;
			versionNodeValue = deviceList[i].getElementsByTagName("Application")[0].attributes.getNamedItem("version").nodeValue;
			if (componentIDValue == 25227) { //Integrated Dell Remote Access Controller
				$("fwVersion").innerHTML = versionNodeValue;
				// fwVersionValue = versionNodeValue;
			} else if (componentIDValue == 28897) { //Lifecycle Controller
				$("LCCfwVersion").innerHTML = versionNodeValue;
			} else if (componentIDValue == 159) { //BIOS
				$("biosVer").innerHTML = versionNodeValue;
			}
		}
	}
	getFIPSMode();
}

function loadSoftwareInventoryError(e){
	console.log (top.localeObj["sys_prop_summary_software_error"]);
	$("fwVersion").innerHTML = top.localeObj["pwr_config_pwrSupp_NA"];
	$("LCCfwVersion").innerHTML = top.localeObj["pwr_config_pwrSupp_NA"];
	$("biosVer").innerHTML = top.localeObj["pwr_config_pwrSupp_NA"];
	getFIPSMode();
}

var headerArr = ["X_SYSMGMT_OPTIMIZE", "true", "ST2", top.TOKEN_VALUE];
var FIPSModeURL = "/sysmgmt/2015/server/fipsStatus";
var FIPSModeJSON = null;

function getFIPSMode()
{
	showProgressPanel();
	new Ajax.Request(FIPSModeURL, {
		method: 'get',
		requestHeaders: headerArr,
		onSuccess: onSuccessGetFIPSMode,
		onFailure: onFailureGetFIPSMode
	});
}

function onSuccessGetFIPSMode(e)
{
	var FIPS_ENABLE = 1;
	var FIPS_DISABLE = 0;
	if (e.responseText == null || e.responseText.length == 0)
		return;
	try {
		FIPSModeJSON = e.responseText.evalJSON(true);
		if (FIPSModeJSON["FIPS"] == FIPS_ENABLE) {
			$("FIPS_mode_row").style.display = "";
			$("FIPS_mode_val").innerHTML = top.localeObj["gen_enabled"];
		} else {
			$("FIPS_mode_row").style.display = "none";
		}
	} catch (e) {
		console.log("Error in parsing FIPS Mode Configuration.");
	}
}

function onFailureGetFIPSMode()
{
	console.log("Error in getting FIPS Mode.");
}

//US2600-Identify_On_Homepage
function CreateSystemIDLED(ledBlink,lcdHostEventStatus,lcdVisibleErrCount,lcdHiddenErrCount)
{
	var elem =  document.getElementById("sysidledTR"); //For display text
	var sysidledonoff = jsesp_sysidledonoff;
	var sysidled = jsesp_sysidled;
	var ledliTxt = "";	//init html

	var tdwith = "180";//For fit with Configure is 180 and without Configure is 130
	var sysidtxtstyle = "";//For text style
	var sysidledstyle = "grayLed"; //For display icon,default gray
	var sysidledset = "sysidledset"; //For alert and change value


	//independent function on sysidled.js
	sysidledstyle = getLedStatusType(ledBlink,lcdHostEventStatus,isCmc,lcdVisibleErrCount,lcdHiddenErrCount);


	//For Configure
	if(top.CAN_CFG_IDRAC)
	{
		sysidtxtstyle = "<a href='javascript:QuickLaunch(\""+sysidledset+"\");' style='margin-left:-1px;'> "+sysidledonoff+"</a>";
	}
	else
	{
		tdwith="130";
		sysidtxtstyle ="<a href='#' style='margin-left:-1px;color:#333333; text-decoration:none;cursor:text'>"+sysidled+"</a>";
	}

	//ledliTxt ="<li id='sysidledTR'>"
	ledliTxt+="  <table width='"+tdwith+"'  border='0'  cellspacing='0' cellpadding='0'>"
	ledliTxt+="    <tr style='padding:0;margin:0;line-height: 0px;'> "
	ledliTxt+="      <td  style='margin:0; padding-left:0px;' align='right' nowrap='nowrap'>"
	ledliTxt+=sysidtxtstyle
	ledliTxt+="      </td>"
	ledliTxt+="      <td style='padding:0;margin:0;' nowrap='nowrap' align='right'>"
	ledliTxt+="         <div style='margin-top:1px;padding-top:2px;overflow:auto;' id='sysidledicon' class='ledIcon "+ sysidledstyle+"'>"
	ledliTxt+="      </div></td>"
	ledliTxt+="    </tr>"
	ledliTxt+="  </table>"
	//ledliTxt+="</li>"

	elem.innerHTML = ledliTxt;
	elem.style.display = '';
	Set_Cookie( 'sysidledicon', 'ledIcon '+sysidledstyle, '', '/', '', '' );
}


function launchKVM(arg) {
	if( isKVMEnabled || (top.CAN_VMEDIA == true) ) {
		launchConsole(isKVMEnabled, arg);
	}
}

function setDataAfterPower()
{
	setTimeout("refreshbox(1)",30000);
}

//US2600-Identify_On_Homepage
function refreshDataSysIdLed()
{
	document.chainedCallback = setDataSysIdLed;
	loadXMLDocument("data?get=lcdChassisStatus", waitWithCallback);
}

//US2600-Identify_On_Homepage
function setDataSysIdLed(xmlDoc)
{
	var ledBlink    = getXMLValue(xmlDoc, 'lcdBlink');
	if (ledBlink=='1')
	{
		document.chainedCallback = processSystemIdLedRequestChange;
		loadXMLDocument("data?set=IdentifyEnable:0", waitWithCallback);
	}
	else
	{
		document.chainedCallback = processSystemIdLedRequestChange;
		loadXMLDocument("data?set=IdentifyEnable:1", waitWithCallback);
	}
}

//US2600-Identify_On_Homepage
function processSystemIdLedRequestChange()
{
	var reqFailMsg     = jsesp_reqFailMsg;
	if (xmlRequestObject.readyState == 4)
	{
		if (xmlRequestObject.status == 200 )
		{
			var xmlDoc = xmlRequestObject.responseXML;
			var reqStatus = getXMLValue( xmlDoc, 'status' );
			//It should always be 'ok', if we get error message from backend then we can do alert
			if( reqStatus != 'ok' )
			{
				var message = getXMLValue( xmlDoc, 'message' );
				if(message !=null && message !='')
				alert(reqFailMsg+" : " + message );
			}
			else
			{
				//for FF issue, Original should be true
				//self.location.reload(true);
				self.location.reload();
			}
		}
		else if( xmlRequestObject.status == 401 )
		{
			document.location = "/login.html";
		}
		else
		{
			setTimeout("refreshbox(1)",30000);
		}
	}
}

function loadDataAfterPower()
{
	//showProgressPanel();
		/*var obj;
		obj = document.getElementById("pwrtarget");
		obj.disabled=true;
		obj.onclick=new Function("return false;");

		obj = document.getElementById("pwrcycle");
		obj.disabled=true;
		obj.onclick=new Function("return fals;");*/

	if (xmlRequestObject.readyState == 4)
	{
		var reqFailMsg     = jsesp_reqFailMsg;
		var pwrCmdFailMsg  = jsesp_pwrCmdFailMsg;

		if (xmlRequestObject.status == 200 )
		{
			var xmlDoc = xmlRequestObject.responseXML;
			var pwstatus = getXMLValue(xmlDoc, "pwState");

			var reqStatus = getXMLValue( xmlDoc, 'status' );
			//alert(reqStatus);
			if( reqStatus != 'ok' )
			{
				document.chainedCallback = loadDataAfterPower;
				loadXMLDocument('data?get=pwState', waitWithCallback);
			}
			else
			{
				var state=null;

				if (pwstatus == State.OFF)
				{
					state = State.ON;
				}
				else
				{
					state = State.OFF;
				}

				if (state != null)
				{
					document.chainedCallback = setDataAfterPower;
					loadXMLDocument('data?set=pwState:' + state, waitWithCallback);
				}
			}
		}
		else if( xmlRequestObject.status == 401 )
		{
			document.location = "/login.html";
		}
		else
		{
			//  TODO: Verify this message with Dell GUI team.
			//showErrorMessage(pwrCmdFailMsg );
			//setTimeout("refreshbox(1)",30000);

			document.chainedCallback = loadDataAfterPower;
			loadXMLDocument('data?get=pwState', waitWithCallback);
		}
	}

	//loadXMLDocument('data?set=pwState:' + state, waitWithCallback);
	//setTimeout("refreshbox(1)",30000);

}

function iDracResetDummyHandle()
{
  hideElement('formArea');
  showBlockElement('ResetProgressWiz');
}

function iDracResetToDefaultDummyHandle() {
	hideElement("formArea");
	showBlockElement("ResetToDefaultProgressWiz")
}


function processPowerRequestChange()
{
	if (xmlRequestObject.readyState == 4)
	{

		var reqFailMsg     = jsesp_reqFailMsg;
		var pwrCmdFailMsg  = jsesp_pwrCmdFailMsg;

		if (xmlRequestObject.status == 200 )
		{
			var xmlDoc = xmlRequestObject.responseXML;
			var reqStatus = getXMLValue( xmlDoc, 'status' );
			if( reqStatus != 'ok' )
			{
				var message = getXMLValue( xmlDoc, 'message' );
				alert(reqFailMsg+" : " + message );
			}
			else
			{
				//  Everything went fine, reload page.
				//pollCount = 24;// Reset polling duration.
				//loadData();
				//setTimeout("refreshbox(1)",30000);
				self.location.reload(true);
			}
		}
		else if( xmlRequestObject.status == 401 )
		{
			document.location = "/login.html";
		}
		else
		{
			//  TODO: Verify this message with Dell GUI team.
			showErrorMessage(pwrCmdFailMsg );
			setTimeout("refreshbox(1)",30000);
		}
	}
}

function QuickLaunch(launchname)
{
  var submitConfirmMsg = jsesp_submitConfirmMsg;
  var resetiDRACConfirmMsg = jsesp_resetiDRACConfirmMsg;
  var afterResetiDRACMsg = jsesp_afterResetiDRACMsg;
  var resettodefaultiDRACConfirmMsg = jsesp_resettodefaultiDRACConfirmMsg;
  var afterResetToDefaultiDRACMsg = jsesp_afterResetToDefaultiDRACMsg;
  var systemidledonoffMsg = jsesp_systemidledonoffMsg;

  var unGraceShutConfirmMsg = jsesp_unGraceShutConfirmMsg;

	switch (launchname)
	{
		case 'pwrgraceshut':
		if (pwState != State.OFF) {//BITS078099 fix
			if (tconfirm(submitConfirmMsg)) {
				document.chainedCallback = processPowerRequestChange;
				loadXMLDocument('data?set=pwState:' + State.SHUTDOWN, waitWithCallback);
			}
		}//BITS078099 fix
		break;
		case 'pwrtarget':
					if (pwState == State.OFF)
					{
						//BITS078947_fix
						state = State.ON;
						if (tconfirm(submitConfirmMsg)){
							document.chainedCallback = processPowerRequestChange;
							loadXMLDocument('data?set=pwState:' + state, waitWithCallback);
						}
					}
					else
					{
						state = State.OFF;
						if ((top.isPlasma == 1 && tconfirm(unGraceShutConfirmMsg)) || (top.isPlasma == 0 && tconfirm(submitConfirmMsg))) {
							document.chainedCallback = processPowerRequestChange;
							loadXMLDocument('data?set=pwState:' + state, waitWithCallback);
						}
					}
				break;
		case 'pwrcycle':
		if (pwState != State.OFF)
				{
				if ((top.isPlasma==1 && tconfirm(unGraceShutConfirmMsg))||(top.isPlasma==0&&tconfirm(submitConfirmMsg)))
				{
					document.chainedCallback = processPowerRequestChange;
						loadXMLDocument('data?set=pwState:' + State.POWERCYCLE, waitWithCallback);
					}
				}
				break;
		case 'idracreset':
			if (top.CAN_CFG_IDRAC) {
				if (tconfirm(resetiDRACConfirmMsg))
				{
					document.chainedCallback = iDracResetDummyHandle;
					loadXMLDocument('data?set=iDracReset:1', waitWithCallback);
					//alert(afterResetiDRACMsg);
					//document.write(afterResetiDRACMsg);
				}
			} else {
				showErrorMessage(jsesp_inSufficientPriv);
			}
			break;
		case 'idracreset_shw_msg':
			// DF381944 	In firefox message of idrac resetting is missing when idrac is reset
			// This is the same as 'idracreset'.  It also show the message.
			if (top.CAN_CFG_IDRAC) {
				if (tconfirm(resetiDRACConfirmMsg))
				{
					document.chainedCallback = iDracResetDummyHandle;
					loadXMLDocument('data?set=iDracReset:1', waitWithCallback);
					document.write(afterResetiDRACMsg);
				}
			} else {
				showErrorMessage(jsesp_inSufficientPriv);
			}
			break;
		case "idracresettodefault_shw_msg":
			if (top.CAN_CFG_IDRAC && top.CAN_CFG_USER) {
				if (tconfirm(resettodefaultiDRACConfirmMsg)) {
					document.chainedCallback = iDracResetToDefaultDummyHandle;
					loadXMLDocument('data?set=iDracResetToDefault:1', waitWithCallback);
					setTimeout(function(){document.write(afterResetToDefaultiDRACMsg)},700);
				}
			} else {
				showErrorMessage(jsesp_inSufficientPriv);
			}
			break;
		case "sysidledset":
			//US2600-Identify_On_Homepage
			if (tconfirm(systemidledonoffMsg)) {
				refreshDataSysIdLed();
			}
		break;

		case 'viewer':
				launchKVM(launchType);
				break;
		case 'viewsel':
		case 'viewraclog':
				//top.parent.snb.f_getHTML(top.treelist.tbl_System.substring(4),top.treelist.snbindex_logs, '');
				top.parent.treelist.f_select(top.treelist.tbl_Logs.substring(4), '', '');
				break;
		case 'firmupdate':
				//top.parent.snb.f_getHTML(top.treelist.tbl_newupdates.substring(4),top.treelist.snbindex_newFirmwareUpdate, '');
				top.parent.treelist.f_select(top.treelist.tbl_newupdates.substring(4), '', '');
				break;
		case 'consoleCfg':
				//top.parent.snb.f_getHTML(top.treelist.tbl_System.substring(4),top.treelist.snbindex_virtualConsole, '');
				top.parent.treelist.f_select(top.treelist.tbl_VirtualConsole.substring(4), '', '');
				break;

	}
}

function SensorPage(sensorname)
{
	switch (sensorname)
	{
		case 'batteries':
				top.parent.snb.f_getHTML(top.treelist.tbl_batteries.substring(4),top.treelist.snbindex_batteries, '');
				break;
		case 'cmcstatus':
			top.parent.treelist.f_select(top.treelist.tbl_cmcstatus.substring(4),top.treelist.snbindex_cmcstatus, '');
			break;
		case 'fans':
				top.parent.snb.f_getHTML(top.treelist.tbl_fans.substring(4),top.treelist.snbindex_fans, '');
				break;
		case 'intrusion':
				top.parent.snb.f_getHTML(top.treelist.tbl_intrusion.substring(4),top.treelist.snbindex_intrusion, '');
				break;
		case 'pwrsupplies':
				top.parent.snb.f_getHTML(top.treelist.tbl_powersupplies.substring(4),top.treelist.snbindex_powersupplies, '');
				break;
		case 'removableFlashMedia':
				top.parent.snb.f_getHTML(top.treelist.tbl_rmvflashmedia.substring(4),top.treelist.snbindex_rmvflashmedia, '');
				break;
		case 'temperatures':
				top.parent.treelist.f_select(top.treelist.tbl_Powerthermal.substring(4),top.treelist.snbindex_cemTemperatures, '');
				break;
		case 'voltages':
				top.parent.snb.f_getHTML(top.treelist.tbl_Powerthermal.substring(4),top.treelist.snbindex_voltages, '');
				break;
	}
}

function linkServerHealth(linkname)
{
	switch (linkname)
	{
		case 'pwrstate':
			top.parent.snb.f_getHTML(top.treelist.tbl_Powerthermal.substring(4),top.treelist.snbindex_pwrConfig, top.treelist.lsnbindex_pwrControl);
			break;
		case 'networkadv':
			top.parent.snb.f_getHTML(top.treelist.tbl_network.substring(4),top.treelist.snbindex_network, top.treelist.lsnbindex_networkadv);
		break;
		default:
			//top.parent.snb.f_getHTML(top.treelist.tbl_System.substring(4),top.treelist.snbindex_serverProperties, top.treelist.lsnbindex_serverDetails);
			top.parent.lsnb.f_getLink(top.treelist.serverDetails_linkID);
			break;
	}
}