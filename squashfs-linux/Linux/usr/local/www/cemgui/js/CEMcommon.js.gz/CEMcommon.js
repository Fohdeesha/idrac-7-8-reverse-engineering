var maxRow = 25;
var AUTO_REFRESH_INTERVAL = 30000;
var controllerURL = '/sysmgmt/2010/storage/controller';
var enclosureURL = "/sysmgmt/2010/storage/enclosure";
var pdiskURL = '/sysmgmt/2010/storage/pdisk';
var vdiskURL = "/sysmgmt/2010/storage/vdisk";
var lcLogsURL = "/sysmgmt/2010/storage/event";
var firmareURL = "/sysmgmt/2012/server/firmware";
var scratchPadURI = "/sysmgmt/2012/server/firmware/queue";
var CSIORuri = "/sysmgmt/2012/server/attribute/LifecycleController.Embedded.1#LCAttributes.1#CollectSystemInventoryOnRestart";
var lifecycleURI = "/sysmgmt/2012/server/attribute/LifecycleController.Embedded.1#LCAttributes.1#LifecycleControllerState";
var backupRestoreURL = "/sysmgmt/2012/server/configuration";
var networkTestURL = "/sysmgmt/2012/server/network/test";
var LC_LOGURI = "/sysmgmt/2013/server/lclogs";
var healthReportURL  = "/sysmgmt/2013/server/reports/health";
var lcKey = lifecycleURI.substring(lifecycleURI.lastIndexOf("/") + 1);
var csiorKey = CSIORuri.substring(CSIORuri.lastIndexOf("/") + 1);
var osbmcURI= "/sysmgmt/2012/server/configgroup/iDRAC.OS-BMC";
var memoryURI="/sysmgmt/2012/server/memory"
var nicURI = "/sysmgmt/2012/server/configgroup/iDRAC.NIC";
var autoBackup ="/sysmgmt/2012/server/configgroup/lifecyclecontroller.lcattributes.autobackup";
var autoUpdate ="/sysmgmt/2012/server/configgroup/lifecyclecontroller.lcattributes.autoupdate";
var iDRACtimeURI = '/sysmgmt/2013/server/datetime';
var schedulerBackupURI = schedulerURI='/sysmgmt/2013/server/scheduler';
var splitFqddArr = new Array();
var Table = {
	len: '',
	trElem: '',
	tdElem: '',
	divElem: '',
	subTable: '',
	lastLSNBindex: '',
	currLSNBindex: '',
	lsnbCallBack: '',
	lastSNBindex: '',
	currSNBindex: '',
	snbCallBack: '',
	secSubTable: '',
	alertDiv: '',
	propCnt: 0,
	totalProp: 0,
	firstSet: 0,
	generateAdvTable: function(_ID, _tblBody, _basicArr, _advObj, _advTitle){
		this.len = _basicArr.length;
		this.trElem = _tblBody.insertRow(_tblBody.rows.length);
		this.trElem.id = _ID.replace(/[^\w\s]/gi, '');
		if (_advObj == null) {
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			this.tdElem.className = "left";
		}
		else {
			// Advanced properties contains 'add' icon at first row
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			this.tdElem.className = "drawer_cell borderbottom borderright center";
			this.tdElem.innerHTML = '<span  class="table_accordion_row_close" id="img_'+_ID+'" onclick="Table.spanHandler(this)">&nbsp;</span>';
			this.len = _basicArr.length - 1;
		}
		for (var i = 0; i < this.len; i++) {
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			if (String(_basicArr[i]).indexOf('status_') != -1 || String(_basicArr[i]).indexOf('action_') != -1) {
				this.tdElem.className = "contents borderbottom borderright center";
				this.tdElem.innerHTML = '<span  class="' + _basicArr[i] + '">&nbsp;</span><span class="hidden">' + _basicArr[i] + '</span>';
			}
			else {
				this.tdElem.className = "contents borderbottom borderright";
								// Checking input and br tags exists or not
				//if (String(_basicArr[i]).indexOf('<input') != -1 || String(_basicArr[i]).indexOf('<br') != -1) {
				if (String(_basicArr[i]).match(/<\/*[a-z][^>]+?>/gi)) {
					this.tdElem.innerHTML = '<span>' +_basicArr[i]+ '</span>';
				}else{
					//escapeHTML - Converts HTML special char to entity equiv written in prototype.js
					this.tdElem.innerHTML = '<span style="width:100px" >' + String(_basicArr[i]).escapeHTML() + '</span>';
				}
			}
		}
		if (_advObj == null) {
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			this.tdElem.className = "right";
		}
		else {
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			this.tdElem.className = "contents borderbottom borderright";
			this.tdElem.innerHTML = "<div><span>" + _basicArr[_basicArr.length - 1] + "</span></div><div class='container_content hide'><div class='sub_header'><span>" + _advTitle + "</span></div><table id='newTable" + _ID + "' class='infolist' ></table></div>";
			this.generateAdvList($('newTable' + _ID), _advObj);
		}


	},

	generateAdvList: function(_tbl, _advObj){
		this.propCnt = 0;
		this.totalProp = Object.keys(_advObj).length
		this.firstSet = Math.round(this.totalProp / 2);
		this.clearAdvTableData(_tbl)

		this.trElem = _tbl.insertRow(_tbl.rows.length);
		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
		this.tdElem.width = "50%";
		this.tdElem.className = "alignlefttop";
		this.tdElem.innerHTML = "<table class='infolist' id='leftTable" + _tbl.id + "'><tr><td class='top_spacer_small' colspan='2'></td></tr></table>";
		this.subTable = $('leftTable' + _tbl.id);

		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
		this.tdElem.width = "50%";
		this.tdElem.className = "alignlefttop";
		this.tdElem.innerHTML = "<table class='infolist' id='rightTable" + _tbl.id + "'><tr><td class='top_spacer_small' colspan='2'></td></tr></table>";
		this.secSubTable = $('rightTable' + _tbl.id);
		for (var k in _advObj) {
			this.propCnt++;
			if (this.totalProp < 8 || this.propCnt < this.firstSet + 1) {
				this.trElem = this.subTable.insertRow(this.subTable.rows.length);
			}
			else {
				this.trElem = this.secSubTable.insertRow(this.secSubTable.rows.length);
			}
			if (k == "view") {
				this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
				this.tdElem.className = "normal";
				this.tdElem.colSpan = "2";
				this.tdElem.innerHTML = '<span>' + _advObj[k] + '</span>';
			}
			else {
				this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
				this.tdElem.className = "item";
				this.tdElem.style.verticalAlign = "middle";
				this.tdElem.innerHTML = '<span>' + Localization.getLocaleStringForID(k) + ' </span>';
				this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
				if (k == "status") {
					this.tdElem.innerHTML = '<span  class="' + _advObj[k] + '">&nbsp;</span><span class="hidden">' + _advObj[k] + '</span>';
				}
				else {
					//check to verify valid HTML tag
					if (String(_advObj[k]).match(/<\/*[a-z][^>]+?>/gi)) {
						this.tdElem.innerHTML = '<span>' + _advObj[k] + '</span>';
					}
					else this.tdElem.innerHTML = '<span>' + String(_advObj[k]).escapeHTML() + '</span>';
				}
			}
		}

	},
	spanHandler: function(e){
		toggleTableRow(e, e.parentNode.parentNode.id, false);
	},
	clearAdvTableData: function(_tbl){
		for (var i = 0; i < _tbl.childNodes.length; i++) {
			_tbl.removeChild(_tbl.childNodes[i]);
			i = i - 1;
		}
		scroll(0, 0);
	},
	contentList: function(_tblBody, _advObj){
		this.clearContentListTable(_tblBody);
		for (var k in _advObj) {
			this.trElem = _tblBody.insertRow(_tblBody.rows.length);
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			this.tdElem.className = "item";
			this.tdElem.innerHTML = '<span>' + Localization.getLocaleStringForID(k) + ' </span>';
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
			if (k == "status") this.tdElem.innerHTML = '<span  class="' + _advObj[k] + '">&nbsp;</span><span class="hidden">' + _advObj[k] + '</span>';
			else this.tdElem.innerHTML = String(_advObj[k]).escapeHTML();
		}
		this.trElem = _tblBody.insertRow(_tblBody.rows.length);
		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
	},
	clearContentListTable: function(_tbl){
		for (var i = 0; i < _tbl.childNodes.length; i++) {
			_tbl.removeChild(_tbl.childNodes[i]);
			i = i - 1;
		}
		scroll(0, 0);
	},
	generateLSNB: function(e, _appendProp, _comp, callBackFun, _select){
		this.lsnbCallBack = callBackFun;
		var lsnbTR = top.lsnb.document.getElementById('lsnbtable').rows[0];
		var lsnbCnt = 0;
		var convFQDD;
		var selectLSNB;
		this.clearTabData(lsnbTR);
		for (var j in e) {
			this.tdElem = lsnbTR.insertCell(lsnbTR.cells.length);
			this.tdElem.className = "lsnb-text";
			this.tdElem.id = j;
			if (lsnbCnt == 0) {
				selectLSNB = j;
			}
			if (_comp == "controller") {
				this.tdElem.innerHTML = '<a onmousedown="return false;" ondrag="window.event.returnValue=false" id="c_lsnb' + lsnbCnt + '" href="#" onclick="top.da.Table.LSNBclickAction(this)" class="lsnb-text">' + Conversion.getControllerName(e[j]) + '</a>';
			}
			else {
				this.tdElem.innerHTML = '<a onmousedown="return false;" ondrag="window.event.returnValue=false" id="c_lsnb' + lsnbCnt + '" href="#" onclick="top.da.Table.LSNBclickAction(this)" class="lsnb-text">' + e[j].name.escapeHTML() + '</a>';
			}
			this.tdElem = lsnbTR.insertCell(lsnbTR.cells.length);
			this.tdElem.className = "lsnb-separator";
			this.tdElem.innerHTML = '|';
			lsnbCnt++;
		}
		if (_select == null) this.LSNBselect(selectLSNB);
		else {
			this.LSNBselect(_select);
		}
	},
	LSNBselect: function(e){
		var tableID = top.lsnb.document.getElementById('lsnbtable');
		for (var j = 0; j < tableID.childNodes[0].childNodes[0].childNodes.length; j++) {
			if (tableID.childNodes[0].childNodes[0].childNodes[j].id == e) {
				tableID.childNodes[0].childNodes[0].childNodes[j].childNodes[0].className = "lsnb-text lsnb-text-selection";
				this.lastLSNBindex = tableID.childNodes[0].childNodes[0].childNodes[j].childNodes[0].id;
				this.lsnbCallBack(e);
				break;
			}
		}

	},
	LSNBclickAction: function(_elem){
		this.currLSNBindex = _elem.id;
		top.lsnb.document.getElementById(_elem.id).className = "lsnb-text lsnb-text-selection";
		if (this.lastLSNBindex != this.currLSNBindex) {
			top.lsnb.document.getElementById(this.lastLSNBindex).className = "lsnb-text";
		}
		this.lastLSNBindex = this.currLSNBindex;
		this.lsnbCallBack(_elem.parentNode.id);
	},
	clearTabData: function(e){
		for (var i = 1; i < e.cells.length; i++) {
			e.deleteCell(i);
			i = i - 1;
		}
	},

	generateSNB: function(e, _prop, callBackFun, _select){
		var snbCnt = 0;
		var snbTR = top.snb.document.getElementById('snbtable').rows[0];
		this.snbCallBack = callBackFun;
		this.clearTabData(snbTR);
		var selectSNB;
		for (var j in e) {
			this.tdElem = snbTR.insertCell(snbTR.cells.length);
			this.tdElem.style.valign = "middle";
			this.tdElem.style.align = "center";
			this.tdElem.style.nowrap = "nowrap";
			this.tdElem.id = j;
			if (snbCnt == 0) {
				selectSNB = j;
			}

			this.tdElem.className = "tab-image";
			if (_prop == "controller") {
				this.tdElem.innerHTML = '<a id="' + e[j]['enclosures'] + '" class="tab-text" href="#" onclick="top.da.Table.SNBAction(this)">' + Conversion.getControllerName(e[j]) + '</a>&nbsp;'
				this.tdElem = snbTR.insertCell(snbTR.cells.length);
				this.tdElem.innerHTML = '<img id="img_' + e[j]['enclosures'] + '" src="images/snb_divider.png" alt="">';
			}
			snbCnt++;
		}
		if (_select == null) this.SNBselect(selectSNB);
		else {
			this.SNBselect(_select);
		}


	},
	SNBAction: function(_elem){
		this.clearTabData(top.lsnb.document.getElementById('lsnbtable').rows[0]);
		var a_elem = _elem.id;
		var img_elem = "img_" + a_elem;
		this.currSNBindex = a_elem;
		top.snb.document.getElementById(this.currSNBindex).className = "tab-text-selected";
		top.snb.document.getElementById(this.currSNBindex).parentNode.className = "tab-text first";
		top.snb.document.getElementById(img_elem).src = "images/snb_right_selected.png";
		if (this.lastSNBindex != this.currSNBindex) {
			img_elem = "img_" + this.lastSNBindex;
			top.snb.document.getElementById(this.lastSNBindex).className = "tab-text";
			top.snb.document.getElementById(this.lastSNBindex).parentNode.className = "tab-image";
			top.snb.document.getElementById(img_elem).src = "images/snb_divider.png";
		}
		this.lastSNBindex = this.currSNBindex;
		this.snbCallBack(_elem.id);
	},
	SNBselect: function(e){
		var tableID = top.snb.document.getElementById('snbtable');
		for (var j = 0; j < tableID.childNodes[0].childNodes[0].childNodes.length; j++) {
			if (tableID.childNodes[0].childNodes[0].childNodes[j].id == e) {
				tableID.childNodes[0].childNodes[0].childNodes[j].className = "tab-text first";
				tableID.childNodes[0].childNodes[0].childNodes[j].childNodes[0].className = "tab-text tab-text-selected";
				this.lastSNBindex = tableID.childNodes[0].childNodes[0].childNodes[j].childNodes[0].id;
				this.snbCallBack(tableID.childNodes[0].childNodes[0].childNodes[j].childNodes[0].id);
				break;
			}

		}
	},
	generateAdvancedNoHiddenTable:function(_id,_tblBody,_obj,_advObj,_isMsg){
		var cnt=0;
		var childCnt=0;
		_id = _id.replace(/\|/g, '');
		this.trElem = _tblBody.insertRow(_tblBody.rows.length);
		this.trElem.id="basicTable"+_id;
		if(this.propCnt%2==0){
			this.trElem.className = "fill"
		}else{
			this.trElem.className = ""
		}
		$('theadTr').cleanWhitespace();

		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
		this.tdElem.className = "left";
		this.tdElem.style.width=$('theadTr').childNodes[childCnt].style.width;

		for(var j in _obj){
			cnt++;
			childCnt++;
			this.tdElem = this.trElem.insertCell(this.trElem.cells.length);

			if(j.indexOf("icon")!=-1){
				this.tdElem.className = "contents borderbottom borderright center";
				var widthStr= $('theadTr').childNodes[childCnt].style.width;
				widthStr = widthStr.substring(0,widthStr.length-2);
				this.tdElem.style.width=(widthStr)+"px";
			}else{
				this.tdElem.className = "contents borderbottom borderright";
				this.tdElem.style.wordWrap="break-word";
					this.tdElem.style.width=$('theadTr').childNodes[childCnt].style.width;
					var widthStr= $('theadTr').childNodes[childCnt].style.width;
					widthStr = Number(widthStr.substring(0,widthStr.length-2))+4;
					this.tdElem.style.width=widthStr+"px";
			}

			this.tdElem.innerHTML = _obj[j];

		}
		this.tdElem.style.width="";
		if(this.trElem.childNodes.length < $('theadTr').childNodes.length) this.tdElem.colSpan = 2;

		this.trElem = _tblBody.insertRow(_tblBody.rows.length);
		this.trElem.id="advTable"+_id;
		if(this.propCnt%2==0){
			this.trElem.className = "fill"
		}else{
			this.trElem.className = ""
		}

		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
		this.tdElem.className = "left";
		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);

		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
		//this.tdElem.className = "borderleft borderbottom";
		this.tdElem.colSpan = cnt;
		this.tdElem.innerHTML = '<div style="margin-left: 90px"><table class="infoMsglist" id="'+_id+'_child'+'"></table></div>';
		$(_id+'_child').style.display = 'none';
		this.secSubTable = $(_id+'_child');
		this.trElem = this.secSubTable.insertRow(this.secSubTable.rows.length);
		if(_isMsg!=null && !_isMsg){
			Table.contentMsg($(_id+'_child'), _advObj,_id);
		}else{
			Table.contentList($(_id+'_child'), _advObj);
		}
		this.propCnt++;
	},contentMsg: function(_tblBody, _advObj,_id){
		this.clearContentListTable(_tblBody);
		this.trElem = _tblBody.insertRow(_tblBody.rows.length);
		this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
		this.tdElem.id = "msgContainer_"+_id;
		this.tdElem.className = "nowrap";
		this.tdElem.colSpan = "2";
		for (var k in _advObj) {
				this.trElem = _tblBody.insertRow(_tblBody.rows.length);
				this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
				if (k == "noTitle") {
					this.tdElem.colSpan = "2";
					this.tdElem.innerHTML =  _advObj[k];
				}else{
					this.trElem.style.display="block";
					this.tdElem.innerHTML = '<b><span>' + Localization.getLocaleStringForID(k) + ': </span></b>';

				}
				this.tdElem = this.trElem.insertCell(this.trElem.cells.length);
				if (k == "status")
					this.tdElem.innerHTML = '<span  class="' + _advObj[k] + '">&nbsp;</span><span class="hidden">' + _advObj[k] + '</span>';
				else {
					if (k != "noTitle") {
						this.tdElem.innerHTML = String(_advObj[k]).escapeHTML();
					}
				}
				this.trElem = _tblBody.insertRow(_tblBody.rows.length);
		}
		this.trElem = _tblBody.insertRow(_tblBody.rows.length);

		this.trElem = _tblBody.insertRow(_tblBody.rows.length);

	}
}
var Localization = {
	language: 'en',
	functionToCall: '',
	stringURL: '',
	messageURL: '',
	strObj: '',
	msgObj: '',
	strENobj: '',
	msgENobj: '',
	tmpMsgObj: new Object(),
	isUIstrLoaded: false,
	isUImsgLoaded: false,
	localENConfig: '',
	defaultMsgObj:'',//fix for DF482699
	loadLanguage: function(lang, callBack){
		this.language = lang;
		this.functionToCall = callBack;
		if(this.language=="" || this.language==null)
			lang="en";
		this.stringURL = 'locale/' + lang + '/locale_str.json'; //removing the hardcoding for lang
		this.messageURL = 'locale/' + lang + '/locale_msg.json'; //removing the hardcoding for lang
		//this.stringURL = 'locale/en/locale_str.json';
		//this.messageURL = 'locale/en/locale_msg.json';
		this.loadData(this.stringURL);
		this.loadData(this.messageURL);
	},
	loadData: function(_url){
		var localConfig = new Ajax.Request(_url, {
			method: 'get',
			onSuccess: this.onsuccess,
			onFailure: this.onfailure,
			on404: this.defaultLoad,
			on500: ErrorMessage.on500Status,
			on503: ErrorMessage.on503Status,
			on404: ErrorMessage.on404Status,
			on401: ErrorMessage.on401Status,
			on302: ErrorMessage.on302Status
		});
	},
	onfailure: function(e){
		//Default english message is shown if there is any failure on locale
		//fix for DF482699
		Localization.defaultMsgObj.id= "RAC0508";
		Localization.defaultMsgObj.Message="An unexpected error occurred."
		Localization.defaultMsgObj.ResponseAction="Wait for few minutes and refresh the page. If the problem persists, contact service provider."
		pageAlertMsg(Localization.defaultMsgObj);
		progressBar.hide();
	},
	defaultLoad: function(e){
		//if non-english files are not present, the english files are loaded
		if (Localization.language != 'en') {
			Localization.isUIstrLoaded = false;
			Localization.isUImsgLoaded = false;
			Localization.stringURL = 'locale/en/locale_str.json';
			Localization.messageURL = 'locale/en/locale_msg.json';
			Localization.loadData(Localization.stringURL);
			Localization.loadData(Localization.messageURL);
		}
	},
	onsuccess: function(e){
		validateSession(e);
		if(e.responseText == null || e.responseText.length == 0)	return;
		try {
			if (e.request.url == Localization.stringURL) {
				Localization.strObj = e.responseText.evalJSON().StringTable;
				Localization.isUIstrLoaded = true;
			}
			else {
				Localization.msgObj = e.responseText.evalJSON().StringTable;
				Localization.isUImsgLoaded = true;
			}
		}
		catch (e) {
			//Default english message is shown if there is any exception
			//fix for DF482699
			Localization.defaultMsgObj.id= "RAC0508";
			Localization.defaultMsgObj.Message="An unexpected error occurred."
			Localization.defaultMsgObj.ResponseAction="Wait for few minutes and refresh the page. If the problem persists, contact service provider."
			pageAlertMsg( Localization.defaultMsgObj);
			progressBar.hide();
		}

		if (Localization.isUIstrLoaded && Localization.isUImsgLoaded) {
			Localization.functionToCall();
		}
	},
	getLocaleStringForID: function(_id){
		if (this.strObj[_id] != null) { return this.strObj[_id]; }
		else {
			if (this.language != 'en') {
				this.localENConfig = new Ajax.Request('locale/en/locale_str.json', {
					method: 'get',
					asynchronous: false,
					on404: ErrorMessage.on404Status,
					onSuccess: function(e){
						Localization.strENobj = e.responseText.evalJSON().StringTable;
					},
					onFailure: this.onfailure
				});
				if (this.strENobj[_id] != null) {
					this.strObj[_id] = this.strENobj[_id];
				}
				else {
					this.strObj[_id] = _id;
				}
				return this.strObj[_id];
			}
			else { return _id; }
		}
	},
	getLocaleMessageForID: function(_id, _category){
		if (this.msgObj[_category][_id] != null) {
			this.msgObj[_category][_id].id = _id;//fix for DF482699
			return this.msgObj[_category][_id]
		}
		else {
			if (this.language != 'en') {
				this.localENConfig = new Ajax.Request('locale/en/locale_msg.json', {
					method: 'get',
					asynchronous: false,
					on404: ErrorMessage.on404Status,
					onSuccess: function(e){
						Localization.msgENobj = e.responseText.evalJSON().StringTable;
					},
					onFailure: this.onfailure
				});
				if (this.msgENobj[_category][_id] != null) {
					this.msgENobj[_category][_id].id = _id;//fix for DF482699
					return this.msgENobj[_category][_id];
				}
				else {
					this.tmpMsgObj.Severity = _id;
					this.tmpMsgObj.Message = _id;
					this.tmpMsgObj.ResponseAction = _id;
					this.tmpMsgObj.id = _id;//fix for DF482699
					return this.tmpMsgObj;
				}
			}
			else {
				Localization.tmpMsgObj.Severity = _id;
				Localization.tmpMsgObj.Message = _id;
				Localization.tmpMsgObj.ResponseAction = _id;
				Localization.tmpMsgObj.id = _id;//fix for DF482699
				return Localization.tmpMsgObj;
			}
		}
	},
	getLocaleNewMessageForID:function(_id){
		var localeObj = new Object();
		localeObj.id = _id;
		localeObj.Severity = 1;
		localeObj.Message = _id;
		localeObj.ResponseAction = _id;
		for(var j in this.msgObj){
			for(var i in this.msgObj[j]){
				if(i==_id){
					localeObj = this.msgObj[j][i];
					localeObj.id = _id;
					break;
				}
			}
		}
		var ll;
		return localeObj;
	}
}

var ErrorMessage = {
	on401Status: function(){
		showMessage("RAC0506");
	},
	on404Status: function(){
		showMessage("RAC0507");
	},
	on500Status: function(){
		showMessage("RAC0508");
	},
	on503Status: function(){
		showMessage("RAC0509");
	},
	on302Status: function(){
		showMessage("RAC0509");
	},
	on204Status: function(_callBckFun){
		showMessage("RAC0505");
		_callBckFun();
	}
}

function showMessage(_id,_type){
	if (inPageAlert) pageAlertMsg(Localization.getLocaleMessageForID(_id, "Storage"));//fix for DF482699
	else containerAlertMsg( Localization.getLocaleMessageForID(_id, "Storage"));//fix for DF482699
}
//Fix for CR485186
var Mappings = {
	state: function(e) {
		switch (e) {
			case 'ready':
				return [Localization.getLocaleStringForID("ready"), 1];
			case 'online':
				return [Localization.getLocaleStringForID("online"), 2];
			case 'foreign':
				return [Localization.getLocaleStringForID("foreign"), 3];
			case 'offline':
				return [Localization.getLocaleStringForID("offline"), 4];
			case 'blocked':
				return [Localization.getLocaleStringForID("blocked"), 5];
			case 'failed':
				return [Localization.getLocaleStringForID("failed"), 6];
			case 'degraded':
				return [Localization.getLocaleStringForID("degraded"), 7];
			case 'non_raid':
				return [Localization.getLocaleStringForID("non_raid"), 8];
			case 'missing':
				return [Localization.getLocaleStringForID("missing"), 9];
			case 'removed':
				return [Localization.getLocaleStringForID("removed"), 9];
			case 'charging':
				return [Localization.getLocaleStringForID("charging"), 10];
			case 'learning':
				return [Localization.getLocaleStringForID("learning"), 11];
			case 'low_power':
				return [Localization.getLocaleStringForID("low_power"), 12];
			case 'read_only':
				return [Localization.getLocaleStringForID("read_only"), 15]; //For PCIeSSD
			default:
				return [Localization.getLocaleStringForID("unknown"), 0];
		}
	}
}

var Conversion = {
	status: function(e){
		//Fix for CR485186
		switch (e) {
			case 2:
				return "status_ok";
			case 3:
				return "status_noncritical";
			case 4:
			case 5:
				return "status_critical";
			default:
				return "status_unknown";
		}
	},
	pciSlot: function(e){
		switch (String(e)) {
			case '-1':
				return Localization.getLocaleStringForID("embedded");
			default:
				return Localization.getLocaleStringForID("pci_slot") + " " + e;
		}
	},
	getControllerName:function(e){
		var fqdd = "", slotCntrlNo = "", slotNo = "", cntrlNo = "";
		var dashPos = -1, dotPos = -1;
		// console.log("e::", e);
		if (e.embedded) {
			if (e.FQDD != undefined && e.FQDD != null && e.FQDD != "") {
				fqdd = e.FQDD.toLowerCase();
				// Stash PERC Controller
				if (fqdd.indexOf("modular") != -1) {
					dotPos = fqdd.lastIndexOf(".");
					if (dotPos != -1) {
						slotCntrlNo = fqdd.slice(++dotPos);
						dashPos = slotCntrlNo.indexOf("-");
						if (dashPos != -1) {
							cntrlNo = slotCntrlNo.slice(++dashPos);
							slotNo = slotCntrlNo.slice(0, --dashPos);
						}
					}
					return (Localization.getLocaleStringForID("slot_no") +
						"-" + slotNo + ", " + e.name.escapeHTML() + " (" +
						Localization.getLocaleStringForID("controller") + " " +
						cntrlNo + ")");
				} else {
					// Embedded Controller
					return e.name.escapeHTML() + " (" +
						Localization.getLocaleStringForID("embedded") + ")";
				}
			} else {
				return e.name.escapeHTML() + " (" +
						Localization.getLocaleStringForID("embedded") + ")";
			}
		} else {
			// Controller in PCI Slot
			return e.name.escapeHTML() + " (" +
				Localization.getLocaleStringForID("pci_slot") + " " +
				e.pci_slot + ")";
		}
	},
	bytes: function(e){
		var val;
		val = e / (1024 * 1024);

		if (val >= 1024) {
			val = val / 1024;
			return (new Template(Localization.getLocaleStringForID("gb")).evaluate({
				gbStr: val.toFixed(2)
			}));
		}
		else { return (new Template(Localization.getLocaleStringForID("mb")).evaluate({
			mbStr: val.toFixed(2)
		})); }
	},
	speed: function(e){
		switch (e) {
			case 1:
				return new Template(Localization.getLocaleStringForID("gbps")).evaluate({
					gbpsStr: "1.5"
				});
			case 2:
				return new Template(Localization.getLocaleStringForID("gbps")).evaluate({
					gbpsStr: "3"
				});
			case 4:
				return new Template(Localization.getLocaleStringForID("gbps")).evaluate({
					gbpsStr: "6"
				});
			case 8:
				return new Template(Localization.getLocaleStringForID("gbps")).evaluate({
					gbpsStr: "12"
				});
			default:
				return Localization.getLocaleStringForID("info_not_available");
		}
	},
	pciespeed: function(e){
		switch (e) {
			case 16:
				return new Template(Localization.getLocaleStringForID("gtps")).evaluate({
					gtpsStr: "5"
				});
			case 32:
				return new Template(Localization.getLocaleStringForID("gtps")).evaluate({
					gtpsStr: "8"
				});
			case 64:
				return new Template(Localization.getLocaleStringForID("gtps")).evaluate({
					gtpsStr: "2.5"
				});
			default:
				return Localization.getLocaleStringForID("info_not_available");
		}
	},
	sensorStatus:function(e){
		switch (e) {
			case 2:
				return "status_ok";
			case 3:
			case 5:
			case 6:
			case 7:
				return "status_noncritical";
			case 4:
				return "status_critical";
			default:
				return "status_unknown";
		}
	},
	celsiusToFarenheit:function(e){
		if(isNaN(e)){
			return Localization.getLocaleStringForID("info_not_available");
		}
		return new Template(Localization.getLocaleStringForID("degree_c_f")).evaluate({
					degreeCenti: e,
					degreeFahren: (e*1.8+32).toFixed(1)
		});
	},
	kbtomb:function(e){
		return new Template(Localization.getLocaleStringForID("mb")).evaluate({
			mbStr: (e/1024).toFixed(2)
		});
	},
	mbtogb:function(e){
		return (new Template(Localization.getLocaleStringForID("gb")).evaluate({
			gbStr: (e/1024).toFixed(2)
		}));
	},
	bytesToSize:function(bytes){
		var sizes = ['bytes', 'kb', 'mb', 'gb'];
		if (bytes==null || typeof(bytes)=="string"||bytes == 0) return Localization.getLocaleStringForID("info_not_available");
		var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
		var  resultStr=  (bytes / Math.pow(1024, i))
		if(i>0)resultStr = resultStr.toFixed(2);
		return (new Template(Localization.getLocaleStringForID(sizes[i])).evaluate({
			result: resultStr
		}));
	}
}

Array.prototype.sortMultiple = function(l){
	var cmp = function(a, b, l){
		var p = l.shift();
		var c = a[p];
		var d = b[p];
		return (c < d) ? -1 : (c > d) ? 1 : (l.length) ? cmp(a, b, l) : 0;
	};
	this.sort(function(a, b){
		return cmp(a, b, l.split(","));
	});
};

Array.prototype.findAndRemove = function(_arr){
	for (var i = 0; i < this.length; i++) {
		for (var j = 0; j < _arr.length; j++) {
			if (this[i] == _arr[j]) {
				this.splice(i, 1);
				i = i - 1;
			}
		}
	}
	return this;
};

Array.prototype.count = function(val){
	var count = 0;
	for (var i = 0; i < this.length; i++) {
		if (this[i] == val) {
			count++;
		}
	}
	return count;
}

Array.prototype.random = function(){
	var r = [];
	var t = this.length;
	for (var i = 0; i < t; r[i++] = this.splice(Math.floor(Math.random() * this.length), 1))
		;
	for (var j = 0; j < t; j++)
		this[j] = r[j];
	return this;
}

function strFromFQDD(_fqdd, _pos){
	splitFqddArr = _fqdd.split(":");
	return splitFqddArr[_pos];
}

function objLength(_this){
	var x = 0;
	for (var i in _this) {
		x++;
	}
	return x;
}

function addProgressBarControl(){
	document.write('<div id="progressPage"><div class="progressBackground"></div><div class="progressContainer"><div id="progressGraphic"></div></div></div>');
}

function pageAlertMsg(msgObj){
	progressBar.hide();
	var alertType = "";
	var txt = '';
	var icon = '';
	var title='';
	//Fix for DF487759, changed Severity check with Integer to avoid l10n issue
	switch (msgObj.Severity) {
		case 3:
			alertType = icon = "info";
			title = Localization.getLocaleStringForID("informational");
			break;
		case 2:
			alertType = "nc";
			icon = "non-critical";
			title = Localization.getLocaleStringForID("system_alert");
			break;
		case 1:
			alertType = "c";
			icon = "critical";
			title = Localization.getLocaleStringForID("system_alert");
			break;
	}
	txt.toLowerCase()
	txt += '<div class="table_container" id="alertPaging_id"><div class="container">';
	txt += '<div class="' + alertType + '_container_top_right">';
	txt += '<div class="' + alertType + '_container_top_left">';
	txt += '<div class="' + alertType + '_container_gradient">';
	txt += '<div class="alert_container_title">' + Localization.getLocaleStringForID(title) + '</div></div></div></div>';
	txt += '<div class="' + alertType + '_container_right">';
	txt += '<div class="' + alertType + '_container_left"><div class="alert_container_content"><table><tr>';
	txt += '<td class="' + icon + '"></td>';
	if(msgObj.ResponseAction==null)msgObj.ResponseAction='';
	txt += '<td class="alert_info">' + msgObj.id+": "+msgObj.Message  + ' ' + msgObj.ResponseAction + '</td></tr></table></div></div></div>';//fix for DF482699
	txt += '<div class="' + alertType + '_container_bottom_right">';
	txt += '<div class="' + alertType + '_container_bottom_left">';
	txt += '<div class="' + alertType + '_container_bottom"></div></div></div></div></div>';
	$('alertContent').style.display = '';
	$('alertContent').innerHTML = txt;
}

function containerAlertMsg(msgObj){
	$('dataarea').style.visibility = 'visible';
	progressBar.hide();
	var txt = '';
	var icon='';
	//Fix for DF487759, changed Severity check with Integer to avoid l10n issue
	switch (msgObj.Severity) {
		case 3:
			icon = "action_info_16";
			break;
		case 2:
			icon = "status_noncritical";
			break;
		case 1:
			icon = "status_critical";
			break;
	}
	txt += '<span class="' + icon + '">&nbsp</span>';
	txt += '&nbsp<span style="font-size:12px">' +msgObj.id+": "+msgObj.Message + '</span>';//fix for DF482699
	if(msgObj.ResponseAction!=null)txt += '&nbsp&nbsp<span style="font-size:12px">' + msgObj.ResponseAction + '</span>';//fix for DF482699
	inPageAlertContainer.parentNode.parentNode.style.display = '';
	inPageAlertContainer.innerHTML = txt;
}

var AlertPaging = {
	show: function(){
		$('alertPaging_id').style.display = "";
	},
	hide: function(){
		$('alertPaging_id').style.display = "none";
	}
}




var Chart = {
	colorArr: ["#4d7c2e","#e1af1d","#ce7203","#99351c","#8e4893","#56286f","#213c7c","#6f8ea4","#7d7469"],
	pie: function(_dataArr, _labelArr){
		var seriesArr = new Array();
		for (var i = 0; i < _dataArr.length; i++) {
			seriesArr.push({
				label: _labelArr[i],
				color: this.colorArr[i],
				data: _dataArr[i],
				xaxis: 1,
				yaxis: 1
			})
		}
		return seriesArr;
	}
}

function jumpToPage(page){
	for (var i = 0; i < parent.treelist.data.length; i++) {
		if (parent.treelist.data[i][3] == page) {
			parent.treelist.f_select(parent.treelist.data[i][0], parent.treelist.data[i][1], parent.treelist.data[i][2]);
		}
	}
}

function filterPendingObj(e){
	var obj = new Object();
	for (var j in e) {
		if (j.indexOf('|C|') != -1) {
			obj[j] = e[j];
		}
	}
	return obj;
}

function filterAvailableObj(e){
	var obj = new Object();
	for (var j in e) {
		if ((j.indexOf('|C|') != -1) && e[j].state!=9) {
			obj[j] = e[j];
		}
	}
	return obj;
}
function splitCurrentObj(e){
	return e.split("|C|")[1];
}

function getObjFromKey(_arr, _result){
	for (var j in _arr) {
		if (j.indexOf(_result) != -1) { return _arr[j]; }
	}
}

function getKeyWithCurrentObj(_arr, _result){
	for (var j in _arr) {
		if (j.indexOf(_result) != -1) { return j; }
	}
}

Array.prototype.getDisplayString = function(_val){
	for (var i = 0; i < this.length; i++) {
		if (this[i][1] == _val) { return (this[i][0]); }
	}
	return Localization.getLocaleStringForID("info_not_available");
}

function validateSession(e){
	if (e.getResponseHeader("Content-Type") == "text/html") {
		// var isIE11 = !!navigator.userAgent.match(/Trident\/7\./);//BITS153566
		// if (navigator.appName == "Microsoft Internet Explorer" || isIE11) {
		top.document.location.href = "/start.html";
		// } else {
		// 	document.open();
		// 	document.write(e.responseText);
		// 	document.close();
		// }
	}
}


function getKeyFromURI(_URI, _value){
	if(_URI.indexOf(_value)!=-1)
	return (_URI.split(_value + "/")[1]);
	else
	return "";
}

var Range = {
	controller:["X_SYSMGMT_OPTIMIZE", "true", "X_SYSMGMT_RANGE", "name,pci_slot,embedded,raid_object_hide"]
}


//Fix for DF518670 - Multiple Session logout
var RESTrequest = Class.create(Ajax.Request, {
	initialize: function($super, url, options) {
		if(options.requestHeaders==null){
			options.requestHeaders = new Array();
		}
		options.requestHeaders.push(top.TOKEN_NAME);
		options.requestHeaders.push(top.TOKEN_VALUE);
		var c = Object.clone(options);
		options.onSuccess = function(transport){
		if(transport.responseJSON && transport.request.url.indexOf(".json") == -1) {
			transport.responseText = transport.responseText.escapeHTML();
			//console.log(transport.request.url + ":"+transport.responseText);
		}
		c.onSuccess(transport);
		}
		$super(url,options);
	}
});

//Code to change the state of the tree
function CheckTop(){
	if ( top.document.location.href.search('index') < 0 ){
		top.document.location.href = "/start.html";
		return false;
	}
	return true;
}

function UpdateHelpIdAndState(str_HelpId, b_UpdateState){
	if (! CheckTop())
		return;
	if (b_UpdateState == true)
		top.treelist.f_updateState(self.document.location.search);
}

function isProductLicensed(){
	if(top.savedProdDesc.indexOf('Basic')!=-1 || top.savedProdDesc.indexOf('Express')!=-1){
		return false
	}
	return true;
}

//modalDialogHide in a common place. //Added as part of BITS052929
function modalDialogHide(modalDiv, modalContainer,_isRedirect) {
	var modalpage = $(modalDiv);
	var modalgraphic = $(modalContainer);
	if (modalpage != null && modalgraphic != null) {
		modalpage.style.display = "none";
		addEvent.remove(window, "scroll", function () { modalDialog.setModalGraphic(modalContainer); });
		addEvent.remove(window, "resize", function () { modalDialog.setModalGraphic(modalContainer); });
		}
}

//Scheduler functions
function selectedTab(e,_type){

	 if (e == "default") {
		$('defaultTabDiv').style.display = "";
		$('schedulerDiv').style.display = "none";
		$('defaultTab_id').className = "tab_button_emphasized";
		$('schedulerTab_id').className = "tab_button";
		if (_type == "autoupdate") {
			$('btnUpload').style.display = "";
			$('updateDetailsTbl_id').style.display = '';
		}
		else {
			$('defaultApplyBtn').style.display = "";
			schedulerURI = schedulerBackupURI;
		}

		$('clearSetBtn').style.display = "none";
		$('schApplyBtn').style.display = "none";
	}
	else {
		$('defaultTabDiv').style.display = "none";
		$('schedulerDiv').style.display = "";
		$('defaultTab_id').className = "tab_button";
		$('schedulerTab_id').className = "tab_button_emphasized";
		if (_type == "autoupdate") {
			$('btnUpload').style.display = "none";
			$('updateDetailsTbl_id').style.display='none'
		}
		else
			$('defaultApplyBtn').style.display = "none";

		$('clearSetBtn').style.display = "";
		$('schApplyBtn').style.display = "";
		_schedulerType = _type;
		Scheduler.getState(_type);

	}
	//disableAllScheduler();

}

function disableAllScheduler(){
	//$('enableSchedulerChkBox').disabled = "disabled";
	$('sNetwork').disabled = "disabled";
	$('sVflash').disabled = "disabled";
	$('sFileName').disabled = "disabled";
	$('sBackupPharse').disabled = "disabled";
	$('sConfirmPharse').disabled = "disabled";
	$('sIpAddress').disabled = "disabled";
	$('sProtocol').disabled = "disabled";
	$('sShareName').disabled = "disabled";
	$('sDomainName').disabled = "disabled";
	$('sUserName').disabled = "disabled";
	$('sPassword').disabled = "disabled";
	$('sLnkTestConnection').className = "disabled";
	$('shour').disabled = "disabled";
	$('recurDailyChkBox').disabled = "disabled";
	$('smin').disabled = "disabled";
	$('dailyTI').disabled = "disabled";
	$('recurWeekChkBox').disabled = "disabled";
	$('recurMonRadio').disabled = "disabled";
	$('schApplyBtn').className = "container_button_disabled";
	$('clearSetBtn').className = "container_button_disabled";
	$('smaxNum').disabled = "disabled";
	//
	var inputFields = $('monthlyDetailsRow1').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
		inputFields.each(function(inputField){
			inputField.disabled = true;
		});

	var inputFields = $('monthlyDetailsRow2').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
		inputFields.each(function(inputField){
			inputField.disabled = true;
		});
	$('sMonth').disabled = true;
	$('sMonthWeek').disabled = true;
	$('weEveryTI').disabled = true;
	var inputFields = $('weeklyDetailsRow2').select('input[type=checkbox]');
		inputFields.each(function(inputField){
			inputField.disabled = true;
		});

	var inputFields = $('weeklyDetailsRow3').select('input[type=checkbox]');
		inputFields.each(function(inputField){
			inputField.disabled = true;
		});


}

function enableAllScheduler(){
	$('sNetwork').disabled = "";
	$('sVflash').disabled = "";
	$('sFileName').disabled = "";
	$('sBackupPharse').disabled = "";
	$('sConfirmPharse').disabled = "";
	$('sIpAddress').disabled = "";
	$('sProtocol').disabled = "";
	$('sShareName').disabled = "";
	$('sDomainName').disabled = "";
	$('sUserName').disabled = "";
	$('sPassword').disabled = "";
	$('sLnkTestConnection').className = "";
	$('shour').disabled = "";
	$('recurDailyChkBox').disabled = "";
	$('smin').disabled = "";
	$('dailyTI').disabled = "";
	$('recurWeekChkBox').disabled = "";
	$('recurMonRadio').disabled = "";
	$('schApplyBtn').className = "container_button";
	$('clearSetBtn').className = "container_button";
	$('smaxNum').disabled = "";
	//
	var inputFields = $('monthlyDetailsRow1').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
		inputFields.each(function(inputField){
			inputField.disabled = false;
		});

	var inputFields = $('monthlyDetailsRow2').select('input[type=text]', 'input[type=password]', 'input[type=radio]');
		inputFields.each(function(inputField){
			inputField.disabled = false;
		});
	$('sMonth').disabled = false;
	$('sMonthWeek').disabled = false;
	$('weEveryTI').disabled = false;
	var inputFields = $('weeklyDetailsRow2').select('input[type=checkbox]');
		inputFields.each(function(inputField){
			inputField.disabled = false;
		});

	var inputFields = $('weeklyDetailsRow3').select('input[type=checkbox]');
		inputFields.each(function(inputField){
			inputField.disabled = false;
		});
	Scheduler.disableFields()
}


function recurrenceRadioSel(e)
	{
		Scheduler.recurrencePattern = e;
		if(e=="daily"){
			$('dailyDetails').style.display="";
			$('weeklyDetailsRow1').style.display="none";
			$('weeklyDetailsRow2').style.display="none";
			$('weeklyDetailsRow3').style.display="none";
			$('monthlyDetailsRow1').style.display="none";
			$('monthlyDetailsRow2').style.display="none";
			//$('rangeRecurNoEndRadio').disabled="disabled";
			//$('rangeRecurEndRadio').disabled="disabled";
			//$('rangeRepeatTI').disabled="disabled";
			//$('rangeOfRecTD').style.display="none";

		}else if(e=="weekly"){
			$('dailyDetails').style.display="none";
			$('weeklyDetailsRow1').style.display="";
			$('weeklyDetailsRow2').style.display="";
			$('weeklyDetailsRow3').style.display="";
			$('monthlyDetailsRow1').style.display="none";
			$('monthlyDetailsRow2').style.display="none";
			//$('rangeRecurNoEndRadio').disabled="";
			//$('rangeRecurEndRadio').disabled="";
			//$('rangeRepeatTI').disabled="";
			//$('rangeOfRecTD').style.display="";

		}else{
			$('dailyDetails').style.display="none";
			$('weeklyDetailsRow1').style.display="none";
			$('weeklyDetailsRow2').style.display="none";
			$('weeklyDetailsRow3').style.display="none";
			$('monthlyDetailsRow1').style.display="";
			$('monthlyDetailsRow2').style.display="";
			//$('rangeRecurNoEndRadio').disabled="";
			//$('rangeRecurEndRadio').disabled="";
			//$('rangeRepeatTI').disabled="";
			//$('rangeOfRecTD').style.display="";

		}
	}


var Scheduler = {
	_schedulerType:'',
	clearSet:false,
	isEnableDisable:false,
	recurrencePattern:'daily',
	isclearSetSel:false,
	enableDisableChkBox:function(e){
		if (!($(e).checked)) {
			disableAllScheduler();
		}
		else {
			enableAllScheduler();
		}
		this.setEnableDisableSch($(e).checked);
	},
	getState:function(e){
		progressBar.show(true);
		this.clearAllDay();
		if(_schedulerType=="autobackup")
			URL = autoBackup;
		else
			URL = autoUpdate;
		_param = '';
		_methodType = 'get';
		loadRESTdata();
	},
	changeStateChkBox:function(_state){
		this.getRecuJobSch();
		if (_state.toLowerCase() == "enabled") {
			$('enableSchedulerChkBox').checked = true;
			enableAllScheduler();
		}
		else {
			$('enableSchedulerChkBox').checked = false;
			disableAllScheduler();
			progressBar.hide();
		}
	},
	setEnableDisableSch:function(e){
		this.isEnableDisable = true;
		progressBar.show(true);
		URL  = schedulerBackupURI;
		var selectedState = (e)?"Enable":"Disable";
		_param = '{"action":"'+selectedState+'","jobtype":"'+_schedulerType+'"}';
		_methodType = 'put';
		this.isclearSetSel =false;
		loadRESTdata();
	},
	getiDRACtime:function(){
		URL  = iDRACtimeURI;
		_param = '';
		_methodType = 'get';
		loadRESTdata();
	},
	getRecuJobSch:function(){
		schedulerURI = schedulerBackupURI+'?jobtype='+_schedulerType;
		URL  = schedulerURI;
		_param = '';
		_methodType = 'get';
		loadRESTdata();
	},
	setExistSch:function(e){
		this.getiDRACtime();

		$('sFileName').value = (e.imagename!=null&&e.imagename.length!=0)?e.imagename:'';
		$('sIpAddress').value = (e.hostname!=null&&e.hostname.length!=0)?e.hostname:'';
		$('sShareName').value = (e.sharename!=null&&e.sharename.length!=0)?e.sharename:'';
		$('sDomainName').value = (e.domain!=null&&e.domain.length!=0)?e.domain:'';
		$('shour').value = (e.time).split(":")[0];
		$('smin').value = (e.time).split(":")[1];
		$('sUserName').value =(e.username!=null&&e.username.length!=0)?e.username:'';

		if(e.username==null &&  e.imagename==null){
			$('sVflash').checked = "checked"

		}else
			$('sNetwork').checked = "checked";
		Scheduler.disableFields();
		for(var i=0;i<$('sProtocol').options.length;i++){
			if($('sProtocol').options[i].value==e.sharetype){
				$('sProtocol').selectedIndex=i;
				$('sProtocol').onchange();
				break;
			}
		}

		$('smaxNum').value = (e.maxnumberofbackuparchives!=null&&e.maxnumberofbackuparchives.length!=0)?e.maxnumberofbackuparchives:'';
		if(e.dayofmonth=="*" && e.weekofmonth=="*" && e.dayofweek=="*" ){
			recurrenceRadioSel('daily');
			$('recurDailyChkBox').checked = "checked";
			$('dailyTI').value=e.repeat;
		}else if(e.dayofmonth=="*" && e.weekofmonth=="*" && e.dayofweek.length>2 ){
			recurrenceRadioSel('weekly');
			$('weEveryTI').value = e.repeat;
			$('recurWeekChkBox').checked = "checked";
			var daySel = e.dayofweek.split(",");
			for(var i=0;i<daySel.length;i++){
				var dayName= daySel[i].toLowerCase();
								$(dayName).checked=true;
			}
		}else if(e.dayofmonth!="*" && e.weekofmonth=="*" && e.dayofweek=="*" ){
			recurrenceRadioSel('monthly');
			$('recurMonRadio').checked = "checked";
			$('domRadio').checked="checked";
			$('dayOfMonthTI').value = e.dayofmonth;
			$('repeatMonth1TI').value = e.repeat;
		}else if(e.weekofmonth!="*" && e.dayofweek!="*" && e.dayofmonth=="*" ){
			recurrenceRadioSel('monthly');
			$('recurMonRadio').checked = "checked";
			$('domLRadio').checked="checked";
			for(var i=0;i<$('sMonth').options.length;i++){
				if(e.weekofmonth==$('sMonth').options[i].value){
					$('sMonth').selectedIndex = i;
					break;
				}
			}
			for(var i=0;i<$('sMonthWeek').options.length;i++){
				if(e.dayofweek==$('sMonthWeek').options[i].value){
					$('sMonthWeek').selectedIndex = i;
					break;
				}
			}
			$('repeatMonth2TI').value = e.repeat;
		}

		if($('enableSchedulerChkBox').checked == false){
			disableAllScheduler();
		}
	},
	disableFields:function(e){
		var flag = $('sVflash').checked;
		var inputFields = $('sNetworkSettings').select('input[type=text]', 'input[type=password]');
		inputFields.each(function(inputField){
			if(inputField.id=="weEveryTI" || inputField.id=="dayOfMonthTI"|| inputField.id=="shour"|| inputField.id=="smin"|| inputField.id=="repeatMonth1TI"|| inputField.id=="repeatMonth2TI"|| inputField.id=="dailyTI"){
			}else
				inputField.disabled = flag;
		});
		 if (flag) {
			$('sLnkTestConnection').addClassName('disabled');
			$('sLnkTestConnection').href = "javascript:void(0);";
			$('smaxNum').value = 1;
		}
		else {
			$('sLnkTestConnection').removeClassName('disabled');
			$('sLnkTestConnection').href = "javascript:Scheduler.testNtrkConnection();"
		}

		$('sProtocol').selectedIndex = 0;
		$('sProtocol').disabled=flag;
		$('sFileName').disabled=flag;
		$('smaxNum').disabled=flag;

	},
	applySchedule:function(){
	   var _bodyTxt='{"jobtype":"autobackup",'
		if($('sNetwork').checked){
			_bodyTxt+='"maxnumberofbackuparchives":"'+$('smaxNum').value+'",'
			if($('sFileName').value.length!=0) _bodyTxt+='"imagename":"'+$('sFileName').value+'",'
			if($('sUserName').value.length!=0){
				//Fix for BITS182388
				if($('sUserName').value.trim().indexOf("/")!=-1)
					_bodyTxt+='"username":"'+$('sUserName').value.trim().replace(/\//g,'\\\\')+'",'
				else
					_bodyTxt+='"username":"'+$('sUserName').value.trim().replace(/\\/g,'\\\\')+'",'
			}
			if($('sPassword').value.length!=0) _bodyTxt+='"password":"'+$('sPassword').value+'",'
			if($('sIpAddress').value.length!=0)_bodyTxt+='"hostname":"'+$('sIpAddress').value+'",'
			if($('sShareName').value.length!=0)_bodyTxt+='"sharename":"'+$('sShareName').value+'",'
			if($('sDomainName').value.length!=0) _bodyTxt+='"domain":"'+$('sDomainName').value+'",'
			if($('sBackupPharse').value.length!=0)_bodyTxt+='"passphrase":"'+$('sBackupPharse').value+'",'
		}    else{
			_bodyTxt+='"maxnumberofbackuparchives":"1",'
		}

			if(Scheduler.recurrencePattern=="daily"){
				_bodyTxt+='"repeat":"'+$('dailyTI').value+'",'
				 _bodyTxt+='"dayofmonth":"*",'
				_bodyTxt+='"weekofmonth":"*",'
				_bodyTxt+='"dayofweek":"*",'
			}else if (Scheduler.recurrencePattern == "weekly") {
				_bodyTxt+='"dayofmonth":"*",'
				_bodyTxt+='"weekofmonth":"*",'
				_bodyTxt+='"repeat":"'+$('weEveryTI').value+'",'
				var dayTmp = '';
				if($('sun').checked==true)dayTmp += "sun,";
				if($('mon').checked==true)dayTmp += "mon,";
				if($('tue').checked==true)dayTmp += "tue,";
				if($('wed').checked==true)dayTmp += "wed,";
				if($('thu').checked==true)dayTmp += "thu,";
				if($('fri').checked==true)dayTmp += "fri,";
				if($('sat').checked==true)dayTmp += "sat,";
				dayTmp= dayTmp.substring(0,dayTmp.length-1);
				_bodyTxt += '"dayofweek":"'+dayTmp+'",';
			}
			else {
				if ($('domRadio').checked) {
					_bodyTxt += '"dayofmonth":"' + $('dayOfMonthTI').value + '",';
					_bodyTxt += '"repeat":"' + $('repeatMonth1TI').value + '",';
					_bodyTxt += '"weekofmonth":"*",'
					_bodyTxt += '"dayofweek":"*",'
				}
				else {
					_bodyTxt += '"weekofmonth":"'+$('sMonth').options[$('sMonth').selectedIndex].value+'",';
					_bodyTxt += '"dayofweek":"'+$('sMonthWeek').options[$('sMonthWeek').selectedIndex].value+'",';
					_bodyTxt += '"repeat":"' + $('repeatMonth2TI').value + '",';
					_bodyTxt+='"dayofmonth":"*",'

				}


			}
			if(!($('sVflash').checked))
			{
				_bodyTxt+='"sharetype":"'+$('sProtocol').value+'",'
			}else
				 _bodyTxt+='"sharetype":"vflash",'

			_bodyTxt+='"time":"'+Scheduler.addZeroMin($('shour').value)+':'+Scheduler.addZeroMin($('smin').value)+ '"'
			_bodyTxt+='}'
			URL  = schedulerURI;
			_param = _bodyTxt;
			_methodType = 'post';
			loadRESTdata();

		//TODO - add range
		/*if(Scheduler.recurrencePattern=="daily" && $('dailyDaysTI').value < 367){

		}else{
			loadRESTdata();
		}*/

	},
	clearSettings:function()
	{
		if ($('schApplyBtn').className == "container_button_disabled") {
			return;
		}
		if(!this.validateField()){
			return;
		}
		progressBar.show(true);
		var _bodyTxt='{"action":"clear","jobtype":"autobackup"}'
		URL  = schedulerURI;
		_param = _bodyTxt;
		_methodType = 'put';
		if(this.isclearSetSel==false)this.clearSet=true;
		// BITS194934

		/*if (csiorState == "0") {
			progressBar.hide();
			$('modalDialogError').className = "warning_modal";
			$('error_icon').className="non-critical";
			var msgObj = Localization.getLocaleNewMessageForID('RAC0604');
			modalError(msgObj.id + ": " + msgObj.Message + " " + msgObj.ResponseAction);
		}
		else */
		if (lcState == "0") {
			progressBar.hide();
			$('modalDialogError').className = "error_modal";
			$('error_icon').className="critical";
			var msgObj = Localization.getLocaleNewMessageForID('BIOS010');
			modalError(msgObj.id + ": " + msgObj.Message + " " + msgObj.ResponseAction);
		}else
		loadRESTdata();

	},
	enableSettings:function()
	{
		progressBar.show(true);
		var _bodyTxt='{"action":"enable","jobtype":"autobackup"}'
		URL  = schedulerURI;
		_param = _bodyTxt;
		_methodType = 'put';
		this.clearSet=false;
		loadRESTdata();
	},
	testNtrkConnection:function(){
		progressBar.show(true);
		_methodType = 'get';
		var testconn_username = $('sDomainName').value == "" ? ($('sUserName').value.trim().replace(/\//g,'\\')) : $('sUserName').value.trim();
		var bodyMsg = "username="+testconn_username;
		bodyMsg += "&password="+($('sPassword').value.trim());
		bodyMsg += "&domain_name="+($('sDomainName').value.trim());
		bodyMsg += "&ipaddress="+($('sIpAddress').value.trim());
		bodyMsg += "&sharename="+($('sShareName').value.trim());

		if($('sProtocol').value=="cifs")bodyMsg += "&accesstype=2";
		else bodyMsg += "&accesstype=0"
		testAppendURI = networkTestURL + "/share?"+bodyMsg;
		URL = testAppendURI;
		loadRESTdata();
	},
	clearAllDay:function(){
		$('sun').checked=false;
		$('mon').checked=false;
		$('tue').checked=false;
		$('wed').checked=false;
		$('thu').checked=false;
		$('fri').checked=false;
		$('sat').checked=false;
	},
	clearJobAndFields:function(){
		if ($('clearSetBtn').className == "container_button_disabled") {
			return;
		}
		this.clearAllDay();
		this.isclearSetSel = true;
		$('enableSchedulerChkBox').checked=false;


		var inputFields = $('sFileSettings').select('input[type=text]', 'input[type=password]');
		inputFields.each(function(inputField){
			inputField.value = '';
		});

		var inputFields = $('sNetworkSettings').select('input[type=text]', 'input[type=password]');
		inputFields.each(function(inputField){
			inputField.value = '';
		});
		$('sProtocol').selectedIndex=0;
		$('sMonth').selectedIndex=0;
		$('sMonthWeek').selectedIndex=0;
		$('shour').value='';
		$('smin').value='';

		var inputFields = $('recSetDiv').select('input[type=text]');
		inputFields.each(function(inputField){
			inputField.value = '';
		});
		$('domRadio').checked = "checked";
		$('sNetwork').checked = "checked";
		$('recurDailyChkBox').checked = "checked";
		recurrenceRadioSel('daily');
		this.clearSettings();
		//if(Scheduler.isclearSetSel==true)Scheduler.isclearSetSel =false;
		disableAllScheduler();

	},
	validateField:function(){

		if(this.isclearSetSel){
			return true;
		}
		if (!$('sBackupPharse').disabled&&($('sBackupPharse').value != $('sConfirmPharse').value)) {
			var msgObj = Localization.getLocaleNewMessageForID('RAC0610');
			modalError(msgObj.id + ": " + msgObj.Message + " " + msgObj.ResponseAction);
			return false;
		}

		if($('sNetwork').checked && $('sProtocol').selectedIndex==0 && ($('sUserName').value.length==0||$('sPassword').value.length==0||$('sIpAddress').value.length==0||$('sShareName').value.length==0) ){
			var msgObj = Localization.getLocaleNewMessageForID('LC023');
			modalError(msgObj.id + ": " + msgObj.Message + " " + msgObj.ResponseAction);
			return false;
		}

		if($('sNetwork').checked && $('sProtocol').selectedIndex==1 && ($('sIpAddress').value.length==0||$('sShareName').value.length==0) ){
			var msgObj = Localization.getLocaleNewMessageForID('LC023');
			modalError(msgObj.id + ": " + msgObj.Message + " " + msgObj.ResponseAction);
			return false;
		}

		if (Scheduler.recurrencePattern == "weekly") {
			if(($('sun').checked==false) && ($('mon').checked==false) && ($('tue').checked==false) && ($('wed').checked==false) && ($('thu').checked==false) && ($('fri').checked==false) && ($('sat').checked==false)) {
				var msgObj = Localization.getLocaleNewMessageForID('RAC0646');
				modalError(msgObj.id + ": " + msgObj.Message + " " + msgObj.ResponseAction);
				return false;
			}
		}
		if(parseInt($('dailyTI').value) < 1 || parseInt($('dailyTI').value) > 366) {
			var msgObj = Localization.getLocaleNewMessageForID('RAC0645');
			$('modalDialogError').className = "error_modal";
			$('error_icon').className="critical";
			modalError(msgObj.id + ":"+ msgObj.Message+""+msgObj.ResponseAction);
			return false;
		}
		return true
	},
	addZeroMin:function(e){
		if(e.length==1){
			return "0"+e;
		}
		return e;
	}

}

function isNumberKey(evt)
{
 var charCode = (evt.which) ? evt.which : evt.keyCode
 //allow backspace,Alpahbets, L & l for Schedulers
 if (charCode!=108 && charCode!=8 && charCode!=76 && charCode > 31 && (charCode < 48 || charCode > 57))
	return false;

 return true;
}

//Fix for BITS184106
function isNavKey(evt)
{
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if(charCode == 37 || charCode == 39 || charCode == 46) {
		return true;
	} else {
		return false;
	}
}

function NewpageAlertMsg(msgObj,_param){
	progressBar.hide();
	var alertType = "";
	var txt = '';
	var icon = '';
	var title='';
	var linkname,show;
	var redirect_to_JobQueue = '<a href="#" onclick="redirectToJobqueue(this);return false">'+Localization.getLocaleStringForID("job_queue")+'</a>';

	switch (msgObj.Severity) {
		case 3:
			alertType = icon = "info";
			title = Localization.getLocaleStringForID("informational");
			break;
		case 2:
			alertType = "nc";
			icon = "non-critical";
			title = Localization.getLocaleStringForID("system_alert");
			break;
		case 1:
			alertType = "c";
			icon = "critical";
			title = Localization.getLocaleStringForID("system_alert");
			break;
		}
		txt.toLowerCase();
		if(_param == 2)
			txt += '<div class="table_container" id="alertPaging_id_2"><div class="container">';
		else
			txt += '<div class="table_container" id="alertPaging_id"><div class="container">';
		txt += '<div class="' + alertType + '_container_top_right">';
		txt += '<div class="' + alertType + '_container_top_left">';
		txt += '<div class="' + alertType + '_container_gradient">';
		txt += '<div class="alert_container_title">' + Localization.getLocaleStringForID(title) + '</div></div></div></div>';
		txt += '<div class="' + alertType + '_container_right">';
		txt += '<div class="' + alertType + '_container_left"><div class="alert_container_content"><table><tr>';
		txt += '<td class="' + icon + '"></td>';
		if(msgObj.ResponseAction==null)msgObj.ResponseAction='';

		if((msgObj.id == "RAC0659") && (_param != null)&&(_param != '')){
			var myTemplate1 = new Template(msgObj.Message);
			var myTemplate2 = new Template(msgObj.ResponseAction);
			var show1 = {AdapterName: _param};
			var show2 = {job_queue: redirect_to_JobQueue};
			txt += '<td class="alert_info" id="td_alert_info">' + msgObj.id+": "+myTemplate1.evaluate(show1)  + ' ' +'<br />'+myTemplate2.evaluate(show2)  + ' ' +'</td></tr></table></div></div></div>';
		}
		else if(msgObj.id == "RAC0513"){
			var myTemplate = new Template(msgObj.ResponseAction);
			linkname = '<a href="javascript:redirectToCreateVD(this);">'+Localization.getLocaleStringForID("create_virtualdisk")+'</a>'
			show={create_virtualdisk_link:linkname};
			txt += '<td class="alert_info" id="td_alert_info">' + msgObj.id+": "+msgObj.Message  + ' ' + myTemplate.evaluate(show)+'</td></tr></table></div></div></div>';
		}else if(msgObj.id == "RAC0514"){
			var myTemplate1 = new Template(msgObj.ResponseAction);
			var show1 = {AdapterName: _param,job_queue: redirect_to_JobQueue};
			txt += '<td class="alert_info" id="td_alert_info">' + msgObj.id+": "+msgObj.Message + ' ' + myTemplate1.evaluate(show1)+'</td></tr></table></div></div></div>';
		}
		else if( msgObj.id == "RAC0676" || msgObj.id == "RAC0677" ){
			var msgTemplate = new Template(msgObj.ResponseAction);
			linkname = '<a href="javascript:redirectToCreateVD(this);">'+Localization.getLocaleStringForID("create_virtualdisk")+'</a>'
			show={create_virtualdisk_link:linkname};
			txt += '<td class="alert_info" id="td_alert_info">' + msgObj.id+": "+msgObj.Message  + ' ' + msgTemplate.evaluate(show) + '</td></tr></table></div></div></div>';
		}
		else if(msgObj.id == "SSLAlert"){
			txt += '<td class="alert_info" id="td_alert_info">'+ msgObj.Message+ " " + msgObj.linkname+'</td></tr></table></div></div></div>';
		}else
			txt += '<td class="alert_info" id="td_alert_info">' + msgObj.id+": "+msgObj.Message  + ' ' + msgObj.ResponseAction + '</td></tr></table></div></div></div>';

		txt += '<div class="' + alertType + '_container_bottom_right">';
		txt += '<div class="' + alertType + '_container_bottom_left">';
		txt += '<div class="' + alertType + '_container_bottom"></div></div></div></div></div>';
		if(_param == 2){
			$('secondAlertContent').style.display = '';
			$('secondAlertContent').innerHTML = txt;
		}else{
			$('alertContent').style.display = '';
			$('alertContent').innerHTML = txt;
		}
}
function redirectToJobqueue(e){
	jumpToPage("cemgui/jobqueue.html");
	parent.da.location = "jobqueue.html";
}
function redirectToCreateVD(e){
	jumpToPage("cemgui/createvirtualdisk.html");
	parent.da.location = "createvirtualdisk.html";
}
function redirectToThisPage(_linkname){
	jumpToPage("cemgui/"+_linkname);
	parent.da.location = _linkname;
}
function filterCurrentObj(e){
	var obj = new Object();
	for (var j in e) {
		if (j.indexOf('|P|') != -1) {
				obj[j] = e[j];
			}
	}
	return obj;
}
function assignDropDownData(_cb, _arr, index){
	for (var i = 0; i < _arr.length; i++) {
		_cb.options[i + index] = new Option(_arr[i][0], _arr[i][1]);
	}
}
function assignClassType(_id,_class,_startindex){
	var Node = _id;
	var val;
	val = $(Node).options.length;
	for (var i=_startindex;i<val;i++){
//		$(Node).options[i].setAttribute("class",_class);
		$(Node).options[i].className = _class;
	}
}
function convertion_BytesToGB(e){
	if (e != null) { return (Number(e) / 1073741824).toFixed(2); }
		return 0;
}
var _method,_param = null;
 function loadRESTrequest(){
   if(_method==null){
		_method='get';
	}
	if(_param==null){
		_param='';
	}
	new RESTrequest(encodeURI(URL), {
		method: _method,
		postBody: (_param),
		onSuccess: successHandler,
		onFailure: errorAction,
		on400: errorAction,
		on401: errorAction,
		on404: errorAction,
		on503: errorAction,
		on302: errorAction,
		on1223: on204Action,
		on204: on204Action,
		requestHeaders: headerArr
	});
}

 //Fix for BITS186311
 function Get_Cookie_Details( check_name ) {
	  // first we'll split this cookie up into name/value pairs
	  // note: document.cookie only returns name=value, not the other components
	  var a_all_cookies = document.cookie.split( ';' );
	  var a_temp_cookie = '';
	  var cookie_name = '';
	  var cookie_value = '';
	  var b_cookie_found = false; // set boolean t/f default f
	  for ( i = 0; i < a_all_cookies.length; i++ )
	  {
	    // now we'll split apart each name=value pair
	    a_temp_cookie = a_all_cookies[i].split( '=' );
	    // and trim left/right whitespace while we're at it
	    cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');
	    // if the extracted name matches passed check_name
	    if ( cookie_name == check_name )
	    {
	      b_cookie_found = true;
	      // we need to handle case where cookie has no value but exists (no = sign, that is):
	      if ( a_temp_cookie.length > 1 )
	      {
	        cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
	      }
	      // note that in cases where cookie is initialized but no value, null is returned
	      return cookie_value;
	      break;
	    }
	    a_temp_cookie = null;
	    cookie_name = '';
	  }
	  if ( !b_cookie_found )
	  {
	    return null;
	  }
}

 function getBrowser() {
 	if (navigator==null) {  return ""; }
    return navigator.appName;
}

//Fix for BITS188128
function isValidXMLData(xmlText)
{
	try{
	     // code for IE 10 and 9
	     if (window.ActiveXObject)
	     {
	        var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
	        xmlDoc.async = "false";
	        xmlDoc.loadXML(xmlText);

	        if(xmlDoc.parseError.errorCode!=0)
	           return false;
	     }
	     // code for Mozilla, Chrome, Opera, etc.
	     else if (window.DOMParser)
	     {
	        var parser = new DOMParser();
	        var xmlDoc = parser.parseFromString(xmlText,"text/xml");

	        if (xmlDoc.getElementsByTagName("parsererror").length>0)
	             return false;
	      }
 	 }
 	 catch(e){
 	 	//Do nothing and return true
 	 }
      return true;
  }
