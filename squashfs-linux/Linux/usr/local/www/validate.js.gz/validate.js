var helpTable = new Object();

helpTable['h_authenticate.html'] =
       'GUID-D21E96FA-13AA-4454-B774-5CD4653F776A.html';
helpTable['h_adirectory_.html'] =
       'GUID-578F80EA-3199-4A37-9004-5D9233843BF1.html';
helpTable['h_adtest1_.html'] =
       'GUID-36287F8A-069C-4B5C-AA71-98D36E1742BD.html';
helpTable['h_adtest_2.html'] =
       'GUID-BBDB6AC6-8003-4569-BB75-B35DC5F94F34.html';
helpTable['h_AdvSettings_.html'] =
       'GUID-8010FE89-09E3-49D3-B4C7-B2B096F19694.html';
helpTable['h_adWizard1_.html'] =
       'GUID-2A060FFE-5564-4541-BE27-5941B0BFDA99.html';
helpTable['h_adWizard2_.html'] =
       'GUID-36471042-1744-472C-B725-E82936AF0851.html';
helpTable['h_adWizard3_.html'] =
       'GUID-FB95BE7B-EDD0-4422-8033-3F5A56B0CB8E.html';
helpTable['h_adWizard4a_.html'] =
       'GUID-4BED27A4-48F5-4CA3-81B5-0F670E5431D1.html';
helpTable['h_adWizard4b_.html'] =
       'GUID-88E60B23-4249-4154-9358-09E4FDACD0D2.html';
helpTable['h_adWizard4_.html'] =
       'GUID-5C6F8937-4866-4878-AC13-A48FA90D7D6C.html';
helpTable['h_attachedMedia_.html'] =
       'GUID-02EC9BE8-9C55-4509-A2E0-6A0DCF03BEA1.html';
helpTable['h_batteries_.html'] =
       'GUID-49A57C0A-A953-4391-8353-BEE84188CFFA.html';
helpTable['h_certupload_.html'] =
       'GUID-F7D27DCE-B01B-4A9E-B815-59E63D16EAB6.html';
helpTable['h_cmcSummary_.html'] =
       'GUID-F92E5568-D286-4D89-B746-C4806BFFDA54.html';
helpTable['h_config_role_group_.html'] =
       'GUID-578F80EA-3199-4A37-9004-5D9233843BF1.html';
helpTable['h_configuresmartcard_.html'] =
       'GUID-59ADD306-78CD-4E16-8B94-5F07AFC73309.html';
helpTable['h_console_.html'] =
       'GUID-62708D36-4965-46D6-AEB3-371EC3341028.html';
helpTable['h_cpu_.html'] =
       'GUID-DA8C9CA5-3FFA-4A23-B055-45B536EFFAE6.html';
helpTable['h_debug_.html'] =
       'GUID-8CAA3C43-DF28-4145-BA3E-F804110C8A56.html';
helpTable['h_debugidentify_.html'] =
       'GUID-C79B5086-F707-4CF9-BB01-78FB3AD2FB60.html';
helpTable['h_dirservice_.html'] =
       'GUID-B9E63F83-561E-4E5E-ABFF-0226FD02C800.html';
helpTable['h_eventalerts_.html'] =
       'GUID-A610FA7C-467E-47FE-B5BC-9971494CCF68.html';
helpTable['h_fans_.html'] =
       'GUID-14F0B827-9897-404B-B3E9-32C2F001458D.html';
helpTable['h_firstbootdevice_.html'] =
       'GUID-4AC438C2-32E0-488D-B4BC-A5927F5BCEED.html';
helpTable['h_flash_create_.html'] =
       'GUID-5165708A-D1F3-4D53-BF6C-3217B971A5DF.html';
helpTable['h_flash_create_image_.html'] =
       'GUID-FA2BAC46-6403-45B2-A1A7-98AA23FB0F91.html';
helpTable['h_flash_download_.html'] =
       'GUID-6D1B9D39-F564-45E7-B9A1-C8278CC2AF93.html';
helpTable['h_flash_format_.html'] =
       'GUID-6A846F6A-A3E9-4939-A9B2-A176F5BF8658.html';
helpTable['h_fwupdate1.html'] =
       'GUID-61B0AF86-DBE0-4A5A-A189-C7C6DB6A8BC6.html';
helpTable['h_fwupdate2.html'] =
       'GUID-E67C8220-2E9B-4038-BD68-A6CCB7BD8174.html';
helpTable['h_fwupdate3.html'] =
       'GUID-B4B736F8-77B0-4CDF-9B27-8B09723D2CA7.html';
helpTable['h_gencert_.html'] =
       'GUID-DEF1B011-06A3-4BFB-834A-0CDDD809F612.html';
helpTable['h_genericldap_summary_.html'] =
       'GUID-B5FB286C-EFC8-4D2D-BC4F-2CD2031EDA54.html';
helpTable['h_interface_.html'] =
       'GUID-4EC4D5CF-49BB-45F1-9A41-74F02BBC8372.html';
helpTable['h_intrusion_.html'] =
       'GUID-C7FE2F98-AAEF-42E2-A3D1-771EA341BD98.html';
helpTable['h_LCD_.html'] =
       'GUID-E5F35DD5-D475-4D09-B63A-E2A64E3D658A.html';
helpTable['h_lcs_.html'] =
       'GUID-E717F912-AA62-4973-8E70-54C6FD1D9837.html';
helpTable['h_ldaprolegroup_.html'] =
       'GUID-BEB90C1F-0AA7-4FC5-8DCA-D09C063AF40C.html';
helpTable['h_ldaptest1_.html'] =
       'GUID-D2F0947D-BB64-4F5F-B939-FD2B9C19600A.html';
helpTable['h_ldaptest_2.html'] =
       'GUID-5E257454-103F-4D3A-AE43-152E90C06AD7.html';
helpTable['h_ldapWizard1_.html'] =
       'GUID-37F4780B-A044-487B-931A-5C6804077322.html';
helpTable['h_ldapWizard2_.html'] =
       'GUID-D7F3A573-AB4E-4ECA-A732-8558EC365CC1.html';
helpTable['h_ldapWizard3_.html'] =
       'GUID-65521DDC-7D5D-433C-981C-C13C159501C3.html';
helpTable['h_ledfront_.html'] =
       'GUID-07847FB2-C856-4EAD-B7BF-E041D9646A1E.html';
helpTable['h_ledmod_.html'] =
       'GUID-DA9BC5A2-D358-48CB-8C7C-CDF50A5D8F3C.html';
helpTable['h_licensing_.html'] =
       'GUID-61B540C2-BCB4-4F81-9491-F6172774ADAA.html';
helpTable['h_lifeCycLog_.html'] =
       'GUID-001C0BC5-C6BA-478E-B7A5-93EC9A1E87D0.html';
helpTable['h_LstBoot_.html'] =
       'GUID-733276E3-2253-48CE-99B2-9C5A2403E138.html';
helpTable['h_LstCrashl_.html'] =
       'GUID-E717F912-AA62-4973-8E70-54C6FD1D9837.html';
helpTable['h_managepartitions_.html'] =
       'GUID-B2021E31-2430-4020-91E0-5765C5564075.html';
helpTable['h_netconfig_.html'] =
       'GUID-B891C31C-4457-4F6E-A191-D6FAC79DA75D.html';
helpTable['h_NetSecAdv_.html'] =
       'GUID-98557629-3044-4868-B5E1-CB288739EA23.html';
helpTable['h_nic_.html'] =
       'GUID-28270A92-87DE-422A-85E1-C94808737C77.html';
helpTable['h_ntp_.html'] =
       'GUID-6B74657E-A0E3-4E30-9B84-AECED8B28FCE.html';
helpTable['h_platform_events_.html'] =
       'GUID-A610FA7C-467E-47FE-B5BC-9971494CCF68.html';
helpTable['h_power_cfg_.html'] =
       'GUID-BEB79374-DEA2-4842-BF8E-44F2B35BA674.html';
helpTable['h_power_mgmt_.html'] =
       'GUID-502DD5B8-0053-410B-A46C-B45C0EA92206.html';
helpTable['h_powersup_.html'] =
       'GUID-4D37858C-C644-4ACD-A14B-9B09A9EFD8A2.html';
helpTable['h_PwrMonitor_.html'] =
       'GUID-89AD6E09-7A6E-49AC-8108-5602201CA554.html';
helpTable['h_RACLog_.html'] =
       'h_RACLog_.html';
helpTable['h_remote_info_.html'] =
       'GUID-3494BDB3-9E7A-4449-843D-9D7DDB52D38A.html';
helpTable['h_remotesyslog_.html'] =
       'GUID-4B35614E-C640-4FAC-A822-5D219ADCD4BE.html';
helpTable['h_rmstorage_.html'] =
       'GUID-9850B2AB-99E4-46B5-98C1-8C45254E1344.html';
helpTable['h_SDcardproperties_.html'] =
       'GUID-43DDFBB7-C1A1-4060-9253-EB75E127C8B3.html';
helpTable['h_seladvopt_.html'] =
       'GUID-B94FC06C-1D67-4710-81A3-E4F0D3701A5A.html';
helpTable['h_sel_.html'] =
       'GUID-4090A592-293B-4947-B5CB-8CF89CA57425.html';
helpTable['h_SerialLAN_.html'] =
       'GUID-BF5BB984-93AE-4CFE-B7F8-B84EE4DC39EF.html';
helpTable['h_SerialPort_.html'] =
       'GUID-5A7CAC43-D418-40E1-90F9-45A93DE63330.html';
helpTable['h_Sessions_.html'] =
       'GUID-F37E6C81-9C81-458D-B2BE-3C57FD736707.html';
helpTable['h_snmp_traps_.html'] =
       'GUID-5AAD1AFF-82D7-4E34-9A42-BF6D9205F275.html';
helpTable['h_sysinfo_.html'] =
       'GUID-7FA00817-234E-4E00-A619-AA09B34E45FB.html';
helpTable['h_sysinventory_.html'] =
       'GUID-5685497A-BF40-48A2-A5B8-9C508DE2351A.html';
helpTable['h_sysLogPostCode_.html'] =
       'GUID-F69C68EA-925D-4F95-B8FC-9CC0993AC9A8.html';
helpTable['h_sysSummary_.html'] =
       'GUID-369ADAEA-6EB2-41C3-9460-1452D378FE2E.html';
helpTable['h_temps_.html'] =
       'GUID-72854B1F-4C5B-49DF-9F88-D81179E0E184.html';
helpTable['h_TermMode_.html'] =
       'GUID-7F5B3A1B-D678-4CBD-9FEC-9D256ABDC176.html';
helpTable['h_user_cfg_.html'] =
       'GUID-8F1A3A3B-3681-4369-AF81-A865B89B13A3.html';
helpTable['h_users_cfg_.html'] =
       'GUID-BE2BCFC8-DFCA-43C7-A5FA-E898565D69C7.html';
helpTable['h_users_uploadsshkey_.html'] =
       'GUID-D53FCCEE-7416-4306-B1B6-050E48262134.html';
helpTable['h_users_uploadtrustedcacert_.html'] =
       'GUID-8DE14A6E-97C5-46C6-ABCA-0119053EA0D0.html';
helpTable['h_users_uploadusercert_.html'] =
       'GUID-DCBA3E5A-3206-48B6-8204-9B10ED0E3CAD.html';
helpTable['h_users_usermainmenu_.html'] =
       'GUID-BCC44F72-869E-4E53-8F00-D832EFD502F7.html';
helpTable['h_users_viewsshkey_.html'] =
       'GUID-28AED0E3-D5A2-4D48-8907-D93BD4A5D29B.html';
helpTable['h_users_viewtrustedcacert_.html'] =
       'GUID-EF9FD0B2-EB48-4372-BF42-A495AC3117E6.html';
helpTable['h_users_viewusercert_.html'] =
       'GUID-D586D5E6-2DCB-4CA7-AEB4-060B9E3C5D50.html';
helpTable['h_viewcert_.html'] =
       'GUID-D586D5E6-2DCB-4CA7-AEB4-060B9E3C5D50.html';
helpTable['h_voltages_.html'] =
       'GUID-6F090340-39AE-4111-9902-49624C68FB87.html';
helpTable['h_Worknotes_.html'] =
       'h_Worknotes_.html';
helpTable['h_wwnMac_.html'] =
       'GUID-05C5C7AF-0DCF-4497-BF7B-1FCDEF3E607D.html';
helpTable['h_fcdev_help_.html'] =
       'GUID-FE9D73EB-8CF4-4894-BCD0-F19CC6AE0664.html';
helpTable['h_ssl_.html'] =
       'GUID-4997D2CC-21B7-42C9-9E1B-F7FD2AF9EE20.html';
helpTable['h_nic_summary.html'] =
       'GUID-DA107995-3820-4011-BCC3-59FA2276DDAE.html';

function isAlphaNumWithDashAndPeriod(text)
 {
	var validchars = /^[a-zA-Z0-9-.]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isAlphaNum(text)
 {
	var validchars = /^[a-zA-Z0-9]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isAlphabetics(text)
 {
	var validchars = /^[a-zA-Z]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isValidEscapeKey(text)
{
	var validSplchars = /^[\[\]\\\^\_]*$/;

	var str = new String(text);

	if(str.length != 2)
		return false;

	if(str.slice(0,1) == "^")
	{
		if(str.slice(1) == "-")
			return false;
		if(validSplchars.test(str.slice(1)))
			return true;
		if(isAlphabetics(str.slice(1)))
			return true;
	}
	else
		return false;

	if(isthishex(str) || isthisOctal(str))
		return false;
	if(isNumeric(str))
		return false;

	return false;

}

function isAlphaNumWithDash(text)
 {
	var validchars = /^[a-zA-Z0-9-]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isAlphaNumSymbols(text)
{

	var validchars = /^[a-zA-Z0-9 \/\=\-\_\+\~\`\!\@\#\$\%\^\&\*\(\)\{\}\[\]\|\\\;\:\"\'\<\>\,\.\?]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function firstAlphaNumChar(text)
{
	var validchars = /^[a-zA-Z0-9]*$/;
	if( validchars.test(text.substring(0,1)))
	{
		return true;
	}
	return false;
}

function isValidPwd(text)
{
	var validchars = /^[a-zA-Z0-9 \/\=\-\_\+\~\`\!\@\#\$\%\^\&\*\(\)\{\}\[\]\|\\\;\:\"\'\<\>\,\.\?\§]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isValidIPMIPwd(text)
{
	var validchars = /^[a-zA-Z0-9 \/\=\-\_\+\~\`\!\@\#\$\%\^\&\*\(\)\{\}\[\]\|\;\:\"\'\<\>\,\.\?\§]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isValidRFSPwd(text)
{
	var validchars = /^[a-zA-Z0-9 \/\=\-\_\+\~\`\!\@\#\$\%\^\&\*\(\)\{\}\[\]\|\\\;\:\.\?\§]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}
// Checks to make sure that text does not contain forward slash and at sign
function isValidForUserName(text)
{
	var validchars = /^[a-zA-Z0-9 \=\-\_\+\!\#\$\%\^\&\*\(\)\{\}\[\]\|\;\:\<\>\,\?\§]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

// Checks to make sure that the text does not begin or end with spaces
function startsEndsWithSpace(text)
{
	// cannot start or end with a space.
	if(/^ /.test(text) || / $/.test(text))
	{
		return true;
	}
	return false;
}

function ltrim ( s )
{
	return s.replace( /^\s*/, "" );
}
function rtrim ( s )
{
	return s.replace( /\s*$/, "" );
}
//Combine the rtrim() and ltrim() functions to make the trim() function, which just wraps both calls together:
function trim ( s )
{
	return rtrim(ltrim(s));
}

//Check for numeric values only
function isNumeric(val)
{
    if ((val == null) || (val == "") || (val == undefined)) return false;

	var validchars = /^[0-9]*$/;
	if( validchars.test(val))
	{
		return true;
	}
	return false;
}

//Check for HEX values only
function isvalidhex(val)
{
    if ((val == null) || (val == "") || (val == undefined)) return false;

	var validchars = /^[0-9ABCDEFabcdef]*$/;
	if( validchars.test(val))
	{
		return true;
	}
	return false;
}

function isthishex(val)
{
    if ((val == null) || (val == "") || (val == undefined)) return false;

	bIsValid = true;

	if((val.slice(0,2) == "0x") || (val.slice(0,2) == "0X"))
	{
		if(!isvalidhex(val.slice(2)))
			bIsValid = false;
	}
	else
	{
	//	if(!isvalidhex(val))
			bIsValid = false;
	}
	return bIsValid;
}

function isthisOctal(val)
{
    if ((val == null) || (val == "") || (val == undefined)) return false;

	var validchars = /^[0-7]*$/;
	//octal format starts with a zero, followed by at least one digit (0 to 7).   DF483039
	if(val.length <= 1 )
		return false;

	if(val.slice(0,1) != "0")
		return false;

	if( !validchars.test(val))
		return false;

	return true;
}

function convertOctToDec(val)
{
    if (!isthisOctal(val)) return 0;

	var octval = 0;
	octval = parseInt(val, 8);
	return octval;
}

function convertOctToDecString(val)
{
	if (typeof val == "number") { val = val + "";} // insure a string going forward
	var octval = convertOctToDec(val);
    return octval +"";	// Return a string instead of an integer type
}


function convertHexToDec(val)
{
    if ((val == null) || (val == "") || (val == undefined)) return 0;

	var decimalval = 0;
	if((val.slice(0,2) == "0x") || (val.slice(0,2) == "0X"))
		hexval = val.slice(2);
	decimalval = parseInt(hexval, 16);
	return decimalval;
}

function convertHexToDecString(val)
{
	if (typeof val == "number") { val = val + "";} // insure a string going forward
	var decimalval = convertHexToDec(val);
	return decimalval +"";	// Return a string instead of an integer type
}

//Check for valid number range
function isValidNumRange(userVal, minVal, maxVal)
{
	var bIsValid = true;
	var decimalval, validVal, minV, maxV;
        minV = parseInt(minVal);
        maxV = parseInt(maxVal);

	if (typeof userVal == "number") { userVal = userVal + "";} // insure a string going forward

	if(isNumeric(userVal))
	{
            validVal = parseInt(userVal, 10);//make sure we parse the string into base-10 number
            if ((validVal < minV) || (validVal > maxV))
            {
                bIsValid = false;
            }
	}
	else
	{
            if(isthishex(userVal))
            {
                decimalval = convertHexToDec(userVal);  //comes back as Int
                if((decimalval < minV) || (decimalval > maxV))
                {
                    bIsValid = false;
                }
            }
            else
                bIsValid = false;   //not hex or numeric
	}
	return bIsValid;
}

function Valid_Number(value, exact, min, max)
{
    var nASCII_0 = 48;
    var nASCII_9 = 57;
    if (exact != -1 && value != exact)
    	return false;
    else if (exact != -1 && value == exact)
	return true;
    if (value == null || value == "")
	return false;

    var str = new String(value);
    for (var i = 0; i <  str.length; i++)
    {
        if (str.charCodeAt(i) < nASCII_0 || str.charCodeAt(i) > nASCII_9)
            return false;
    }
    if (Math.floor(str) < Math.floor(min) || Math.floor(str) > Math.floor(max))
       return false;
    else
       return true;
}

function NonBroadCastAddr(ipaddr)
{
	var octet = ipaddr.split('.');
	if ( !ValidIPRange(ipaddr))
	{
		return false;
	}
	if ( octet[3] == 0 || octet[3] == 255 )
        {
		return false;
	}
	return true;
}

function ValidFirstOctet(ipaddr)
{
	var octet = ipaddr.split('.');
	if ( octet[0] == 127)
		return false;
	return true;
}
function Valid_IP_with_Netmask(IP_Addr,NetMask_Addr)
{
	var ip_addr_array = IP_Addr.split('.');
	var netmask_addr_array = NetMask_Addr.split('.');

	if ( (!ValidIPRange(IP_Addr)) || (!ValidIPRange(NetMask_Addr)))
	{
		return false;
	}

	var IPAddr_data = ip_addr_array[0] << 24 | ip_addr_array[1] << 16 | ip_addr_array[2] << 8 | ip_addr_array[3];
	var NetMask_data = netmask_addr_array[0] << 24 | netmask_addr_array[1] << 16 | netmask_addr_array[2] << 8 | netmask_addr_array[3];

	if (0 == (~(NetMask_data) & IPAddr_data) || (0 == ~(NetMask_data | IPAddr_data)))
	{
		return false;
	}

	return true;
}


function Valid_GatewayAddr_with_Netmask(Gateway_Addr,NetMask_Addr)
{
	var gateway_addr_array = Gateway_Addr.split('.');
	var netmask_addr_array = NetMask_Addr.split('.');

	if ( (!ValidIPRange(Gateway_Addr)) || (!ValidIPRange(NetMask_Addr)))
	{
		return false;
	}
	if (Gateway_Addr == '0.0.0.0')
		return true;

	var GatewayAddr_data = gateway_addr_array[0] << 24 | gateway_addr_array[1] << 16 | gateway_addr_array[2] << 8 | gateway_addr_array[3];
	var NetMask_data = netmask_addr_array[0] << 24 | netmask_addr_array[1] << 16 | netmask_addr_array[2] << 8 | netmask_addr_array[3];

	if (0 == (~(NetMask_data) & GatewayAddr_data) || (0 == ~(NetMask_data | GatewayAddr_data)))
	{
		return false;
	}

	return true;
}

function Valid_IPV4(str,min_firstOctet,max_firstOctet,min,max,b_ZerosAllowed)
{
	var nASCII_0 = 48;
	var nASCII_9 = 57;
	var nASCII_dot = 46;
	var curNumber = "";
	var iCount = 0;
	var jCount = 0;
	var limitedMask = 255;

	if (str.length == 0 || str == "")
		return false;

	if ((b_ZerosAllowed == true) && (str == '0.0.0.0'))
		return true;

	if (!ValidFirstOctet(str))
		return false;

//	if (!NonBroadCastAddr(str))
//		return false;

	if (str == '255.255.255.255')
		return false;

	for (var i = 0; i < str.length; i++)
	{

		curChar = str.charCodeAt(i);
		curNum = str.charAt(i);

 		if (curChar == nASCII_dot)
		{

			iCount++;
			jCount = 0;

			if (iCount == 1)
				ret_code = Valid_Number(curNumber,-1,min_firstOctet,max_firstOctet);
			else
			        ret_code = Valid_Number(curNumber,-1,min,limitedMask);

			if (!ret_code)
			        return false;
		       curNumber = "";
		       continue;
		}
		else if (curChar >= nASCII_0 && curChar <= nASCII_9 && jCount <= 3)
		{
			jCount++;
			curNumber += curNum;
		}
		else
	        {
	   	 	return false;
	        }
	}

	ret_code = Valid_Number(curNumber,-1,min,limitedMask);
	if (!ret_code)
		return false;
	if (iCount != 3)
		return false;

	return true;
}

//Validate IP address
function ValidIPRange(ipaddr)
{
	var addrParts = ipaddr.split('.');
	var bValidIP = true;
	if ( addrParts.length == 4)
	{
		for (i=0; i < addrParts.length ; i++)
		{
			if (!isNumeric(addrParts[i]))
				bValidIP=false;
			if ((addrParts[i] < 0) || (addrParts[i] > 255))
				bValidIP=false;
		}
	}
	else
	{
		bValidIP = false;
	}
	return bValidIP;
}

function isSubnetMaskValidOctet(octet)
{
  	if(octet == 0 ||
	  octet == 128 ||
	  octet == 192 ||
	  octet == 224 ||
	  octet == 240 ||
	  octet == 248 ||
	  octet == 252 ||
	  octet == 254 )
	{
		return true;
	}
	return false;
}

// Validate Subnet Mask
// Class C 255.255.255.XXX
// Last octet MUST be valid (0,128,192,224,240,248,252,254)
// Class B: 255.255.XXX.XXX
// Third octet must be valid (0,128,192,224,240,248,252,254) and last octet must be 0
// Class A: 255.XXX.XXX.XXX
// Second octet must be valid (0,128,192,224,240,248,252,254) and remaining octets must be 0
// All others. First octet must be valid (0,128,192,224,240,248,252,254) and remaining octets must be 0
function ValidSubnetMask(ipaddr)
{
	var octet = ipaddr.split('.');
	var bValidClassC = false;
	var bValidClassB = false;
	var bValidClassA = false;
	var bValidRest = false;

	if ( !ValidIPRange(ipaddr))
	{
		return false;
	}
	if( octet[0] == 255 && octet[1] == 255 && octet[2] == 255 )
        {
		if(isSubnetMaskValidOctet(octet[3]))
			bValidClassC = true;
	}
	if( octet[0] == 255 && octet[1] == 255 && octet[3] == 0 )
        {
		if(isSubnetMaskValidOctet(octet[2]))
			bValidClassB = true;
	}
	if( octet[0] == 255 && octet[2] == 0 && octet[3] == 0 )
        {
		if(isSubnetMaskValidOctet(octet[1]))
			bValidClassA = true;
	}
	if( octet[1] == 0 && octet[2] == 0 && octet[3] == 0 )
        {
		if(isSubnetMaskValidOctet(octet[0]))
			bValidRest = true;
	}
	if( !bValidClassC && !bValidClassB && !bValidClassA && !bValidRest)
		return false;
	return true;
}

function isbracketIP(str)
{
	var isIPPattern = /^\[(\d{1,3}\.)(\d{1,3}\.)(\d{1,3}\.)(\d{1,3})\]$/;
	var match = str.match(isIPPattern);
	return match != null
		&& match[1] < 256
		&& match[2] < 256
		&& match[3] < 256
		&& match[4] < 256;
}
// Validate email address which needs at least one at symbol and optional period
function isValidEmail(str)
{
	var sErrorMsg = '';
	var at = "@"
	var dot = "."
	var lat = str.indexOf(at);
	var lstr = str.length;
	var ldot = str.indexOf(dot);
	var lastdot=str.lastIndexOf(dot);

	//BITS083202 Idrac7 Email alert configuration accept destination email address with squre brackets. Ex. user@[192.168.1.20].
	if (isbracketIP(str.substring(lat+1))) {return true;}


	// check well formed email
	if (lat == -1 || lat == 0 || lat == lstr) {return false;}	//check for missing or badly placed "@"
	if (ldot == -1 || ldot == 0 || ldot == lstr) {return false;}//check for missing or badly placed "."
	if (str.indexOf(at,(lat+1)) != -1) {return false;}			//check for multiple "@"
	if (str.substring(lat-1,lat) == dot || str.substring(lat+1,lat+2) == dot) {return false;}
	if (str.indexOf(" ") != -1) {return false;}
	if ( lastdot<lat+2 || lastdot+2>=lstr)  {return false;}		//66865
	if (!isValidDomainName(str.substring(lat+1, lstr-1))) {return false;}

	return true;
}

// checks the top location... if the url is not index it redirects to login.
function CheckTop()
{
	if ( top.document.location.href.search('index') < 0 )
	{
		top.document.location.href = "/start.html";

		return false;
	}

	return true;
}
function findInMap(strHelpId)
{
   var val = helpTable[strHelpId];
   if (val == null)
      return strHelpId;
   else
      return val;
}


// Update the helpId and State. Note that the order of update is important. First help and then state.
function UpdateHelpIdAndState(str_HelpId, b_UpdateState)
{
	if (! CheckTop())
		return;


	var sHelpId = findInMap(str_HelpId);
	if (str_HelpId.length != 0 || sHelpId != "")
		top.globalnav.helpId = sHelpId;
	if (b_UpdateState == true)
		top.treelist.f_updateState(self.document.location.search);
}
  //Domain Name Validation using RFC 1123 Rules
  function isValidDomainName(str)
  {
      var tStr = str;
      var dot = 0;
      var ext = "";
      //Check Max length 255
      if (tStr.length > 255)
              return false;

      if (isIPV4(tStr))
              return true;
      //First character is relaxed to allow either a letter or a digit
      //[The first character must not be a minus sign or period]
      if (tStr.indexOf(".")== 0 || tStr.indexOf("-")==0)
              return false;

      //The last character must not be a minus sign or period
      if (tStr.lastIndexOf(".")+1== tStr.length || tStr.lastIndexOf("-")+1==tStr.length)
              return false;
      if (!isAlphaNumWithDashAndPeriod(tStr))
              return false;
      //domain name extension should be Alphabetics only
      if (tStr.indexOf(".")  != -1)
      {
             dot = tStr.lastIndexOf(".");
             ext = tStr.substring(dot+1,tStr.length);
	     if (!isAlphabetics(ext))
	     {
		      return false;
	     }
      }

      return true;
  }


  function isValidstatciDNSDomainName(str)
  {
      var tStr = str;
      var dot = 0;
      var ext = "";
      //Check Max length 255
      if (tStr.length > 255)
              return false;

      if (isIPV4(tStr))
              return true;

      //First character is relaxed to allow either a letter or a digit
      //[The first character must not be a minus sign or period]
      if (tStr.indexOf(".")== 0 || tStr.indexOf("-")==0)
              return false;

      //The last character must not be a dashes (-).
      if (tStr.lastIndexOf("-")+1==tStr.length)
              return false;

      //The  character must  be  /^[a-zA-Z0-9-.]*$/ and last character can be a minus sign
      if (!isAlphaNumWithDashAndPeriod(tStr))
      {
          return false;
      }

      //domain name extension should be Alphabetics only
      if (tStr.indexOf(".")  != -1)
      {
             dot = tStr.lastIndexOf(".");
             ext = tStr.substring(dot+1,tStr.length);
	     if (!isAlphabetics(ext))
	     {
		      return false;
	     }
      }
      else
      {
      		if (tStr.lastIndexOf(".") ==-1)
                  return false;
      }


      return true;
  }
  function isAlphaNumWithDashPeriodUnderscoreSpace(text)
{
	var validchars = /^[a-zA-Z0-9-._ ]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
}

function isAlphaNumWithSpace(text)
{
	var validchars = /^[a-zA-Z0-9 ]*$/;
	if( validchars.test(text))
	{
		return true;
	}
	return false;
  }

function isValidHostName(value) {
   var regex = /^(?![0-9]+$)(?!.*-$)(?!-)[a-zA-Z0-9-]{1,63}$/;
   return regex.test(value);
}

function validateSession(e){
	if (e.getResponseHeader("Content-Type") == "text/html") {
		top.document.location.href = "/start.html";
	}
}
