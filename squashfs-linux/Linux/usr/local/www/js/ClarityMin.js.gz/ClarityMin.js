
﻿var addEvent={add:function(elm,evType,fn,useCapture){if(elm.addEventListener){elm.addEventListener(evType,fn,useCapture);return true;}else if(elm.attachEvent){var r=elm.attachEvent("on"+evType,fn);return r;}else{elm['on'+evType]=fn;}}};var tooltips={initialize:function(){this.XHTMLNS="http://www.w3.org/1999/xhtml";var ti;if(!document.createElement||!document.getElementsByTagName){return;}
if(!document.createElementNS){document.createElementNS=function(ns,elt){return document.createElement(elt);};}
if(!document.links){document.links=document.getElementsByTagName("a");}
for(ti=0;ti<document.links.length;ti++){var lnk=document.links[ti];if(lnk.title){lnk.setAttribute("tooltip",lnk.title);lnk.removeAttribute("title");tooltips.addEvents(lnk);}
else if(lnk.innerHTML){lnk.setAttribute("tooltip",lnk.innerHTML);lnk.removeAttribute("title");tooltips.addEvents(lnk);}}
if(!document.images){document.images=document.getElementsByTagName("img");}
for(ti=0;ti<document.images.length;ti++){var img=document.images[ti];if(img.title||img.alt){img.setAttribute("tooltip",img.alt);img.setAttribute("tooltip",img.title);img.removeAttribute("alt");img.removeAttribute("title");tooltips.addEvents(img);}}},__findPosition:function(evt){var posX,posY;if(evt.pageX){posX=evt.pageX;}
else if(evt.clientX){posX=evt.clientX+(document.documentElement.scrollLeft?document.documentElement.scrollLeft:document.body.scrollLeft);}
else{posX=0;}
if(evt.pageY){posY=evt.pageY;}
else if(evt.clientY){posY=evt.clientY+(document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop);}
else{posY=0;}
return[posX,posY];},showToolTip:function(e){if(tooltips.CURRENT_TOOL_TIP){hideToolTip(tooltips.CURRENT_TOOL_TIP);}
if(!document.getElementsByTagName){return;}
var lnk;if(window.event&&window.event.srcElement){lnk=window.event.srcElement;}else if(e&&e.target){lnk=e.target;}
if(!lnk){return;}
if(lnk.nodeName.toUpperCase()!='A'){var alnk=tooltips.__getParent(lnk,"A");if(alnk){lnk=alnk;}}
if(!alnk){if(lnk.nodeName.toUpperCase()!='IMG'){var ilnk=tooltips.__getParent(lnk,"IMG");if(ilnk){lnk=ilnk;}}}
if(!lnk){return;}
var tooltip=lnk.getAttribute("tooltip");if(tooltip!==null&&tooltip.length>0){var d=document.createElementNS(tooltips.XHTMLNS,"div");d.className="tooltip";d.innerHTML=tooltip;STD_WIDTH=10;if(tooltip.length){t=tooltip.length;}
t_pixels=t*7;if(t_pixels>STD_WIDTH){w=t_pixels;}
else{w=STD_WIDTH;}
mpos=tooltips.__findPosition(e);mx=mpos[0];my=mpos[1];d.style.left=(mx+5)+'px';d.style.top=(my+20)+'px';if(window.innerWidth&&((mx+w)>window.innerWidth)){d.style.left=(window.innerWidth-w-25)+"px";}
if(document.body.scrollWidth&&((mx+w)>document.body.scrollWidth)){d.style.left=(document.body.scrollWidth-w-25)+"px";}
document.getElementsByTagName("body")[0].appendChild(d);tooltips.CURRENT_TOOL_TIP=d;}},hideToolTip:function(e){if(!document.getElementsByTagName){return;}
if(tooltips.CURRENT_TOOL_TIP){document.getElementsByTagName("body")[0].removeChild(tooltips.CURRENT_TOOL_TIP);tooltips.CURRENT_TOOL_TIP=null;}},__getParent:function(el,pTagName){if(el===null){return null;}
else if(el.nodeType==1&&el.tagName.toLowerCase()==pTagName.toLowerCase())
{return el;}
else
{return tooltips.__getParent(el.parentNode,pTagName);}},addEvents:function(obj){addEvent.add(obj,"mouseover",tooltips.showToolTip);addEvent.add(obj,"mouseout",tooltips.hideToolTip);addEvent.add(obj,"focus",tooltips.showToolTip);addEvent.add(obj,"blur",tooltips.hideToolTip);}};var tableSort={sortTable:function(id,col,rev){this.rowClsNm="fill";this.colClsNm="topsorted";this.colClsNmDesc="topsorteddescend";if(document.ELEMENT_NODE===null){document.ELEMENT_NODE=1;document.TEXT_NODE=3;}
var tblEl=document.getElementById(id);if(tblEl.reverseSort===null){tblEl.reverseSort=new Array();tblEl.lastColumn=4;}
if(tblEl.reverseSort[col]===null)
{tblEl.reverseSort[col]=rev;}
if(col==tblEl.lastColumn)
{tblEl.reverseSort[col]=!tblEl.reverseSort[col];}
tblEl.lastColumn=col;var oldDsply=tblEl.style.display;tblEl.style.display="none";var tmpEl;var i,j;var minVal,minIdx;var testVal;var cmp;for(i=0;i<tblEl.rows.length-1;i++){minIdx=i;minVal=__getTextValue(tblEl.rows[i].cells[col]);for(j=i+1;j<tblEl.rows.length;j++){testVal=__getTextValue(tblEl.rows[j].cells[col]);cmp=__compareValues(minVal,testVal);if(tblEl.reverseSort[col])
{cmp=-cmp;}
if(cmp===0&&col!=1){cmp=__compareValues(getTextValue(tblEl.rows[minIdx].cells[1]),__getTextValue(tblEl.rows[j].cells[1]));}
if(cmp>0){minIdx=j;minVal=testVal;}}
if(minIdx>i){tmpEl=tblEl.removeChild(tblEl.rows[minIdx]);tblEl.insertBefore(tmpEl,tblEl.rows[i]);}}
__makePretty(tblEl,col,tblEl.reverseSort[col]);tblEl.style.display=oldDsply;return false;},__normalizeString:function(s){var whtSpEnds=new RegExp("^\\s*|\\s*$","g");var whtSpMult=new RegExp("\\s\\s+","g");s=s.replace(whtSpMult," ");s=s.replace(whtSpEnds,"");return s;},__getTextValue:function(el){var i;var s;s="";for(i=0;i<el.childNodes.length;i++){if(el.childNodes[i].nodeType==document.TEXT_NODE)
{s+=el.childNodes[i].nodeValue;}
else if(el.childNodes[i].nodeType==document.ELEMENT_NODE&&el.childNodes[i].tagName=="BR")
{s+=" ";}
else
{s+=getTextValue(el.childNodes[i]);}}
return __normalizeString(s);},__compareValues:function(v1,v2){var f1,f2;f1=parseFloat(v1);f2=parseFloat(v2);if(!isNaN(f1)&&!isNaN(f2)){v1=f1;v2=f2;}
if(v1==v2)
{return 0;}
if(v1>v2)
{return 1;}
return-1;},__makePretty:function(tblEl,col,descendingsort){var rowTest=new RegExp(rowClsNm,"gi");var colTest=new RegExp(colClsNm,"gi");var colTestDescend=new RegExp(colClsNmDesc,"gi");var i,j;var rowEl,cellEl;for(i=0;i<tblEl.rows.length;i++){rowEl=tblEl.rows[i];for(j=1;j<rowEl.cells.length-1;j++){cellEl=rowEl.cells[j];cellEl.className=cellEl.className.replace(rowTest,"");if(i%2!==0)
{cellEl.className+=" "+rowClsNm;}
cellEl.className=__normalizeString(cellEl.className);}}
var el=tblEl.parentNode.tHead;rowEl=el.rows[0];for(i=0;i<rowEl.cells.length;i++){cellEl=rowEl.cells[i];cellEl.className=cellEl.className.replace(colTest,"");cellEl.className=cellEl.className.replace(colTestDescend,"");if(i==col){if(descendingsort)
{cellEl.className+=" "+colClsNmDesc;}
else
{cellEl.className+=" "+colClsNm;}}
cellEl.className=__normalizeString(cellEl.className);}}};var tableCopy={copyAll:function(obj){var cellnum=obj.parentNode.cellIndex;var tbody=obj.parentNode.offsetParent.tBodies[0];var objtype=obj.type;var row,cell,cellitems,cellitem;for(var i=0;i<tbody.rows.length;i++){row=tbody.rows[i];cell=row.cells[cellnum];if(cell){cellitems=cell.childNodes;for(var j=0;j<cellitems.length;j++){cellitem=cellitems[j];if(cellitem.type==objtype){switch(objtype){case"checkbox":cellitem.checked=obj.checked;break;case"select-one":cellitem.value=obj.value;break;case"text":cellitem.value=obj.value;break;default:break;}}}}}},resetHeader:function(obj){var cellnum=obj.parentNode.cellIndex;var thead=obj.parentNode.offsetParent.tHead;var objtype=obj.type;var row,cell,cellitems,cellitem;for(var i=0;i<thead.rows.length;i++){row=thead.rows[i];cell=row.cells[cellnum];if(cell){cellitems=cell.childNodes;for(var j=0;j<cellitems.length;j++){cellitem=cellitems[j];if(cellitem.type==objtype){switch(objtype){case"checkbox":cellitem.checked=false;break;case"select-one":cellitem.selectedIndex=0;break;case"text":cellitem.value="";break;default:break;}}}}}}};var tableHighlight={highlightRow:function(e){this.lasthoverclass=new Array();var tds=e.getElementsByTagName("td");var classname;for(var i=0;i<tds.length;i++){if(i===0||i==tds.length-1)
{continue;}
classname=tds[i].className;lasthoverclass[i]=classname;tds[i].className='hover '+classname;}},unHighlightRow:function(e){var tds=e.getElementsByTagName("td");for(var i=0;i<tds.length;i++){if(i===0||i==tds.length-1)
{continue;}
tds[i].className=lasthoverclass[i];}}};var imageMap={initialize:function(){if(!document.getElementById||!document.createElement||!document.getElementsByTagName)
{return;}
var anni=document.getElementsByTagName('img');for(var i=0;i<anni.length;i++){if((anni[i].className.search(/\bannotated\b/)!=-1)&&(anni[i].getAttribute('usemap')!==null)){this.prepImage(anni[i]);}}},prepImage:function(img){var mapName=img.getAttribute('usemap');if(mapName.substr(0,1)=='#'){mapName=mapName.substr(1);}
var mapObjs=document.getElementsByName(mapName);if(mapObjs.length!=1){return;}
var mapObj=mapObjs[0];var areas=mapObj.getElementsByTagName('area');img.areas=[];for(var j=areas.length-1;j>=0;j--){if(areas[j].getAttribute('shape').toLowerCase()=='rect'){var coo=areas[j].getAttribute('coords').split(',');if(coo.length!=4){break;}
var a=document.createElement('a');a.associatedCoords=coo;a.style.width=(parseInt(coo[2],10)-parseInt(coo[0],10))+'px';a.style.height=(parseInt(coo[3],10)-parseInt(coo[1],10))+'px';var thisAreaPosition=this.__getAreaPosition(img,coo);a.style.left=thisAreaPosition[0]+'px';a.style.top=thisAreaPosition[1]+'px';a.className='annotation';var href=areas[j].getAttribute('href');if(href){a.href=href;}else{a.href="#";}
a.title=areas[j].getAttribute('title');var s=document.createElement('span');s.appendChild(document.createTextNode(''));a.appendChild(s);img.areas[img.areas.length]=a;document.getElementsByTagName('body')[0].appendChild(a);addEvent.add(a,"mouseover",function(){clearTimeout(imageMap.hiderTimeout);});}}
addEvent.add(img,"mouseover",imageMap.showAreas);addEvent.add(img,"mouseout",imageMap.hideAreas);},__getAreaPosition:function(img,coo){var aleft=(img.offsetLeft+parseInt(coo[0],10));var atop=(img.offsetTop+parseInt(coo[1],10));var oo=img;while(oo.offsetParent){oo=oo.offsetParent;aleft+=oo.offsetLeft;atop+=oo.offsetTop;}
return[aleft,atop];},__setAreas:function(t,disp){if(!t||!t.areas){return;}
for(var i=0;i<t.areas.length;i++){t.areas[i].style.display=disp;}},showAreas:function(e){var t=null;if(e&&e.target){t=e.target;}
if(window.event&&window.event.srcElement){t=window.event.srcElement;}
try{for(var k=0;k<t.areas.length;k++){var thisAreaPosition=aI.__getAreaPosition(t,t.areas[k].associatedCoords);t.areas[k].style.left=thisAreaPosition[0]+'px';t.areas[k].style.top=thisAreaPosition[1]+'px';}}
catch(err){}
imageMap.__setAreas(t,'block');},hideAreas:function(e){var t=null;if(e&&e.target){t=e.target;}
if(window.event&&window.event.srcElement){t=window.event.srcElement;}
clearTimeout(imageMap.hiderTimeout);imageMap.hiderTimeout=setTimeout(function(){imageMap.__setAreas(t,'none');},300);}};var pullTab={ra_resizeStart:function(e,splitter){this.dragging=true;this.rightSectionMinWidth=200;window.ra_splitter=splitter;splitter.parrentOffsetX=pullTab.ra_GetX(splitter.parentNode)+e.clientX-pullTab.ra_GetX(splitter);document.onmousemove=function(e){if(!e){e=window.event;}pullTab.ra_mouseMove(e);};document.onmouseup=function(e){if(!e){e=window.event;}pullTab.ra_resizeStop(e);};document.body.ondrag=function(){return!pullTab.dragging;};return false;},ra_GetX:function(oElement){var x=0;while(oElement!==null){x+=oElement.offsetLeft;oElement=oElement.offsetParent;}
return x;},ra_mouseMove:function(e){splitter=window.ra_splitter;x=e.clientX-splitter.parrentOffsetX;if(x>=splitter.parentNode.offsetWidth-splitter.offsetWidth-pullTab.rightSectionMinWidth){x=splitter.parentNode.offsetWidth-splitter.offsetWidth-pullTab.rightSectionMinWidth;}
splitter.style.left=x+"px";return false;},ra_resizeStop:function(){document.onmousemove=null;document.onmouseup=null;var frameset=parent.document.getElementById("contentframeset");splitter=window.ra_splitter;var cols=frameset.cols.split(',');cols[0]=parseInt(cols[0],10);cols[0]+=splitter.offsetLeft;cols[1]='*';splitter.style.left='0px';frameset.cols=cols.join(',');pullTab.dragging=false;if(document.selection){document.selection.empty();}
else if(window.getSelection)
{window.getSelection().removeAllRanges();}},changePullTab:function(){var viewwidth=document.documentElement.clientWidth;var viewheight=document.documentElement.clientHeight;var scrollwidth=document.body.scrollWidth?document.body.scrollWidth:document.documentElement.offsetWidth;var scrollheight=document.body.scrollHeight?document.body.scrollHeight:document.documentElement.offsetWidth;var scrolltop=document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop;var viewportwidth=scrollwidth>viewwidth?scrollwidth:viewwidth;var viewportheight=scrollheight>viewheight?scrollheight:viewheight;var rightside=document.getElementById('rightside');if(rightside){if(scrollheight>viewheight){rightside.style.display="none";}
else{rightside.style.display="block";rightside.style.height=viewportheight+'px';}}
var pullstrip=document.getElementById('pullstrip');if(pullstrip){pullstrip.style.height=viewportheight+'px';}
var pulltab=document.getElementById('pulltab');if(pulltab){var pos=0;if(scrollheight>viewheight){pos=scrollheight-viewheight-scrolltop+42;}else{pos=42;}
pulltab.style.bottom=pos+'px';}}};var popUp={setHeight:function(jumpbar){var viewheight=document.documentElement.clientHeight;var offset=document.all?174:171;if(jumpbar!==true){offset=141;}
var popupoverflow=document.getElementById('popup_overflow');if(popupoverflow){popupoverflow.style.height=viewheight-offset+'px';}},openWindow:function(url,windowtitle){if(windowtitle=='undefined'){windowtitle='popup';}
if(url!='undefined'){window.open(url,windowtitle,'width=700,height=400,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,copyhistory=no,resizable=no');}},closeWindow:function(){window.close();},scrolltoTop:function(){var popupoverflow=document.getElementById('popup_overflow');if(popupoverflow){popupoverflow.scrollTop=0;}}};if(typeof document.observe=='function'){document.observe("dom:loaded",function(){pullTab.changePullTab();Event.observe(document.body,"scroll",function(){pullTab.changePullTab();});Event.observe(document.body,"resize",function(){pullTab.changePullTab();});imageMap.initialize();tooltips.initialize();});}
else{}