﻿var TickFormatters = {

    timeAMPM: function (value, axis) {

        var numericValue = parseInt(value);

        if (numericValue == axis.min ||
                    numericValue == axis.max)
            return "";

        var suffix;
        if (numericValue >= 0 && numericValue < 12)
            suffix = "am";
        else
            suffix = "pm";

        if (numericValue == 0)
            numericValue = 12;

        if (numericValue > 12)
            numericValue -= 12;

        return numericValue + suffix;
    },

    time: function (value, axis) {

        var numericValue = parseInt(value);

//        if (numericValue == axis.min ||
//                    numericValue == axis.max)
//            return "";

        return numericValue + ":00";
    },

    removeMax: function (value, axis) {

        var numericValue = parseInt(value);

        if (numericValue == axis.max)
            return "";
        else
            return value + "";
    }
}


function FullClone(obj) {
    if (obj != null) {
        var cloned = Object.clone(obj);
        for (prop in cloned) {
            if (typeof (cloned[prop]) == "object")
                cloned[prop] = FullClone(cloned[prop]);
        }
        return cloned;
    }
    return null;
}