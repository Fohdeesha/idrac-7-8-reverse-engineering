/* MIT License:
*
* Copyright (c) 2010-2012, Joe Walnes
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/
/**
* This behaves like a WebSocket in every way, except if it fails to connect,
* or it gets disconnected, it will repeatedly poll until it succesfully connects
* again.
*
* It is API compatible, so when you have:
*   ws = new WebSocket('ws://....');
* you can replace with:
*   ws = new ReconnectingWebSocket('ws://....');
*
* The event stream will typically look like:
*  onconnecting
*  onopen
*  onmessage
*  onmessage
*  onclose // lost connection
*  onconnecting
*  onopen  // sometime later...
*  onmessage
*  onmessage
*  etc... 
*
* It is API compatible with the standard WebSocket API.
*
* Latest version: https://github.com/joewalnes/reconnecting-websocket/
* - Joe Walnes
*/
//Web socket for VMedia
/**
* 
* @param {type} ipAddress
* @param {type} port
* @param {type} viewerObject
* @param {type} bSecure
* @returns {AvctVMWebSocket}
*/
var _$_8ab2=["debug","reconnectInterval","timeoutInterval","loginSuccess","SOCK_CONNECTING","SOCK_OPEN","SOCK_CLOSING","SOCK_CLOSED","forcedClose","url","protocols","readyState","URL","binaryType","","mMediaWorkerObj","onopen","VMedia web socket opened  binaryType::","logDebug","arraybuffer","sendVMFirstMessage","onclose","isVMSecure","isReconnectSupport","VMedia notify socket exception for reconnect...","PRIMARY_SOCKET_EXCEPTION","notifySocketException","VMedia connection is closed....","notifyVMediaConnectionState","onconnecting","onmessage","getVMResponseHandler","data","handleResponse","onerror","protocol.. "," url::","getServerPath","/","getQueryString","?","timeoutInterval.. ","exception while creating new websocket ","possible security issue, switching to secure mode","ws:","wss:","replace","new URL","debugAll","AvctVMWebSocket","attempt-connect","getSessionStatus","connection-timeout","close","AvctVMWebSocket::onClose......."," self.readyState::"," forcedClose::"," Reason::","code","Certificate verification may failed.","setVMWebSocketException","Server error of unknown nature 1006: restarting","VMedia","call connect function again","Exception on connect..","exception at connect","sendData","send","INVALID_STATE_ERR  WS(2): Pausing to reconnect websocket","getState","stopReconnect","closeConnection","refresh"];function AvctVMWebSocket(_0x5026,_0x4F36,_0x4EFA,_0x4FEA){var _0x509E=_0x5026;this[_$_8ab2[0]]= false;this[_$_8ab2[1]]= (_0x4FEA* 1000);this[_$_8ab2[2]]= (_0x4FEA* 1000);this[_$_8ab2[3]]= false;this[_$_8ab2[4]]= 0;this[_$_8ab2[5]]= 1;this[_$_8ab2[6]]= 2;this[_$_8ab2[7]]= 3;var _0x4F72=this;var _0x5062;this[_$_8ab2[8]]= false;var _0x4FAE=false;this[_$_8ab2[9]]= _0x5026;this[_$_8ab2[10]]= _0x4F36;this[_$_8ab2[11]]= this[_$_8ab2[4]];this[_$_8ab2[12]]= _0x5026;this[_$_8ab2[13]]= _$_8ab2[14];this[_$_8ab2[15]]= _0x4EFA;this[_$_8ab2[16]]= function(_0x4EBE){Logger[_$_8ab2[18]](_$_8ab2[17]+ _0x5062[_$_8ab2[13]]);_0x5062[_$_8ab2[13]]= _$_8ab2[19];if(_0x4F72[_$_8ab2[15]]!== null){_0x4F72[_$_8ab2[15]][_$_8ab2[20]]()}};this[_$_8ab2[21]]= function(_0x4EBE){if(_0x4F72[_$_8ab2[15]]!== null){if(_0x4F72[_$_8ab2[8]]=== false&& _0x4F72[_$_8ab2[3]]&& _0x4F72[_$_8ab2[15]][_$_8ab2[22]]()&& _0x4F72[_$_8ab2[15]][_$_8ab2[23]]()){Logger[_$_8ab2[18]](_$_8ab2[24]);_0x4F72[_$_8ab2[15]][_$_8ab2[26]](APCPPacket[_$_8ab2[25]])}else {Logger[_$_8ab2[18]](_$_8ab2[27]);_0x4F72[_$_8ab2[15]][_$_8ab2[28]](_0x4F72[_$_8ab2[7]])}}};this[_$_8ab2[29]]= function(_0x4EBE){};this[_$_8ab2[30]]= function(_0x4EBE){if((_0x4F72[_$_8ab2[15]]!== null)&& (_0x4F72[_$_8ab2[15]][_$_8ab2[31]]()!== null)){_0x4F72[_$_8ab2[15]][_$_8ab2[31]]()[_$_8ab2[33]](_0x4EBE[_$_8ab2[32]])}};this[_$_8ab2[34]]= function(_0x4EBE){};function _0x4EBE(_0x509E){Logger[_$_8ab2[18]](_$_8ab2[35]+ _0x4F36+ _$_8ab2[36]+ _0x5026);var _0x4FEA=_0x4F72[_$_8ab2[15]][_$_8ab2[37]]();var _0x5116=_0x4FEA?_0x4FEA+ _$_8ab2[38]:_$_8ab2[14];_0x5026+= _0x5116;var _0x50DA=_0x4F72[_$_8ab2[15]][_$_8ab2[39]]();if(_0x50DA!== null){_0x5026+= _$_8ab2[40]+ _0x50DA};Logger[_$_8ab2[18]](_$_8ab2[41]+ _0x4F72[_$_8ab2[2]]+ _$_8ab2[36]+ _0x5026);try{try{_0x5062=  new WebSocket(_0x5026,_0x4F36)}catch(e){Logger[_$_8ab2[18]](_$_8ab2[42]+ e);Logger[_$_8ab2[18]](_$_8ab2[43]);_0x5026= _0x5026[_$_8ab2[46]](_$_8ab2[44],_$_8ab2[45]);Logger[_$_8ab2[18]](_$_8ab2[47]+ _0x5026);_0x5062=  new WebSocket(_0x5026,_0x4F36)};_0x4F72[_$_8ab2[29]]();if(_0x4F72[_$_8ab2[0]]|| AvctVMWebSocket[_$_8ab2[48]]){Logger[_$_8ab2[18]](_$_8ab2[49]+ _$_8ab2[50]+ _0x5026)};var _0x5152=null;if(_0x4F72[_$_8ab2[15]]!== null&& _0x4F72[_$_8ab2[15]][_$_8ab2[51]]()=== 2){var _0x4EFA=_0x5062;var _0x5152=setTimeout(function(){if(_0x4F72[_$_8ab2[0]]|| AvctVMWebSocket[_$_8ab2[48]]){Logger[_$_8ab2[18]](_$_8ab2[49]+ _$_8ab2[52]+ _0x5026)};_0x4FAE= true;_0x4EFA[_$_8ab2[53]]();_0x4FAE= false},_0x4F72[_$_8ab2[2]])};_0x5062[_$_8ab2[16]]= function(_0x4EBE){if(_0x5152!== null){clearTimeout(_0x5152)};if(_0x4F72[_$_8ab2[0]]|| AvctVMWebSocket[_$_8ab2[48]]){Logger[_$_8ab2[18]](_$_8ab2[49]+ _$_8ab2[16]+ _0x5026)};_0x4F72[_$_8ab2[11]]= _0x4F72[_$_8ab2[5]];_0x509E= false;_0x4F72[_$_8ab2[16]](_0x4EBE)};_0x5062[_$_8ab2[21]]= function(_0x4EFA){Logger[_$_8ab2[18]](_$_8ab2[54]+ _$_8ab2[55]+ _0x4F72[_$_8ab2[11]]+ _$_8ab2[56]+ _0x4F72[_$_8ab2[8]]+ _$_8ab2[57]+ _0x4EFA[_$_8ab2[58]]);if(_0x4EFA[_$_8ab2[58]]=== 1015){Logger[_$_8ab2[18]](_$_8ab2[59]);_0x4F72[_$_8ab2[8]]= true;_0x4F72[_$_8ab2[15]][_$_8ab2[60]]()};if((_0x4EFA[_$_8ab2[58]]=== 1006)&& (_0x4F72[_$_8ab2[3]]=== false)){Logger[_$_8ab2[18]](_$_8ab2[61]);if(!_0x4F72[_$_8ab2[8]]){_0x4F72[_$_8ab2[8]]= true}};clearTimeout(_0x5152);_0x5062= null;if(_0x4F72[_$_8ab2[8]]){_0x4F72[_$_8ab2[11]]= _0x4F72[_$_8ab2[7]];_0x4F72[_$_8ab2[21]](_0x4EFA)}else {_0x4F72[_$_8ab2[11]]= _0x4F72[_$_8ab2[4]];_0x4F72[_$_8ab2[29]]();if(!_0x509E&&  !_0x4FAE){if(_0x4F72[_$_8ab2[0]]|| AvctVMWebSocket[_$_8ab2[48]]){Logger[_$_8ab2[18]](_$_8ab2[62]+ _$_8ab2[21]+ _0x5026)};_0x4F72[_$_8ab2[21]](_0x4EFA)};if(_0x4F72[_$_8ab2[8]]=== false){Logger[_$_8ab2[18]](_$_8ab2[63]);setTimeout(function(){_0x4EBE(true)},_0x4F72[_$_8ab2[1]])}}};_0x5062[_$_8ab2[30]]= function(_0x4EBE){if(_0x4F72[_$_8ab2[0]]|| AvctVMWebSocket[_$_8ab2[48]]){Logger[_$_8ab2[18]](_$_8ab2[62],_$_8ab2[30],_0x5026,_0x4EBE[_$_8ab2[32]])};_0x4F72[_$_8ab2[30]](_0x4EBE)};_0x5062[_$_8ab2[34]]= function(_0x4EBE){{Logger[_$_8ab2[18]](_$_8ab2[49]+ _$_8ab2[34]+ _0x5026,_0x4EBE)}_0x4F72[_$_8ab2[34]](_0x4EBE)}}catch(e){Logger[_$_8ab2[18]](_$_8ab2[64]+ e)}}try{_0x4EBE(_0x5026)}catch(e){Logger[_$_8ab2[18]](_$_8ab2[65]+ e);_0x4F72[_$_8ab2[15]][_$_8ab2[60]]()};this[_$_8ab2[66]]= function(_0x4EBE){if(_0x5062){if(_0x4F72[_$_8ab2[0]]|| AvctVMWebSocket[_$_8ab2[48]]){Logger[_$_8ab2[18]](_$_8ab2[49],_$_8ab2[67],_0x5026,_0x4EBE)};return _0x5062[_$_8ab2[67]](_0x4EBE)}else {throw _$_8ab2[68]}};this[_$_8ab2[69]]= function(){return _0x4F72[_$_8ab2[11]]};this[_$_8ab2[70]]= function(){_0x4F72[_$_8ab2[8]]= true};this[_$_8ab2[71]]= function(){_0x4F72[_$_8ab2[8]]= true;if(_0x5062){_0x5062[_$_8ab2[53]]()}};this[_$_8ab2[72]]= function(){if(_0x5062){_0x5062[_$_8ab2[53]]()}}}AvctVMWebSocket[_$_8ab2[48]]= false