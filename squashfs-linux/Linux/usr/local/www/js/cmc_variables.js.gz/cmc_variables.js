﻿var support = "Support";
var about = "About";
var logout = "Log out";
var version = "Version: 1.15.7";
var date = "Date: 07/11/2010";
var user = "User";
var privilege = "Admin"

var privilege = "256";

var userRights = "";
function userPriv(priv) {
    if (priv == 0) {
        return (true);
    }
    else {
        //took &amp; out and changed it to & so that is would work without XML transforms - REH
        var value = userRights & priv;
        //alert('userRights: ' + userRights + ', priv: ' + priv + ', value = ' + value);
        return (value == priv);
    }
}