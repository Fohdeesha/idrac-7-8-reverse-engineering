var origAlertHeight;
var origTotPadding;
var firstTimeClick = true;

String.prototype.trim = function () {
  return this.replace(/^\s+|\s+$/g, "");
};
String.prototype.ltrim = function () {
  return this.replace(/^\s+/, "");
};
String.prototype.rtrim = function () {
  return this.replace(/\s+$/, "");
};
function hideAlertPaginationButtons(instance) {
  var alertButtonDivs = $$('.alert_button_clear');
  if (instance <= alertButtonDivs.length - 1) {
    alertButtonDivs[instance].addClassName('hide');
  }
}
function hideTablePaginationButtons(instance) {
  var alertButtonDivs = $$('.pagination_button_clear');
  if (instance + 1 <= alertButtonDivs.length - 1) {
    alertButtonDivs[instance].addClassName('hide');
    alertButtonDivs[instance + 1].addClassName('hide');
  }
}
function checkAlertPageCount() {
  var innerAlerts = $$('.alertTabPagesInner');
  var count = 0;
  innerAlerts.each(function (node) {
    var alertPages = node.select('.alertTabPage');
    if (alertPages.length <= 1) {
      hideAlertPaginationButtons(count);
    }
    count++;
  });
}
function checkTablePageCount() {
  var innerAlerts = $$('.tableTabPagesInner');
  var count = 0;

  innerAlerts.each(function (node) {
    var alertPages = node.select('.tableTabPage');
    if (alertPages.length <= 1) {
      hideTablePaginationButtons(count);
    }
    count++;
  });
}

function toggleAllCheckBoxes(primCheckBox, page) {
  var arr = $(page).select('input');
  var check = primCheckBox.checked;

  arr.each(function (node) {
    node.checked = check;
  });
}

function toggleAlert(mySpan, locAlert) {

  closeAllAlertsOnTabPage(locAlert);

  var conHeight = 0;
  var origHeightInt = $(locAlert).getHeight() + 20;

  if (firstTimeClick) {
    origAlertHeight = $(locAlert).getStyle('height');
    origTotPadding = $(locAlert).getStyle('padding-top') + $(locAlert).getStyle('padding-bottom');
    firstTimeClick = false;
  }

  $(mySpan).toggleClassName('table_accordion_row_open');

  var arr = $(locAlert).childElements();
  arr.each(function (node) {
    if (!$(node).hasClassName('alertItemExpandItem')) {
      $(node).toggleClassName('hide');
    }
    if (!$(node).hasClassName('alert_expanded_container')) {
      conHeight = $(node).getHeight();
    }
  });

  if ($(locAlert).getStyle('height') === origAlertHeight) {
    $(locAlert).setStyle({ height: origHeightInt + conHeight + 'px' });
  } else {
    $(locAlert).setStyle({ height: origAlertHeight });
  }
}

function closeAllAlertsOnTabPage(alertItem) {
  var tabPage = $(alertItem).up('.alertTabPage');
  var alertItems = $(tabPage).select('.alertItem');

  alertItems.each(function (item) {
    if (item.id === $(alertItem).id) { return; }
    var toggle = item.down('.table_accordion_row_open');
    if (!toggle) {
      return;
    }
    toggleAlert(toggle, item.id);
  });
}

var lastScrollWidth = 0;
var scrollWidth;
var first = true;

function setTableWidth(pages) {
    var tabArray = $(pages).select('.tableTabPage');
    var tablePage = $(pages).select('.tableTabPages');
    var containerArr = $(pages).select('.option_top_right');
    var newTabWidth = containerArr[0].getWidth();
    var totalLength = newTabWidth * tabArray.length;
    var parentNode;
    tabArray.each(function (node) {
        scrollWidth = newTabWidth;
        if (first) {
            lastScrollWidth = scrollWidth;
            first = false;
        }
        parentNode = $(node).parentNode;
        $(node).setStyle({ width: newTabWidth + 'px' });
    });
    $(parentNode).setStyle({ width: (totalLength + 1000) + 'px' });
    var width = $(pages).getWidth();
    //alert('setting scroll alignment');
    scrollTableAlignCurrentPage(pages);
    var contentContainers = pages.select('.container_content');
    contentContainers.each(function (container) {
        if (!container.hasClassName('hide')) {
            var contWidth = contentContainer.getOffsetParent().getWidth();
            container.setStyle({ width: (contWidth - 75) + 'px' });
        }
    });
}
function getTableWidth(pages) {

  var containerArr = $(pages).select('.option_top_right');
  return containerArr[0].getWidth();

}

function toggleFilter(filter1, filter2) {
  $(filter1).toggleClassName('hide');
  $(filter2).toggleClassName('hide');
}

function toggleTableRow(mySpan, myRow, noPaging) {
  if (!$(mySpan).hasClassName('table_accordion_row_open')) {
    closeAllTabPageTableRows(myRow, noPaging);
  }
  toggleRow(mySpan, myRow, noPaging);
}

function closeAllPagesTableRows(tabPages) {
  // if the rows are not exandible/collapsible then just return
  if ($(tabPages).select('.table_accordion_row_close').length <= 0) { return; }

  var tableTabPages = $(tabPages).select('.tableTabPage');

  tableTabPages.each(function (tabPage) {
    var pageRows = tabPage.down('tbody').childElements();
    pageRows.each(function (row) {
      var mySpan = row.down('td').down('span');
      if (mySpan.hasClassName('table_accordion_row_open')) {
        toggleRow(mySpan, row, false);
      }
    });
  });
}
function closeAllTabPageTableRows(myRow, noPaging) {
  var siblings = $(myRow).siblings();
  siblings.each(function (row) {
    var mySpan;
    if (noPaging) {
      var tds = row.childElements();
      mySpan = tds[1].down('span');
    } else {
      mySpan = row.down('td').down('span');
    }

    if (mySpan.hasClassName('table_accordion_row_open')) {
      toggleRow(mySpan, row, noPaging);
    }
  });
}
function toggleRow(mySpan, myRow, noPaging) {
  var endIndex = $(myRow).cells.length - 1;
  var startIndex = 1;

  if (noPaging) {
    endIndex = $(myRow).cells.length - 2;
    startIndex = 2;
  }

  $(mySpan).toggleClassName('table_accordion_row_open');
  var index = 0;
  for (index = startIndex; index <= endIndex; index++) {
    var cell = $(myRow).cells[index];
    if (index === endIndex) {

      if ($(cell).colSpan === endIndex - 1) {
        $(cell).colSpan = 1;
      }
      else {
        if (noPaging) {
          $(cell).colSpan = endIndex - 1;
        }
        else {
          $(cell).colSpan = endIndex;
        }
      }

      var arr = $(cell).childElements();
      arr.each(function (node) {
        $(node).toggleClassName('hide');
      });
    }
    else {
      $(cell).toggleClassName('hide');
    }
  }

  contentContainer = $(myRow).down('.container_content');
  if (contentContainer) {
    var contWidth = contentContainer.getOffsetParent().getWidth();
    contentContainer.setStyle({ width: (contWidth - 75) + 'px' });
  }
}


function updatelTableTabPagination(tabContentId, pageCount, scrollWidth) {

  if ($(tabContentId)) {


    if ($(tabContentId).select('.tableTabPagesInner').size()) {

      var curPage = Math.round((-($(tabContentId).select('.tableTabPagesInner')[0].positionedOffset().left) / scrollWidth) + 1);

      $(tabContentId).select('.sectionPaginationText')[0].select('input')[0].value = curPage;
      $(tabContentId).select('.sectionPaginationText')[0].select('input')[1].value = curPage;
      $(tabContentId).select('.sectionPaginationText')[1].select('input')[0].value = curPage;
      $(tabContentId).select('.sectionPaginationText')[1].select('input')[1].value = curPage;

      togglePaginationButtons(tabContentId, curPage, pageCount);
    }
  }
}

function toggleAlertPaginationButtons(tabContentId, curPage, pageCount) {
  if (curPage > 1) {
    $(tabContentId).select('.sectionPaginationButtonLeft')[0].removeClassName('disabled');
  } else {
    $(tabContentId).select('.sectionPaginationButtonLeft')[0].addClassName('disabled');
  }

  if (curPage < pageCount) {
    $(tabContentId).select('.sectionPaginationButtonRight')[0].removeClassName('disabled');
  } else {
    $(tabContentId).select('.sectionPaginationButtonRight')[0].addClassName('disabled');
  }
}

function togglePaginationButtons(tabContentId, curPage, pageCount) {
  if (curPage > 1) {
    $(tabContentId).select('.sectionPaginationButtonLeft')[0].removeClassName('disabled');
    $(tabContentId).select('.sectionPaginationButtonLeft')[1].removeClassName('disabled');
  } else {
    $(tabContentId).select('.sectionPaginationButtonLeft')[0].addClassName('disabled');
    $(tabContentId).select('.sectionPaginationButtonLeft')[1].addClassName('disabled');
  }

  if (curPage < pageCount) {
    $(tabContentId).select('.sectionPaginationButtonRight')[0].removeClassName('disabled');
    $(tabContentId).select('.sectionPaginationButtonRight')[1].removeClassName('disabled');
  } else {
    $(tabContentId).select('.sectionPaginationButtonRight')[0].addClassName('disabled');
    $(tabContentId).select('.sectionPaginationButtonRight')[1].addClassName('disabled');
  }
}

function IsNumeric(strString) {
  var strValidChars = "0123456789";
  var strChar;
  var blnResult = true;

  if (strString.length === 0) return false;

  //  test strString consists of valid characters listed above
  for (i = 0; i < strString.length && blnResult === true; i++) {
    strChar = strString.charAt(i);
    if (strValidChars.indexOf(strChar) === -1) {
      blnResult = false;
    }
  }
  return blnResult;
}
function updateAlertPageNumber(tabContentId, updatedPageNumber, maxPageNumber) {
  var pageNumbers = $(tabContentId).select('.sectionPaginationText');

  pageNumbers.each(function (node) {
    node.select('input')[0].value = updatedPageNumber;
    node.select('input')[1].value = updatedPageNumber;
  });

  toggleAlertPaginationButtons(tabContentId, updatedPageNumber, maxPageNumber);
}


function scrollAlertTabToPageOnEnter(e, tabContentId) {
  var evtobj = window.event ? event : e; //distinguish between IE's explicit event object (window.event) and Firefox's implicit.
  var unicode = evtobj.charCode ? evtobj.charCode : evtobj.keyCode;

  //they did not hit enter.
  if (unicode !== 13) {
    return;
  }

  this.scrollAlertTabToPage(tabContentId);

}
function scrollAlertTabToPage(tabContentId) {
  var invalid = false;
  var first = true;
  var currPage, oldPage, maxPage;
  var currPageInt, oldPageInt, maxPageInt, pageOffsetInt, captureNewPageInt = 1;

  var pageNumbers = $(tabContentId).select('.sectionPaginationText');

  pageNumbers.each(function (node) {

    currPage = node.select('input')[0].value;
    if (!IsNumeric(currPage)) {
      invalid = true;
      return false;
    }
    currPageInt = parseInt(currPage);
    if (first) {
      oldPage = node.select('input')[1].value;
      maxPage = node.select('span')[0].innerHTML;
      maxPageInt = parseInt(maxPage);
      oldPageInt = parseInt(oldPage);
      first = false;
    }

    if (currPageInt > maxPageInt || currPageInt <= 0) {
      invalid = true;
      return false;
    }
    if (currPageInt !== oldPageInt) {
      captureNewPageInt = currPageInt;
    }
  });

  if (invalid) { return false; }

  alertScrollWidth = $(tabContentId).select('.alertTabPagesInner')[0].select('.alertTabPage')[0].getDimensions().width;
  pageOffsetInt = captureNewPageInt - oldPageInt;
  updateAlertPageNumber(tabContentId, captureNewPageInt, maxPageInt);
  var paginationScrollSpeed = 0.4;
  var newEffect = new Effect.Move($(tabContentId).select('.alertTabPagesInner')[0], { duration: paginationScrollSpeed,
    transition: Effect.Transitions.sinoidal,
    x: -1 * (alertScrollWidth * pageOffsetInt),
    y: 0,
    mode: 'relative',
    afterFinish: '',
    queue: { scope: 'tablemove', limit: 1 }
  });
}

function updatePageNumber(tabContentId, updatedPageNumber, maxPageNumber) {
  var pageNumbers = $(tabContentId).select('.sectionPaginationText');

  pageNumbers.each(function (node) {
    node.select('input')[0].value = updatedPageNumber;
    node.select('input')[1].value = updatedPageNumber;
  });
 PageNumbersEnabled(tabContentId, true);
  togglePaginationButtons(tabContentId, updatedPageNumber, maxPageNumber);
}

function PageNumbersEnabled(tabContentId,enabled) {
    var pageNumbers = $(tabContentId).select('.sectionPaginationText');

    pageNumbers.each(function (node) {

        node.select('input')[0].removeClassName('disabled');
        node.select('input')[1].removeClassName('disabled');
        node.select('input')[0].enable();
        node.select('input')[1].enable();
        if (!enabled) {
            node.select('input')[0].addClassName('disabled');
            node.select('input')[1].addClassName('disabled');
            node.select('input')[0].disable();
            node.select('input')[1].disable();
        }
    });
}
function scrollTableTabToPageOnEnter(e, tabContentId) {
    var evtobj = window.event ? event : e; //distinguish between IE's explicit event object (window.event) and Firefox's implicit.
    var unicode = evtobj.charCode ? evtobj.charCode : evtobj.keyCode;

    //they did not hit enter.
    if (unicode !== 13) {
        return;
    } else {
        if (evtobj.charCode) {
            evtobj.charCode = 9;
        } else {
            evtobj.keyCode = 9;
        }
    }
    $(tabContentId).focus();
    scrollTableTabToPage(tabContentId);
}

function validateInput(e)
{
        var charCode = (e.which) ? e.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
         return true;
}

function scrollTableTabToPage(tabContentId) {
  var invalid = false;
  var first = true;
  var currPage, oldPage, maxPage;
  var currPageInt, oldPageInt, maxPageInt, pageOffsetInt, captureNewPageInt = 1;


  var pageNumbers = $(tabContentId).select('.sectionPaginationText');
  pageNumbers.each(function (node) {

    currPage = node.select('input')[0].value;
    if (!IsNumeric(currPage)) {
      invalid = true;
      return false;
    }
    currPageInt = parseInt(currPage);
    if (first) {
      oldPage = node.select('input')[1].value;
      maxPage = node.select('span')[0].innerHTML;
      maxPageInt = parseInt(maxPage);
      oldPageInt = parseInt(oldPage);
      first = false;
    }
  /* Allow and default to max page number
    if (currPageInt > maxPageInt || currPageInt <= 0) {
      invalid = true;
      return false;
    }
    */
    if (currPageInt !== oldPageInt) {
      captureNewPageInt = currPageInt;
    }
    //if current page is greater than max page number then default to max.
    if (captureNewPageInt > maxPageInt) { captureNewPageInt = maxPageInt; }

    //if current page is less than min page number then default to 1.
    if (captureNewPageInt < 1) { captureNewPageInt = 1; }

  });

if (invalid) { return false; }
  //Do not disable as this is preventing from highlighting the text on the input field (Defect ID: DF506680)
  //PageNumbersEnabled(tabContentId, false);
  scrollTableTabToSpecificPage(tabContentId, captureNewPageInt, true);
  updatePageNumber.delay(.5, tabContentId, captureNewPageInt, maxPageInt);
}

function scrollTableTabToSpecificPage(tabContentId, captureNewPageInt, animate) {
    var correctLeft = -1 * (scrollWidth * (captureNewPageInt - 1));
    //alert(correctLeft);
    var currentLeftStyle = $(tabContentId).select('.tableTabPagesInner')[0].getStyle('left');
    if (currentLeftStyle !=null)
        currentLeftStyle = currentLeftStyle.replace(/px/i, "");
    var currentLeft = 0;
    currentLeft = parseInt(currentLeftStyle);
    //alert(currentLeft);
    var xDeviation = correctLeft - currentLeft;
    //alert(xDeviation);

    if(xDeviation != 0)
    {
        if (animate) {
            var paginationScrollSpeed = 0.4;
            var newEffect = new Effect.Move($(tabContentId).select('.tableTabPagesInner')[0], { duration: paginationScrollSpeed,
                transition: Effect.Transitions.sinoidal,
                x: xDeviation,
                y: 0,
                mode: 'relative',
                afterFinish: '',
                queue: { scope: 'tablemove', limit: 1 }
            });
        } else {
            $(tabContentId).select('.tableTabPagesInner')[0].setStyle({ 'left': +correctLeft + 'px' });
        }
    }
    
}

function resetTablePaginationWait(tabContentId) {

    //setTimeout(function () {
    //    scrollTableAlignCurrentPage(tabContentId);
    //}, 500);
}

function resetTablePagination(tabContentId) {
  var exitFunction = false;
  var currPage;
  var pageNumbers = tabContentId.select('.sectionPaginationText');
  pageNumbers.each(function (node) {
    currPage = node.select('input')[0].value;

    if (currPage === '1') {
      exitFunction = true;
      return;
    }
    node.select('input')[0].value = '1';
    node.select('input')[1].value = '1';
  });

  if (exitFunction) {
    lastScrollWidth = scrollWidth;
    return;
  }

  var leftButtons = tabContentId.select('.sectionPaginationButtonLeft');
  leftButtons.each(function (node) {
    $(node).addClassName('disabled');
  });

  var rightButtons = tabContentId.select('.sectionPaginationButtonRight');
  rightButtons.each(function (node) {
    $(node).removeClassName('disabled');
  });

  scrollTableAlignCurrentPage(tabContentId);

  lastScrollWidth = scrollWidth;
}
function scrollTableTabScroll(tabContentId, direction, animate) {
    var invalid = false;
    var first = true;
    var currPage, maxPage;
    var currPageInt,  maxPageInt, captureNewPageInt = 1;


    var pageNumbers = $(tabContentId).select('.sectionPaginationText');
    pageNumbers.each(function (node) {

        //currPage = node.select('input')[0].value;
        //Fixing the code to pick the current page number from hidden element instead of text element 
        //Reason: By clicking on the navigation buttons, it was navigating to the next or previous page of value entered in the input element rather than navigating from the current page.
        currPage = node.select('input')[1].value;        
        if (!IsNumeric(currPage)) {
            invalid = true;
            //alert('current page not numaric');
            return false;
        }
        currPageInt = parseInt(currPage);
        if (first) {
            oldPage = node.select('input')[1].value;
            maxPage = node.select('span')[0].innerHTML;
            maxPageInt = parseInt(maxPage);
            oldPageInt = parseInt(oldPage);
            first = false;
        }
        captureNewPageInt = currPageInt + (direction * -1); // I don't know where all this is used, but since its not based on adding pages, I need to flip the sign.
        if (captureNewPageInt > maxPageInt || captureNewPageInt <= 0) {
            invalid = true;
           //alert('new page too high or to low');
            return false;
        }
    });

    if (invalid) {alert('invalid for some other reason');  return false; }
    scrollTableTabToSpecificPage(tabContentId, captureNewPageInt, animate);
    updatePageNumber.delay(.5, tabContentId, captureNewPageInt, maxPageInt);
}

function scrollTableAlignCurrentPage(tabContentId) {
    PageNumbersEnabled(tabContentId, false);
    scrollTableTabScroll(tabContentId, 0, false);
}

function scrollTableTabRight(tabContentId) {
  closeAllPagesTableRows(tabContentId);

  if (!$(tabContentId).select('.sectionPaginationButtonRight')[0].hasClassName('disabled')) {
    PageNumbersEnabled(tabContentId, false);
    scrollTableTabScroll(tabContentId, -1, true);
    return;
  }

}

function scrollTableTabLeft(tabContentId) {
  closeAllPagesTableRows(tabContentId);

  if (!$(tabContentId).select('.sectionPaginationButtonLeft')[0].hasClassName('disabled')) {
    PageNumbersEnabled(tabContentId, false);
    scrollTableTabScroll(tabContentId, 1, true);
  }
}

function updatelAlertTabPagination(tabContentId, pageCount, scrollWidth) {

  if ($(tabContentId)) {
    if ($(tabContentId).select('.alertTabPagesInner').size()) {

      var curPage = Math.round((-($(tabContentId).select('.alertTabPagesInner')[0].positionedOffset().left) / scrollWidth) + 1);
      $(tabContentId).select('.sectionPaginationText')[0].select('input')[0].value = curPage;
      $(tabContentId).select('.sectionPaginationText')[0].select('input')[1].value = curPage;

      if (curPage > 1) {
        $(tabContentId).select('.sectionPaginationButtonLeft')[0].removeClassName('disabled');
      } else {
        $(tabContentId).select('.sectionPaginationButtonLeft')[0].addClassName('disabled');
      }

      if (curPage < pageCount) {
        $(tabContentId).select('.sectionPaginationButtonRight')[0].removeClassName('disabled');
      } else {
        $(tabContentId).select('.sectionPaginationButtonRight')[0].addClassName('disabled');
      }
    }
  }
}

function scrollAlertTabScroll(tabContentId, direction) {

  var paginationScrollSpeed = 0.4;

  if ($(tabContentId)) {
    if ($(tabContentId).select('.alertTabPagesInner').size()) {
      var alertScrolllWidth;
      pageCount = $(tabContentId).select('.alertTabPagesInner')[0].select('.alertTabPage').size();

      if (pageCount > 0) {
        alertScrollWidth = $(tabContentId).select('.alertTabPagesInner')[0].select('.alertTabPage')[0].getDimensions().width;
      } else {
        // default scroll width
        alertScrollWidth = 800;
      }
      // alertScrollWidth = alertScrollWidth;

      var newEffect = new Effect.Move($(tabContentId).select('.alertTabPagesInner')[0], { duration: paginationScrollSpeed,
        transition: Effect.Transitions.sinoidal,
        x: alertScrollWidth * direction,
        y: 0,
        mode: 'relative',
        afterFinish: function () { updatelAlertTabPagination(tabContentId, pageCount, alertScrollWidth); },
        queue: { scope: 'alertmove', limit: 1 }
      });

    }
  }
}

function closeAllAlertsOnPage(tabContentId) {
  var alertItems = $(tabContentId).select('.alertItem');

  alertItems.each(function (item) {
    var toggle = item.down('.table_accordion_row_open');
    if (!toggle) {
      return;
    }
    toggleAlert(toggle, item.id);
  });
}

function scrollAlertTabRight(tabContentId) {
  closeAllAlertsOnPage(tabContentId);

  if (!$(tabContentId).select('.sectionPaginationButtonRight')[0].hasClassName('disabled')) {
    scrollAlertTabScroll(tabContentId, -1);
    return;
  }

}

function scrollAlertTabLeft(tabContentId) {
  closeAllAlertsOnPage(tabContentId);

  if (!$(tabContentId).select('.sectionPaginationButtonLeft')[0].hasClassName('disabled')) {
    scrollAlertTabScroll(tabContentId, 1);
  }
}

//***************************//
//Start graphic functions//
//***************************//

var pie_options = {
  HtmlText: false,
  xaxis: {
    showLabels: false
  },
  yaxis: {
    showLabels: false
  },
  grid: {
    color: '#333', //'#FFFFFF',
    backgroundColor: '#FFFFFF', //'#212429', // => null for transparent, else color
    verticalLines: false,   // => whether to show gridlines in vertical direction
    horizontalLines: false, // => whether to show gridlines in horizontal direction
    outlineWidth: 0
  },
  pie: {
    show: true,
    fill: true,
    fillOpacity: 1,
    explode: 0,
    sizeRatio: 0.7,
    labelFormatter: function (slice) {
      return slice.y + "";
    }
  },
  legend: {
    position: "nw",
    backgroundColor: '#f0f0f0'
  },
  selection: {
    mode: 'xy',            // => one of null, 'x', 'y' or 'xy'
    color: '#B6D9FF',      // => selection box color
    fps: 20                // => frames-per-second
  },
  mouse: {
    track: false,          // => true to track the mouse, no tracking otherwise
    position: 'se',        // => position of the value box (default south-east)
    relative: false,       // => next to the mouse cursor
    margin: 5,             // => margin in pixels of the valuebox
    lineColor: '#FF3F19',  // => line color of points that are drawn when mouse comes near a value of a series
    trackDecimals: 1,      // => decimals for the track values
    sensibility: 2,        // => the lower this number, the more precise you have to aim to show a value
    radius: 3              // => radius of the track point
  }
};


/**
* Function displays a graph in the 'container' element, extending
* the global options object with the optionally passed options.
*/
function drawGraph(series, zoomOpts, containerName, options) {
  var o = Object.clone(options);
  o.xaxis = Object.clone(options.xaxis);
  o.yaxis = Object.clone(options.yaxis);

  if (typeof (zoomOpts) !== "undefined") {
    o.xaxis.min = zoomOpts.xaxis.min;
    o.xaxis.max = zoomOpts.xaxis.max;
    o.yaxis.min = zoomOpts.yaxis.min;
    o.yaxis.max = zoomOpts.yaxis.max;
  }

  return Flotr.draw(
		                $(containerName),
		                series,
		                o
	                );

}

//*******************************************//
//End graphing functions//
//*******************************************//

//***********Start Threshold Progress***************//
function setThresholdRange(thresholdType, thresholdValue) {

    switch (thresholdType) {
        case 'F':
            {
                if (thresholdValue == 0)
                    $('thresholdIndicatorFailure').addClassName('green');
                else if (thresholdValue >= 0.1 && thresholdValue <= 0.7)
                    $('thresholdIndicatorFailure').addClassName('yellow');
                else if (thresholdValue > 0.7)
                    $('thresholdIndicatorFailure').addClassName('red');

                $('thresholdIndicatorFailure').innerHTML = thresholdValue + '%';
                $('thresholdIndicatorFailure').setStyle({ width: ((thresholdValue > 1 || thresholdValue <= 0) ? 1 : thresholdValue) * 100 + '%' });
            }
            break;
        case 'W':
            {

                if (thresholdValue == 0)
                    $('thresholdIndicatorWarning').addClassName('green');
                else if (thresholdValue >= 1 && thresholdValue <= 7)
                    $('thresholdIndicatorWarning').addClassName('yellow');
                else if (thresholdValue > 7)
                    $('thresholdIndicatorWarning').addClassName('red');

                $('thresholdIndicatorWarning').innerHTML = thresholdValue + '%';
                $('thresholdIndicatorWarning').setStyle({ width: ((thresholdValue > 10 || thresholdValue <= 0) ? 10 : thresholdValue) * 10 + '%' });
            }
            break;
    }
}
//***********End Threshold Progress***************//

//*********************************************//
// LCD and LED Object and Methods
//*******************************************//
LcdLedIndicator = {
    errorMultiplier: 3,
    identifyMultiplier: 2,
    setView: function (viewId) {
        LcdLedIndicator.CurrentView.Id = viewId;
        switch (viewId) {
            case 0:
                $('pageTitle').innerHTML = 'Front Panel';
                break;
            case 1:
                $('pageTitle').innerHTML = 'Front Panel';
                break;
            case 2:
                $('pageTitle').innerHTML = 'Front Panel';
                break;

        }
    },
    setViewState: function (errorState, identifyState) {
        //Randomly generate an error state for mock example
        if (errorState >= 3) {
            errorState = LcdLedIndicator.randomNumberGenerator(LcdLedIndicator.errorMultiplier);
        }
        switch (errorState) {
            //There are errors and they're not visible                                              
            case 0:
                LcdLedIndicator.disableErrorButton(false, true);
                LcdLedIndicator.toggleInfoMessage(false);
                break;
            // No Errors                                              
            case 1:
                LcdLedIndicator.disableErrorButton(false, false);
                LcdLedIndicator.toggleInfoMessage(true);

                break;
            //There are errors and they are visible                                              
            case 2:
                LcdLedIndicator.disableErrorButton(true, false);
                LcdLedIndicator.toggleInfoMessage(true);
                break;
        }

        if (identifyState >= 2) {
            identifyState = LcdLedIndicator.randomNumberGenerator(LcdLedIndicator.identifyMultiplier);
        }

        LcdLedIndicator.changeStatusIndicator(errorState, identifyState);
    },
    toggleInfoMessage: function (hide) {
        var children = $(LcdLedIndicator.CurrentView.getCurrentViewId()).descendants();
        children.each(function (container) {
            if (container.id === 'infoMessage' && hide) {
                container.hide();
                return;
            }
            if (container.id === 'infoMessage' && !hide) {
                container.show();
            }
        });
    },
    randomNumberGenerator: function (multiplier) {
        return Math.floor(Math.random() * multiplier);
    },
    removeAllLedClasses: function () {
        var locLed = $(LcdLedIndicator.CurrentView.getCurrentViewId()).down('.ledIcon');
        if (locLed != undefined) {
            locLed.removeClassName('blueFlashLed');
            locLed.removeClassName('blueLed');
            locLed.removeClassName('grayLed');
        }
    },
    changeStatusIndicator: function (errorStatus, identifyStatus) {
        var led = $(LcdLedIndicator.CurrentView.getCurrentViewId()).down('.ledIcon');
        var ledMessage = "";
        LcdLedIndicator.removeAllLedClasses();
        if (led != undefined) {
            if (errorStatus === 1 && identifyStatus === 0) { // No errors displayed and not set to identify
                led.addClassName('grayLed');
                ledMessage = 'No Errors Displayed';
            } else if (errorStatus === 1 && identifyStatus === 1) { // No errors displayed and set to identify
                led.addClassName('blueFlashLed');
                ledMessage = "Identify Enabled";
            } else if ((errorStatus === 0 || errorStatus === 2) && identifyStatus === 0) { // There are errors and not set to identify
                led.addClassName('blueLed');
                ledMessage = "Errors On Server";
            } else if ((errorStatus === 0 || errorStatus === 2) && identifyStatus === 1) {// There are errors and set to identify
                led.addClassName('blueFlashLed');
                ledMessage = "Errors on Server, Identify Enabled.";
            }
        }

        // if there this is the led view then set the message of the led status
        if (LcdLedIndicator.CurrentView.getCurrentViewId() === 'viewLed') {
            $('ledMessage').innerHTML = ledMessage;
        }
    },
    disableErrorButton: function (hide, unhide) {
      if(!top.CAN_CFG_IDRAC) {
        hide = false;
        unhide = false;
      }
        var buttonsEnabled = $(LcdLedIndicator.CurrentView.getCurrentViewId()).select('.container_button');
        var buttonsDisabled = $(LcdLedIndicator.CurrentView.getCurrentViewId()).select('.container_button_disabled');

        buttonsEnabled.each(function (b) {
            if (b.id === 'btnHideErrorsEnabled' && hide) {
                b.show();
                return;
            } else if (b.id === 'btnHideErrorsEnabled' && !hide) {
                b.hide();
                return;
            }

            if (b.id === 'btnUnHideErrorsEnabled' && unhide) {
                b.show();
            }
            if (b.id === 'btnUnHideErrorsEnabled' && !unhide) {
                b.hide();
            }
        });

        buttonsDisabled.each(function (b) {
            if (b.id === 'btnHideErrorsDisabled' && hide) {
                b.hide();
                return;
            } else if (b.id === 'btnHideErrorsDisabled' && !hide) {
                b.show();
                return;
            }
            if (b.id === 'btnUnHideErrorsDisabled' && unhide) {
                b.hide();
            } else if (b.id === 'btnUnHideErrorsDisabled' && !unhide) {
                b.show();
                return;
            }

        });
    },
    toggleLedConfigItems: function (checkBox) {
        var cb = $(checkBox);
        if (cb.id === 'cbBlinkLed') {

            LcdLedIndicator.toggleConfigContainer(cb.up().next(), cb.checked);

            if (!cb.checked) {
                LcdLedIndicator.toggleConfigContainer(cb.up().next().next(), cb.checked);
            }
            return;
        }

        if (cb.id === 'cbBTimeoutLed') {
            LcdLedIndicator.toggleConfigContainer(cb.up().next(), cb.checked);
            return;
        }

    },
    toggleConfigContainer: function (cont, isEnable) {
        var cbs = cont.select('[type=checkbox]');
        var rbs = cont.select('[type=radio]');
        var sps = cont.select('span');

        cbs.each(function (inp) {
            inp.disabled = !isEnable;
            inp.checked = false;
        });

        rbs.each(function (inp) {
            inp.disabled = !isEnable;
            inp.checked = false;
        });

        sps.each(function (sp) {
            if (isEnable) {
                sp.removeClassName('disabled');
                return;
            }
            sp.addClassName('disabled');
        });
    },
    toggleEmptyTextBox: function (txtBox) {

        if ($(txtBox).hasClassName("empty")) {
            $(txtBox).removeClassName("empty");
            $(txtBox).value = "";
        }

    },
    checkTextBoxCount: function (e, txtBox, maxVal) {
        var evtobj = window.event ? event : e; //distinguish between IE's explicit event object (window.event) and Firefox's implicit.
        var unicode = evtobj.charCode ? evtobj.charCode : evtobj.keyCode;

        if (unicode >= 33 || unicode === 13) {
            if ($(txtBox).value.length >= maxVal) {
                return false;
            }
        }

        return true;
    },
    updateMessageBox: function (listBox) {
        var lb = $(listBox);
        var tb = lb.next();

        tb.disabled = true;
        tb.removeClassName('empty');

        switch (lb.options[lb.selectedIndex].innerHTML) {
            case 'None':
                tb.value = '';
                break;
            case 'User Defined':
                tb.value = 'Create User Defined Home Message. (50 Character Limit)';
                tb.disabled = false;
                tb.addClassName('empty');
                break;
            default:
                tb.value = '<' + lb.options[lb.selectedIndex].innerHTML + '>';
                break;
        }
    }
};
LcdLedIndicator.CurrentView = {
  Id: null,
  MaxViews: 3,
  getCurrentViewId: function () {
    return this.getViewIdByIndex(this.Id);
  },
  getViewIdByIndex: function (index) {
    switch (index) {
      case 0:
        return 'viewLcdLed';
      case 1:
        return 'viewLcd';
      case 2:
        return 'viewLed';
      default:
        return 'Invalid';
    }
  }
};
//*********************************************//
// LCD and LED Object and Methods
//*******************************************//
var power_guage = {
    Capacity: 0,
    /*Warning Markers*/
    WarningMarkerId: 'power_guage_lower_marker',
    WarningMarkerTextId: 'power_guage_lower_text',
    WarningThreshold: 0,
    WarningThresholdPercent: 0,
    WarningThresholdTextPercent: 0,
    /*Critical Markers*/
    CriticalMarkerId: 'power_guage_upper_marker',
    CriticalMarkerTextId: 'power_guage_upper_text',
    CriticalThreshold: 0,
    CriticalThresholdPercent: 0,
    CriticalThresholdTextPercent: 0,
    /*Current Markers*/
    CurrentReadingMarkerId: 'power_guage_current_marker',
    CurrentReadingTextId: 'power_guage_current_marker_text',
    CurrentReadingPercent: 0,
    CurrentReadingTextPercent: 0,
    CurrentReading: 0,
    /*Budget Markers*/
    BudgetReadingMarkerId: 'power_guage_budget_marker',
    BudgetReadingTextId: 'power_guage_budget_marker_text',
    BudgetReadingPercent: 0,
    BudgetReadingTextPercent: 0,
    BudgetReading: 0,
    /*Offsets*/
    offsetNoConflict: 1.7,
    offsetConflict: 5,
    setThresholds: function (warningPercentOfCapacity, criticalPercentofCapacity) {
        power_guage.verifyThresholds(warningPercentOfCapacity, criticalPercentofCapacity);
        power_guage.renderThresholds(warningPercentOfCapacity, criticalPercentofCapacity);
    },

    verifyThresholds: function (warningPercent, criticalPercent) {
        try {
            if (warningPercent < 0 || warningPercent > 100 || warningPercent >= criticalPercent) {
                throw "Minimum Threshold Error";
            }
            if (criticalPercent < 0 || criticalPercent > 100 || criticalPercent <= warningPercent) {
                throw "Maximum Threshold Error";
            }

            var cap = parseInt($('capacity').innerHTML);
            power_guage.Capacity = cap;
            power_guage.WarningThresholdPercent = warningPercent;
            power_guage.WarningThreshold = power_guage.Capacity * (warningPercent / 100);
            power_guage.CriticalThresholdPercent = criticalPercent;
            power_guage.CriticalThreshold = power_guage.Capacity * (criticalPercent / 100);
            power_guage.setMinMidMaxLabels(cap);
        }
        catch (e) {
            alert(e);
        }
    },

    setMinMidMaxLabels: function (capacity) {
        $('maxLabel').innerHTML = capacity;
        $('midLabel').innerHTML = capacity / 2;
        $('minLabel').innerHTML = 0;
    },
    renderThresholds: function (warningPercent, criticalPercent) {
        try {

            $(power_guage.CriticalMarkerId).style.bottom = power_guage.CriticalThresholdPercent + '%';
            $(power_guage.CriticalMarkerTextId).innerHTML = power_guage.CriticalThreshold + " Watts - Failure Threshold";
            power_guage.CriticalThresholdTextPercent = power_guage.CriticalThresholdPercent - power_guage.offsetNoConflict;
            $(power_guage.CriticalMarkerTextId).style.bottom = power_guage.CriticalThresholdTextPercent + "%";

            $(power_guage.WarningMarkerId).style.bottom = power_guage.WarningThresholdPercent + '%';
            $(power_guage.WarningMarkerTextId).innerHTML = power_guage.WarningThreshold + " Watts - Warning Threshold";
            power_guage.WarningThresholdTextPercent = power_guage.WarningThresholdPercent - power_guage.offsetNoConflict;
            $(power_guage.WarningMarkerTextId).style.bottom = power_guage.WarningThresholdTextPercent + '%';

            power_guage.adjustThresholds();
        }
        catch (e) {
            alert(e);
        }
    },
    setReadings: function (currentReading, budgetReading) {
        $(power_guage.BudgetReadingMarkerId).show();
        $(power_guage.CurrentReadingMarkerId).show();
        $(power_guage.BudgetReadingTextId).show();
        $(power_guage.CurrentReadingTextId).show();

        power_guage.CurrentReadingPercent = power_guage.calPercentOfCapacity(currentReading);
        $('real_time_reading').innerHTML = currentReading + ' (' + power_guage.CurrentReadingPercent + '% capacity)';
        power_guage.CurrentReading = currentReading;
        $(power_guage.CurrentReadingMarkerId).style.bottom = power_guage.CurrentReadingPercent + '%';
        $(power_guage.CurrentReadingTextId).innerHTML = power_guage.CurrentReading + " Watts - Current Reading";
        power_guage.CurrentReadingTextPercent = power_guage.CurrentReadingPercent - power_guage.offsetNoConflict;
        $(power_guage.CurrentReadingTextId).style.bottom = power_guage.CurrentReadingTextPercent + "%";


        power_guage.BudgetReadingPercent = power_guage.calPercentOfCapacity(budgetReading);
        power_guage.BudgetReading = budgetReading;
        $(power_guage.BudgetReadingMarkerId).style.bottom = power_guage.BudgetReadingPercent + '%';
        $(power_guage.BudgetReadingTextId).innerHTML = power_guage.BudgetReading + " Watts - Defined Limit";
        power_guage.BudgetReadingTextPercent = power_guage.BudgetReadingPercent - power_guage.offsetNoConflict;
        $(power_guage.BudgetReadingTextId).style.bottom = power_guage.BudgetReadingTextPercent + "%";

        power_guage.adjustReadings();
    },
    adjustThresholds: function () {
        var critBottom = power_guage.percentToInt($(power_guage.CriticalMarkerTextId).style.bottom);
        var warnBottom = power_guage.percentToInt($(power_guage.WarningMarkerTextId).style.bottom);
        var difference = critBottom - warnBottom;

        if (difference >= power_guage.offsetConflict) {
            return;
        }

        var differential = (power_guage.offsetConflict - difference) / 2;

        $(power_guage.CriticalMarkerTextId).style.bottom = (critBottom + differential) + '%';
        $(power_guage.WarningMarkerTextId).style.bottom = (warnBottom - differential) + '%';
    },
    adjustReadings: function () {
        var readings = power_guage.createReadingsArray();

        for (var x = 0; x < readings.length; x++) {
            $(readings[x][0]).style.bottom = readings[x][2] + '%';

            if (x >= readings.length - 1) { continue; }

            var diff = power_guage.offsetConflict - (readings[x][2] - readings[x + 1][2]);

            if (diff > 0) {
                readings[x + 1][2] = readings[x + 1][2] - diff;
            }
        }
        diff = 0;
        //Now adjust for the bottom of the guage
        if (readings.length > 0) {
            var pushDelta = 0;
            for (var x = 0; x < readings.length; x++) {
                var tmpPush = (readings[x][2] * -1) + 1;
                if (tmpPush > pushDelta) {
                    pushDelta = tmpPush;
                }
            }
            
            if (pushDelta > 0) {
                for (var x = readings.length - 1; x >= 0; x--) {
                    if (readings[x][2] <= 0) {
                        readings[x][2] = readings[x][2] + pushDelta;
                        if (x != readings.length - 1) {
                            diff = power_guage.offsetConflict - (readings[x + 1][2] - readings[x][2]);
                        }
                        if (diff > 0) {
                            readings[x][2] = readings[x][2] + diff;
                        }
                    }
                    $(readings[x][0]).style.bottom = readings[x][2] + '%';
                    if (x != 0) {
                        diff = power_guage.offsetConflict + (readings[x][2] - readings[x - 1][2]);
                        if (diff > 0) {
                            readings[x - 1][2] = readings[x - 1][2] + diff;
                        }
                    }
                }
            }
        }

    },
    createReadingsArray: function () {
        var orderTemp = new Array();

        orderTemp.push(new Array(power_guage.CriticalMarkerTextId, power_guage.CriticalThreshold, power_guage.percentToInt($(power_guage.CriticalMarkerTextId).style.bottom)));
        orderTemp.push(new Array(power_guage.WarningMarkerTextId, power_guage.WarningThreshold, power_guage.percentToInt($(power_guage.WarningMarkerTextId).style.bottom)));
        orderTemp.push(new Array(power_guage.CurrentReadingTextId, power_guage.CurrentReading, power_guage.percentToInt($(power_guage.CurrentReadingTextId).style.bottom)));
        orderTemp.push(new Array(power_guage.BudgetReadingTextId, power_guage.BudgetReading, power_guage.percentToInt($(power_guage.BudgetReadingTextId).style.bottom)));

        orderTemp = power_guage.sort(orderTemp);
        orderTemp.reverse();

        return orderTemp;
    },
    sort: function (arr) {
        for (i = 0; i < arr.length; i++) {
            tmp = arr[i];
            for (j = i - 1; j >= 0 && arr[j][1] > tmp[1]; j--) {
                arr[j + 1] = arr[j];
            }
            arr[j + 1] = tmp;
        }

        return arr;
    },
    calPercentOfCapacity: function (val) {
        var percentOfCapacity = val / power_guage.Capacity * 100;
        return Math.round(percentOfCapacity * 100) / 100;

    },
    percentToInt: function (percent) {
        if (percent.indexOf("%") <= 0)
            throw "Error Converting Percent to Integer"
        return parseInt(percent.replace('%', ''));
    }
};

/*Firmware updates*/
var needToConfirm = false;
var fwUpdate = {
    setScrollableContainer: function () {
        var h = 0;
        if ($('scrollContainer').getHeight() > $('scrollTable').getHeight()) {
            h = $('scrollContainer').getHeight() - $('scrollTable').getHeight() + 1 + 'px';
            $('emptyRow').setStyle({ height: h });
        }
        fwUpdate.enableUpload(false);
        /*The page exit/unsaved confirmation message appears in IE when any hyperlink with href attribute is clicked.
        The below code is to overcome this behavior in IE.*/
        var links = $$('a[href="#"]');
        links.each(function (el) {
            addEvent.add(el, "click", function (e) { e.preventDefault(); });
        });
    },
    enableUpload: function (flag) {
        if (flag) {
            $('btnUpload').removeClassName('container_button_disabled');
            $('btnUpload').addClassName('container_button');
            addEvent.add($('btnUpload'), "click", fwUpdate.uploadFile);
        }
        else {
            $('btnUpload').removeClassName('container_button');
            $('btnUpload').addClassName('container_button_disabled');
            addEvent.remove($('btnUpload'), "click", fwUpdate.uploadFile);
        }
    },
    uploadFile: function () {
        needToConfirm = true;
        fwUpdate.enableUpload(false);
        fwUpdate.showUploadProgressBar();
        setTimeout(fwUpdate.hideProgressBar, 2000)
    },
    toggleRow: function (mySpan, tbid) {
        $(tbid).setStyle({ display: $(tbid).getStyle('display') == "table" ? "none" : "table" });
        $(mySpan).toggleClassName('table_accordion_row_open');
    },
    toggleCheckbox: function (primCB, container) {
        var sig = $(primCB).id;
        var check = $(primCB).checked;

        var arr = $(container).select('input');
        arr.each(function (node) {
            if (node.id.indexOf(sig) != -1) {
                node.checked = check;
            }
        });
    },
    applyNextReboot: function () {
        if (fwUpdate.validate()) {
            needToConfirm = false;
            modalDialog.show('modalDivInfo', 'modalDialogInfo');
        }
        else {
            modalDialog.show('modalDivWarning', 'modalDialogWarning');
        }
    },
    applyAndReboot: function () {
        if (fwUpdate.validate()) {
            needToConfirm = false;
            modalDialog.show('modalDivProgress', 'modalDialogProgress')
            setTimeout(fwUpdate.hideProgressBar, 2000)
        }
        else {
            modalDialog.show('modalDivWarning', 'modalDialogWarning');
        }
    },
    cancel: function () {
        needToConfirm = false;
        alert('Cancel clicked!');
    },
    validate: function () {
        var isValid = false;

        var updateItems = $('scrollContainer').select('input[type=checkbox]');
        updateItems.each(function (item) {
            if (item.checked) {
                isValid = true;
                throw $break;
            }
        });
        return isValid;
    },
    showUploadProgressBar: function () {
        pageLevelIndeterminateProgressBar.show(true);
    },
    hideProgressBar: function () {
        pageLevelIndeterminateProgressBar.hide();
        modalDialog.hide('modalDivProgress', 'modalDialogProgress')
    },
    confirmExit: function () {
        if(needToConfirm){
            return ("Are you sure you want to leave this page? \nUpdates that have been uploaded, but not applied, will be lost.");
        }
    }
}

/* Backup and Restore*/
var backupRestore =
     {
         disableFields: function () {
             //enable or disable Network Settings
             var flag = $('optvFlash').checked;
             var inputFields = $('NetworkSettings').select('input[type=text]', 'input[type=password]', 'select');
             inputFields.each(function (inputField) {
                 inputField.value = '';
                 inputField.disabled = flag;
             });

             //enable or disable link
             if (flag) {
                 $('lnkTestConnection').addClassName('disabled');
                 $('lnkTestConnection').href = "javascript:void(0);";
             }
             else {
                 $('lnkTestConnection').removeClassName('disabled');
                 $('lnkTestConnection').href = "javascript:backupRestore.testConnection();";
             }

             //enable or disable File Settings
             flag = ($('optRestore').checked && $('optvFlash').checked);
             inputFields = $('FileSettings').select('input[type=text]', 'input[type=password]');
             inputFields.each(function (inputField) {
                 inputField.disabled = flag;
             });
         },
         backupOrRestore: function (option) {
             $('btnBackupRestore').innerHTML = option + " Server Profile";
             $('optPreserve').disabled = $('optDelete').disabled = (option.toLowerCase() == "backup");
             backupRestore.disableFields();
         },
         testConnection: function () {
             alert('Test network connection!');
         }
     }
