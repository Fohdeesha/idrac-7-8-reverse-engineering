﻿/*Simple MUX*/

function setDefaults(selectedOption, slot) {
    //populate configuration based on selecction
    populateConfig(selectedOption);

    //clear & select the slot
    selectIOMSlot(slot);

    updateAssignmentSummary();

    bindEventToSlots();
}

function populateConfig(selectedOption) {
    var configVal = new Array();
    configVal[0] = "Custom Configuration";
    configVal[1] = "Copy A1 Configuration";
    configVal[2] = "Copy B1 Configuration";
    //configVal[3] = "Copy C1 Configuration";
    configVal[3] = "Copy A2 Configuration";
    configVal[4] = "Copy B2 Configuration";
    //configVal[6] = "Copy C2 Configuration";
    var index;
    for (index = 0; index < configVal.length; index++) {
        if (configVal[index].indexOf(selectedOption) > 0) {
            configVal.splice(index, 1);
            break;
        }
    }

    $('ddlConfig').options.length = 0;

    for (index = 0; index < configVal.length; index++) {
        var optn = document.createElement("option");
        optn.text = configVal[index];
        optn.value = configVal[index];
        $('ddlConfig').options.add(optn);
    }
}

function bindEventToSlots() {
    var containers = $$('.annotation');
    containers.each(function (el) {
        addEvent.remove(el, "click", imageMap.showOutline);
        if (el.id.startsWith('chassisfront_Map_')) {
            addEvent.add(el, "click",
                                function () {
                                    var arr = el.id.split('_');
                                    var index = parseInt(arr[arr.length - 1]);
                                    if (index < 8)
                                        index = index + 9;
                                    else
                                        index = 16 - index;

                                    var slot = 'chkSlot' + index;
                                    $(slot).checked = true;
                                    selectChassisSlot($(slot));
                                });
        }
        else {
            addEvent.add(el, "click",
                                function () {
                                    var arr = el.id.split('_');
                                    var index = arr[arr.length - 1];
                                    var optIOM = $('optIOM' + index);
                                    optIOM.checked = true;
                                    selectIOMSlot(index);
                                    populateConfig(optIOM.value);
                                });
        }
    });

}

function selectIOMSlot(slotNo) {
    var slot = 'chassisrear_Map_' + (slotNo);

    //reset IOM selection
    var ioModules = $$('.annotation'); 
    ioModules.each(function (iom) {
        if(iom.id.startsWith('chassisrear_Map_'))
            iom.removeClassName('annotation showoutline');
    });
    //select current IOM
    $(slot).addClassName('annotation showoutline');

    updateAssignmentSummary();
}

function selectChassisSlot(obj) {
    var slotNo = (16 - obj.value);
    slotNo = (obj.value > 8 ? (7 - slotNo) : slotNo);

    var slot = 'chassisfront_Map_' + (slotNo);

    if (obj.checked)
        $(slot).addClassName('annotation showoutline');
    else
        $(slot).removeClassName('annotation showoutline');

    updateAssignmentSummary();
}

function selectAll(bFlag) {
    $$('.chassisSlotsContainer').each(function (container) {
        var chassisSlots = container.select('input[type=checkbox]');
        chassisSlots.each(function (chassisSlot) {
            chassisSlot.checked = bFlag;
            var slot = 'chassisfront_Map_' + (chassisSlot.value - 1);
            if (bFlag)
                $(slot).addClassName('annotation showoutline')
            else
                $(slot).removeClassName('annotation showoutline');
        });
    });
    updateAssignmentSummary();
}

function validateVLANs(e) {
    var charCode = (e.which) ? e.which : e.keyCode;

    if ((charCode > 43 && charCode < 58) || (charCode == 8 || charCode == 9) || (charCode > 34 && charCode < 41))
        return true;
    return false;
}

function validateFields() {
    var isValid = false;

    $$('.chassisSlotsContainer').each(function (container) {
        var chassisSlots = container.select('input[type=checkbox]');
        chassisSlots.each(function (chassisSlot) {
            if (chassisSlot.checked) {
                isValid = true;
                throw $break;
            }
        });
    });
    
    isValid = (isValid && ($('chkIOM16').checked || $('chkIOM32').checked) && ($('txtVLANs').value.trim() != ''));
    return isValid;
}

function validateUpdateVLAN() {
    var isValid = true;
    var inputValue = $('txtVLANs').value;

    if (inputValue.indexOf(',') > 0 || inputValue.indexOf('-') > 0) {
        isValid = false;
    }
    return isValid;
}

function applyChanges() {
    var strMsg = "";
    var numButtons = 2;
    var messageId = $('ddlVLANs').selectedIndex;
    var isValid = ((messageId > 2) || validateFields())

    if (isValid) {
        switch (messageId) {
            case 1:
                {
                    if (!validateUpdateVLAN()) {
                        strMsg = "Invalid entry. Only one untagged VLAN can be configured on a port at any given time."
                        numButtons = 1;
                    }
                    else {
                        strMsg = "Current untagged VLANs in the selected configurations will be overwritten with the entered untagged VLAN.<br><br>Press OK to continue?";
                    }
                    break;
                }
            case 2:
                {
                    strMsg = "The entered VLANs will be removed from the selected configurations.<br><br>Press OK to continue?";
                    break;
                }
            case 3:
                {
                    strMsg = "The selected options will be reset to default configurations to allow all VLANs.<br>This will overwrite current configurations.<br><br>Press OK to continue?";
                    break;
                }
        }
    }
    else {
        strMsg = "Missing values. Confirm that values have been entered for all 4 steps of VLAN Assignment.";
        numButtons = 1;
    }

    if (strMsg != "") {
        (numButtons == 1 ? $('btnCancel').addClassName('hide') :  $('btnCancel').removeClassName('hide'));
        $('dialogMessage').innerHTML = strMsg;
        modalDialog.show('modalDivWarning', 'modalDialogWarning');
    }
}

function updateAssignmentSummary() {
    var selIndex = $('ddlVLANs').selectedIndex;
   
    //enable/disable VLAN entry    
    if (selIndex >= 3) {
        $('txtVLANs').disabled = true;
        $('txtVLANs').addClassName('disabled');
        $('txtVLANs').value = '';
    } else {
        $('txtVLANs').disabled = false;
        $('txtVLANs').removeClassName('disabled');
    }
    
    //enable/disable "Apply" button
    if (selIndex == 4) {
        $('btnApply').removeClassName('container_button');
        $('btnApply').addClassName('container_button_disabled');
    }
    else {
        $('btnApply').removeClassName('container_button_disabled');
        $('btnApply').addClassName('container_button');
    }

    var vLANs = $('ddlVLANs').value + ": " + $('txtVLANs').value;

    var selIOModule = $('optIOMGroup').select('input[type=radio]').find(function (radio) { return radio.checked; }).value;

    var ioModule = "I/O Module: " + selIOModule;
    var portSlots = "";

    if ($('chkIOM16').checked) {
        portSlots = assignPorts(0, selIOModule);
    }

    if ($('chkIOM32').checked) {
        portSlots = portSlots + assignPorts(16, selIOModule);
    }
    var summary = vLANs + "\n" + ioModule + "\n" + portSlots;

    $('txtVLANSummary').value = summary;
}

function assignPorts(portRange, selIOModule) {
    var portSlots = "";
    $$('.chassisSlotsContainer').each(function (container) {
        var chassisSlots = container.select('input[type=checkbox]');
        chassisSlots.each(function (chassisSlot) {
            if (chassisSlot.checked) {
                var portNumber = parseInt(chassisSlot.value) + portRange;
                portSlots = portSlots + "Chassis Slot " + portNumber + ": IOM " + selIOModule + " Port " + portNumber + "\n";
            }
        });
    });
    return portSlots;
}

function filterTableRows(term, col) {
    var searchText = term.value;
    var table = document.getElementById("tblVLANs");
    var cellData;
    for (var row = 1; row < table.rows.length - 1; row++) {
        cellData = table.rows[row].cells[col].innerHTML.replace(/<[^>]+>/g, "");

        if (searchText == '' || (cellData.trim() == searchText.trim())) {
            table.rows[row].style.display = '';
        }
        else {
            table.rows[row].style.display = 'none';
        }
    }
}

