//-------------------------------------------------------------------------
//
//          DELL INC. PROPRIETARY INFORMATION
//
//  This software is supplied under the terms of a license agreement or
//  nondisclosure agreement with Dell Computer Corporation and may not
//  be copied or disclosed except in accordance with the terms of that
//  agreement.
//
//  Copyright (c) 1995-2001 Dell Inc. All Rights Reserved.
// 
//  Abstract/Purpose:
//
//
//  Environment:
//    Windows NT/2000, Linux, Netware
//
//  Created/Version:
//    2001 Jul 24 / $Revision: $
//
//  Author:
//    Christopher Poblete
//
//  Last Modified By/On:
//    $Author: $ / $Date: $
//
//-------------------------------------------------------------------------
function appendVID(url)
{
				    
	var vvid = document.getElementById("vid").value;
					
	if((index=url.indexOf("javascript")) == -1){
		if((index=url.indexOf('#')) != -1){
			url = url.substring(0,index);
		}

		if( (url.indexOf("&amp;vid=") == -1) && (url.indexOf("?vid=") == -1)){
					
			if(url.indexOf('?') != -1){
				url += "&amp;vid=" + vvid;
			}else{
				url += "?vid=" + vvid;
			}
 	      }//vid
	}//javascript
	return url;
				
}

function checkModal ()
{
	var modal = false;

	try
	{
		modal = window.top.body.frames["ct"].g_bModal;
	}
	catch(e)
	{
		try {
			modal = window.top.body.g_bModal;
		     }	
		catch(e) 
		{

		}
	}
	return modal;
}


function help(page , windowid)
{
	page = appendVID(page);
	if (checkModal () == false)
	{
		var helpwin;
		if (windowid == 'null') {
			var n_windowid = (new Number(Math.random())).toString ();
			windowid = n_windowid.substring (n_windowid.indexOf (".") +1);
		}
		helpwin = window.open(page, windowid, config='height=450,width=630,scrollbars=yes,toolbar=no,menubar=no,resizable=yes,location=no,directories=no,status=no');

		// this brings the window to the front.
		helpwin.focus();
	}
}

function support(page , windowid)
{
	if (checkModal () == false)
	{
		var helpwin;
		if (windowid == 'null') {
			var n_windowid = (new Number(Math.random())).toString ();
			windowid = n_windowid.substring (n_windowid.indexOf (".") +1);
		}
		supportwin = window.open(page, windowid, config='height=550,width=930,scrollbars=yes,toolbar=yes,menubar=yes,resizable=yes,location=yes,directories=no,status=yes');

		// this brings the window to the front.
		supportwin.focus();
	}
}

function about(page, windowid)
{
	page = top.gnv.appendVID(page);
	if (checkModal () == false) {
		var aboutwin;
		var n_windowid = windowid + 'about';
		aboutwin = window.open(page, n_windowid, config='height=320,width=600,scrollbars=yes,toolbar=no,menubar=no,resizable=yes,location=no,directories=no,status=no');
		// this brings the window to the front.
		aboutwin.focus();
	}
}

function closePopUpWindow ()
{
	if (checkModal () == false)
		parent.close();
}

function logout ()
{
	if (checkModal () == false)
		top.location.href=appendVID('/servlet/OMSALogout');
}

function visit (sURL)
{
	if (checkModal () == false){
		if (sURL.indexOf("http:") != -1 || sURL.indexOf("https:") != -1)
			top.location.href= appendVID(sURL);
		else
			top.location.href='http://' + appendVID(sURL);
	}
}

function openTaskWindow ()
{
	if (checkModal () == false)
		top.location.href=appendVID('/servlet/OMSATask');
}

function openPreference ()
{
	if (checkModal () == false)
		top.location.href=appendVID('/servlet/OMSATask?mode=pref');
}

function returnProgram (sProgram)
{
	if (checkModal () == false){
		URL = '/servlet/SelectTask?application=' + sProgram;
		top.location.href= appendVID(URL);
	}
}